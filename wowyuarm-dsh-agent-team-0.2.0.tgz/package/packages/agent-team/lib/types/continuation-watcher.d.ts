/**
 * Team-owned idle continuation policy.
 *
 * The supervisor repairs broken Members; this policy covers the opposite
 * failure: every Agent healthy and stopped normally, yet the Task list still
 * holds open work. Left alone, a Team can idle forever on an unfinished list
 * because the last turn ended without anyone picking the next Task up. Every
 * pass reads the same three facts, and only their combination commits:
 *
 * - every enabled Agent reads `available` presence — stopped normally, not
 *   working, not erroring, not unavailable (the supervisor's territory);
 * - at least one open Task (todo / in_progress / in_review) exists;
 * - that shape has held without any ledger write for
 *   {@link CONTINUATION_QUIET_MS} — a hold that rides out the normal gaps
 *   between turns, a Human actively reading, and a leader mid-handoff.
 *
 * When it commits, the Host posts one continuation nudge into the open work's
 * Channel naming the designated leader (`member.leader`), listing the open
 * Tasks with their statuses. The mention delivers through the ordinary Inbox
 * path, so the leader wakes into a normal turn — exactly like being mentioned
 * by a teammate.
 *
 * Every Workspace with open Tasks keeps its own independent quiet hold, so one
 * Workspace's working Agent or ledger writes never stall or reset another's
 * reminder. Latches keep a delivered nudge quiet until something meaningful
 * changes — an Agent works again, the open-Task landscape moves, or the nudge
 * has sat unheard past {@link CONTINUATION_REARM_MS}, when time alone re-arms
 * it for the next quiet period. A Workspace with no designated leader logs once
 * per episode instead of spamming every pass.
 *
 * Counters are process-local by design, exactly like the supervisor's: the
 * nudge itself is an ordinary ledger operation, so a crash around it replays
 * as a normal ledger and never as a half-faked Team fact.
 * @module @wowyuarm/dsh-agent-team/continuation-watcher
 */
import type { AgentTeamMemberId } from './types.ts';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace';
/** How long one continuation pass runs once the Host has restored its Members. */
export declare const CONTINUATION_INTERVAL_MS: number;
/**
 * How long the all-idle, no-ledger-writes shape must hold before one nudge
 * commits. Long enough that a leader finishing a turn, a Human reading, or a
 * handoff in flight resets the hold instead of racing it.
 */
export declare const CONTINUATION_QUIET_MS: number;
/**
 * Time-based nudge re-arm: how long a delivered nudge stays latched even though
 * the leader never worked and the open-Task landscape never changed. Time alone
 * re-arms past this window, so a leader that ignores its reminder is reminded
 * again instead of the watcher going permanently quiet.
 */
export declare const CONTINUATION_REARM_MS: number;
/** One open Task the watcher may name in a continuation nudge. */
export interface ContinuationTask {
    readonly workspaceId: WorkspaceId;
    readonly taskRef: string;
    readonly taskNumber: number;
    readonly status: string;
    readonly subject: string;
}
/** The designated leader one nudge addresses. */
export interface ContinuationLeader {
    readonly memberId: AgentTeamMemberId;
    readonly handle: string;
}
export interface ContinuationWatcherOptions {
    /** Every enabled Agent Member: the watch list. Kept for back-compat; the per-Workspace runs prefer {@link membersInWorkspace}. */
    readonly watchList: () => readonly AgentTeamMemberId[];
    /** Current presence of one watched Member. */
    readonly presenceOf: (memberId: AgentTeamMemberId) => 'available' | 'working' | 'error' | 'unavailable';
    /** Every open Task across all Workspaces, at pass time. */
    readonly incompleteTasks: () => readonly ContinuationTask[];
    /** The enabled designated leader of one Workspace, or undefined. */
    readonly leaderOf: (workspaceId: WorkspaceId) => ContinuationLeader | undefined;
    /** The durable ledger position; any commit resets the quiet hold (global). */
    readonly ledgerPosition: () => number;
    /** Deliver one nudge; a throw is logged and retried on a later episode. */
    readonly notify: (input: {
        readonly workspaceId: WorkspaceId;
        readonly leader: ContinuationLeader;
        readonly tasks: readonly ContinuationTask[];
    }) => Promise<void>;
    /** Log one coordinator diagnostic. */
    readonly log: (message: string) => void;
    readonly intervalMs?: number;
    readonly quietMs?: number;
    /** The enabled Members of one Workspace; defaults to {@link watchList}. */
    readonly membersInWorkspace?: (workspaceId: WorkspaceId) => readonly AgentTeamMemberId[];
    /** Committed-operation count of one Workspace; defaults to {@link ledgerPosition}. */
    readonly positionInWorkspace?: (workspaceId: WorkspaceId) => number;
    /** Time-based nudge re-arm window; defaults to {@link CONTINUATION_REARM_MS}. */
    readonly rearmMs?: number;
}
export declare class TaskContinuationWatcher {
    private readonly options;
    private readonly intervalMs;
    private readonly quietMs;
    private readonly rearmMs;
    private timer;
    private passRunning;
    private disposed;
    /** Per-Workspace, independent idle/armed state, so one Workspace's activity never stalls another's reminder. */
    private readonly states;
    constructor(options: ContinuationWatcherOptions);
    /** Begin the periodic pass; called once the Host has restored every Member. */
    start(): void;
    dispose(): void;
    /** The enabled Members of one Workspace, defaulting to the global watch list. */
    private membersIn;
    /** The committed-operation position of one Workspace, defaulting to the global position. */
    private positionIn;
    /**
     * One continuation pass. Overlapping passes are skipped rather than queued,
     * exactly like the supervision pass: the deliver step is serialized on the
     * Host's send path anyway.
     */
    runPass(now?: number): Promise<void>;
    private passForWorkspace;
    /** One compact diagnostic line per non-firing pass, so host logs show which condition blocks a reminder. */
    private logHoldReason;
}
/**
 * The stable first line of every continuation nudge, carried verbatim into the
 * posted Message. The Inbox notification projection matches it to recognize
 * nudges whose newer delivery has superseded them, so the generator and that
 * matcher share one definition.
 */
export declare const CONTINUATION_NUDGE_MARKER = "Continuation check: every Agent is stopped, but these Task(s) are still open:";
/**
 * The continuation nudge: posted by the Host in the Team Assistant's voice
 * into the open work's Channel, it names the leader, lists every open Task
 * with its standing, and states the one expectation — keep the Team moving.
 * The `@` mention is what delivers the Message and wakes the leader.
 */
export declare function continuationNudgeText(input: {
    readonly leaderHandle: string;
    readonly tasks: readonly ContinuationTask[];
}): string;
//# sourceMappingURL=continuation-watcher.d.ts.map