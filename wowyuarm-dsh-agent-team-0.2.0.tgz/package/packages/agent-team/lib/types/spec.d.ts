import { z } from 'zod';
import type { AgentTeamOperation, AgentTeamOperationId } from './types.ts';
/**
 * Floor for one Member's durable context-window override. Small windows
 * cannot hold a Team turn's fixed prompt assembly, so the override stops
 * here instead of producing a budget the pressure policy would immediately
 * fail closed on.
 */
export declare const MEMBER_CONTEXT_WINDOW_FLOOR = 8192;
/** Ordered backup routes one Member may pin at most. */
export declare const MEMBER_MODEL_FALLBACK_MAX = 4;
/** Durable validator for the closed Agent Team operation union; ledgers written before message occurredAt existed normalize on load. */
export declare const agentTeamOperationSchema: z.ZodType<AgentTeamOperation>;
/** Versioned durable Agent Team declaration; v1 is the first public ledger format and older local media reject at open. */
export declare const agentTeamDomainSpec: {
    name: string;
    version: number;
    tables: {
        operations: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<AgentTeamOperationId, AgentTeamOperation>;
    };
};
//# sourceMappingURL=spec.d.ts.map