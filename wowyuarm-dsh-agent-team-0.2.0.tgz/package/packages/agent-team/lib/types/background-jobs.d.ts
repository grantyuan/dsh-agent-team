/**
 * Team-owned background job registry.
 *
 * A Member starts a long-running script through the `team_job` tool; this
 * registry spawns the process, watches it, and turns its lifecycle into Team
 * facts: a bounded output tail, script-posted progress messages through the
 * gateway, and one completion notice that wakes the owner to handle the
 * result. The registry itself is deliberately process-local — the durable
 * record of a job's life is the Messages it produces, exactly like an
 * external Member's heartbeat cadence staying out of the ledger — so a Host
 * shutdown kills its children instead of pretending to adopt strangers.
 *
 * Authority stays in the Host: the registry never touches the ledger. It
 * reports outcomes through the callbacks the Host wires, and the gateway only
 * forwards a job-token-authenticated script message back here.
 *
 * @module @wowyuarm/dsh-agent-team/background-jobs
 */
import { type ChildProcessWithoutNullStreams } from 'node:child_process';
import type { AgentTeamMemberId } from './types/entities.ts';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace';
/** How many live jobs one Member may hold at once. */
export declare const BACKGROUND_JOB_MAX_PER_MEMBER = 4;
/** How many live jobs the whole Host may hold at once. */
export declare const BACKGROUND_JOB_MAX_TOTAL = 16;
/** Bytes of combined output kept for the completion notice and status reads. */
export declare const BACKGROUND_JOB_OUTPUT_TAIL_BYTES: number;
/** Grace between SIGTERM and SIGKILL when a job is cancelled or the Host stops. */
export declare const BACKGROUND_JOB_KILL_GRACE_MS: number;
/** Stable first line: it names the notice in the owner's Inbox like the other coordinator markers. */
export declare const BACKGROUND_JOB_MARKER = "Team job:";
export type BackgroundJobStatus = 'running' | 'exited' | 'failed' | 'cancelled';
/** One live or just-finished background job. */
export interface BackgroundJob {
    readonly jobId: string;
    readonly workspaceId: WorkspaceId;
    readonly ownerMemberId: AgentTeamMemberId;
    readonly ownerHandle: string;
    readonly name: string;
    /** The display form of the command (program + args); never re-executed. */
    readonly command: string;
    readonly startedAt: number;
    status: BackgroundJobStatus;
    /** The process exit code once the child is gone; undefined while running. */
    exitCode?: number;
    /** Seconds the job ran, filled at finish. */
    ranSeconds?: number;
    /** One bounded progress line the script posted through the gateway. */
    lastScriptMessage?: string;
}
export interface BackgroundJobStartInput {
    readonly workspaceId: WorkspaceId;
    readonly ownerMemberId: AgentTeamMemberId;
    readonly ownerHandle: string;
    readonly name: string;
    readonly program: string;
    readonly args?: readonly string[];
    readonly cwd?: string;
    /** Extra environment for the child, merged over the inherited one. */
    readonly env?: Readonly<Record<string, string>>;
}
export interface BackgroundJobRegistryOptions {
    /** The one completion/outcome callback per job (exit, cancel, or spawn failure). */
    readonly onFinished: (job: BackgroundJob) => Promise<void>;
    /** A script posted a progress message; the Host turns it into a Team Message. */
    readonly onScriptMessage: (job: BackgroundJob, body: string) => Promise<void>;
    /** Log one registry diagnostic. */
    readonly log: (message: string) => void;
    /** Spawn seam; tests substitute a fake child. */
    readonly spawn?: (program: string, args: readonly string[], options: {
        readonly cwd?: string;
        readonly env: NodeJS.ProcessEnv;
        readonly stdio: ['ignore', 'pipe', 'pipe'];
        readonly detached: false;
    }) => ChildProcessWithoutNullStreams;
    readonly now?: () => number;
    readonly maxPerMember?: number;
    readonly maxTotal?: number;
    readonly tailBytes?: number;
    readonly killGraceMs?: number;
}
/**
 * The owner-facing completion notice: one line naming the outcome, the bounded
 * output tail, and the pointer back to the tool. Plain text — the Team
 * Assistant's voice renders literally in the Client, like every other
 * coordinator notice.
 */
export declare function backgroundJobNoticeText(job: BackgroundJob): string;
/**
 * The live-job registry. Every mutation is serialized on the Host's lifecycle
 * queue by its caller; the registry itself only guards its own map.
 */
export declare class BackgroundJobRegistry {
    private readonly options;
    private readonly jobs;
    private readonly maxPerMember;
    private readonly maxTotal;
    private readonly tailBytes;
    private readonly killGraceMs;
    private readonly now;
    private readonly spawnFn;
    private disposed;
    constructor(options: BackgroundJobRegistryOptions);
    /**
     * Spawn one job. A rejected budget or an unknown member is a thrown refusal
     * the tool renders; a child that fails to spawn finishes the job immediately
     * as failed with the spawn error in the tail.
     */
    start(input: BackgroundJobStartInput): {
        readonly job: BackgroundJob;
        readonly token: string;
    };
    /** One job's record, or undefined once it was forgotten. */
    get(jobId: string): BackgroundJob | undefined;
    /** The output tail captured so far (bounded; empty for a finished-then-forgotten job). */
    tailOf(jobId: string): string;
    /** Every job owned by one Member, newest first. */
    listForMember(memberId: AgentTeamMemberId): readonly BackgroundJob[];
    /** How many jobs this Member may still start right now. */
    capacityForMember(memberId: AgentTeamMemberId): number;
    /**
     * Cancel one running job: SIGTERM, then SIGKILL after the grace. The finish
     * notice rides whichever signal actually ends it; cancelling a finished or
     * unknown job is a no-op the tool reports.
     */
    cancel(jobId: string): boolean;
    /**
     * A script reported progress. The job token is the only credential; a
     * mismatch is a refusal the gateway maps to 401. The body is bounded here so
     * the Host-side post never carries an unbounded payload.
     */
    scriptMessage(jobId: string, token: string, body: string): Promise<BackgroundJob>;
    /** Kill every live child and stop accepting work; called on Host dispose. */
    dispose(): void;
    /** One finish: latch, classify, signal the child if a cancel drove it, then notify. */
    private finish;
    /** Append one output chunk, keeping only the last `tailBytes`. */
    private appendTail;
}
//# sourceMappingURL=background-jobs.d.ts.map