import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { SessionId, SessionLogOffset, SessionSeq } from '@deepseek-ai/dsh-session';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace';
import type { AgentTeamAddMemberRequest, AgentTeamAttachmentId, AgentTeamAgentMember, AgentTeamArchiveChannelRequest, AgentTeamArchiveChannelResult, AgentTeamArchiveMemberRequest, AgentTeamArchiveMemberResult, AgentTeamChangeScope, AgentTeamChannelRef, AgentTeamContextCheckpointRef, AgentTeamClaim, AgentTeamClaimList, AgentTeamClaimRequest, AgentTeamClaimResult, AgentTeamClaimRef, AgentTeamCompletedWork, AgentTeamCreateChannelRequest, AgentTeamCreateChannelResult, AgentTeamDmRequest, AgentTeamDmResult, AgentTeamAssistantActor, AgentTeamHumanActor, AgentTeamInbox, AgentTeamInboxActor, AgentTeamInboxRequest, AgentTeamInboxItem, AgentTeamInterruptRef, AgentTeamInterruptResolution, AgentTeamJoinChannelRequest, AgentTeamJoinChannelResult, AgentTeamMemberActor, AgentTeamMemberId, AgentTeamMemberInterrupt, AgentTeamMemberTasks, AgentTeamMemberTasksRequest, AgentTeamMessageRef, AgentTeamEditMessageRequest, AgentTeamEditMessageResult, AgentTeamRecallMessageRequest, AgentTeamRecallMessageResult, AgentTeamOperation, AgentTeamOperationId, AgentTeamOperationReceipt, AgentTeamRemoveChannelMemberRequest, AgentTeamRemoveChannelMemberResult, AgentTeamJoinWorkspaceRequest, AgentTeamJoinWorkspaceResult, AgentTeamLeaveWorkspaceRequest, AgentTeamLeaveWorkspaceResult, AgentTeamRemoveMemberRequest, AgentTeamRemoveMemberResult, AgentTeamReplyRequest, AgentTeamReplyResult, AgentTeamRequestId, AgentTeamResolvedTaskRef, AgentTeamResolvedThreadRef, AgentTeamMessageAttachment, AgentTeamSendMessageRequest, AgentTeamSendMessageResult, AgentTeamSetMemberStateRequest, AgentTeamStatus, AgentTeamTask, AgentTeamTaskRequest, AgentTeamTaskResult, AgentTeamTaskRef, AgentTeamTaskRow, AgentTeamTasks, AgentTeamTasksBatchRequest, AgentTeamTasksBatchResult, AgentTeamTasksRequest, AgentTeamThreadAttentionRequest, AgentTeamThreadAttentionResult, AgentTeamThreadAttentionStatus, AgentTeamThreadHistory, AgentTeamThreadHistoryRequest, AgentTeamThreadReadFact, AgentTeamThreadReadData, AgentTeamThreadReadRequest, AgentTeamThreadReadResult, AgentTeamThreadReadSnapshot, AgentTeamThreadObservations, AgentTeamThreadObservationsRequest, AgentTeamThreadRef, AgentTeamPromoteThreadRequest, AgentTeamPromoteThreadResult, AgentTeamUpdateChannelRequest, AgentTeamUpdateChannelResult, AgentTeamUpdateMemberRequest, AgentTeamView, AgentTeamViewRequest } from './types.ts';
/** Stable Human Member identity shared by every replay of one dshHome Team. */
export declare const AGENT_TEAM_HUMAN_MEMBER_ID: AgentTeamMemberId;
/**
 * Stable Team Assistant identity: the one voice the Team Host's supervision
 * program speaks through. It is a fixed virtual identity like the Human's —
 * never a roster Member with a Session — and the Host alone constructs its
 * actor, so no Remote caller can speak as it.
 */
export declare const AGENT_TEAM_ASSISTANT_MEMBER_ID: AgentTeamMemberId;
/**
 * The Team Assistant's display handle. Reserved in the Member @ namespace so
 * no Agent can take the name the system notices arrive under.
 */
export declare const AGENT_TEAM_ASSISTANT_HANDLE = "Team Assistant";
/**
 * The handle the Human is addressed by in Message bodies. The body parser and
 * the Member directory both read this one constant, so a configurable display
 * name has a single place to land instead of a hard-coded literal per surface.
 */
export declare const AGENT_TEAM_HUMAN_HANDLE = "human";
/** One superseded-instance failure text: the fence, not the ledger content, refused this call. */
export declare const AGENT_TEAM_AUTHORITY_LOST_MESSAGE = "agent-team ledger lost write authority to a newer host; this instance is superseded and commits nothing further";
/** Idempotency identity of the one Host bootstrap operation. */
export declare const AGENT_TEAM_INITIALIZE_REQUEST_ID: AgentTeamRequestId;
/** Resolve the one Human authority owned by this Team. */
export declare function agentTeamHumanActor(): AgentTeamHumanActor;
/** Resolve the one Team Assistant authority the Host's supervision speaks through. */
export declare function agentTeamAssistantActor(): AgentTeamAssistantActor;
/** Caller-owned payload of the idempotent Team initialization request. */
export interface AgentTeamInitializeRequest {
    readonly requestId: AgentTeamRequestId;
    readonly actor: AgentTeamHumanActor;
    readonly humanMemberId: AgentTeamMemberId;
}
export interface AgentTeamAuthorizedCreateChannelRequest extends AgentTeamCreateChannelRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedAddMemberRequest extends AgentTeamAddMemberRequest {
    readonly actor: AgentTeamHumanActor;
    readonly member: AgentTeamAgentMember;
}
export interface AgentTeamAuthorizedSetMemberStateRequest extends AgentTeamSetMemberStateRequest {
    readonly actor: AgentTeamHumanActor;
}
/** Host-authorized intent to move one enabled Member onto a fresh Session id. */
export interface AgentTeamAuthorizedRenewMemberSessionRequest {
    readonly requestId: AgentTeamRequestId;
    readonly workspaceId: WorkspaceId;
    readonly memberId: AgentTeamMemberId;
    /** The freshly minted Session the Member transitions onto. */
    readonly sessionId: SessionId;
    readonly actor: AgentTeamHumanActor;
}
/**
 * Member-authored intent to continue in its next private context generation.
 * The requestId and new Session id derive stably from the successful
 * `context_rollover` tool call so crash replay converges on one operation.
 */
export interface AgentTeamAuthorizedRolloverMemberSessionRequest {
    readonly requestId: AgentTeamRequestId;
    readonly workspaceId: WorkspaceId;
    readonly memberId: AgentTeamMemberId;
    /** The calling Member; must be the target Member itself. */
    readonly actor: AgentTeamMemberActor;
    /** The Session the Member must still be bound to at commit time. */
    readonly previousSessionId: SessionId;
    /** The next generation Session, derived from the successful tool call. */
    readonly newSessionId: SessionId;
    /** Seq of the successful `context_rollover` tool result in the previous Session log. */
    readonly handoffEventSeq: SessionSeq;
    /** Why the rollover happened: the model asked, or ('pressure') a historical Host order no longer produced. */
    readonly trigger: 'model' | 'pressure';
    /** Seed source Session for a checkpoint return; absent on a fresh rollover. */
    readonly sourceSessionId?: SessionId;
    /** Exclusive end of the seeded source prefix (its exact length in the source log). */
    readonly sourceThroughSeq?: SessionLogOffset;
    /** The checkpoint a return was addressed to; absent on a fresh rollover. */
    readonly checkpointRef?: AgentTeamContextCheckpointRef;
}
/**
 * How many pending interrupts one Member may hold. The stack bounds the
 * resume queue the Host nudges at completion; deeper nesting means the
 * Member has been interrupted more times than it can meaningfully pick
 * back up, so a full stack rejects until one is resolved.
 */
export declare const MAX_PENDING_INTERRUPTS = 8;
/** Label and incomplete-state bounds: resume pointers stay compact, notes live in the Member's own memory. */
export declare const INTERRUPT_LABEL_MAX_CHARS = 120;
export declare const INTERRUPT_STATE_MAX_CHARS = 2000;
/** Member-authored intent to pin an unfinished session onto a restorable checkpoint. */
export interface AgentTeamAuthorizedRecordInterruptRequest {
    readonly requestId: AgentTeamRequestId;
    readonly workspaceId: WorkspaceId;
    readonly memberId: AgentTeamMemberId;
    /** The calling Member; must be the target Member itself. */
    readonly actor: AgentTeamMemberActor;
    /** The Member's currently bound Session — the entry pins its context. */
    readonly sessionId: SessionId;
    readonly checkpointRef: AgentTeamContextCheckpointRef;
    readonly label: string;
    readonly incompleteState: string;
    readonly taskRef?: AgentTeamTaskRef;
    readonly threadRef?: AgentTeamThreadRef;
    readonly notePath?: string;
}
/**
 * Intent to close one pending interrupt. The Member itself releases an
 * entry, or the Host records the `resumed` close inside a checkpoint-return
 * transition; the Human releases one through the Client surface.
 */
export interface AgentTeamAuthorizedResolveInterruptRequest {
    readonly requestId: AgentTeamRequestId;
    readonly workspaceId: WorkspaceId;
    readonly memberId: AgentTeamMemberId;
    readonly actor: AgentTeamHumanActor | AgentTeamMemberActor;
    readonly interruptRef: AgentTeamInterruptRef;
    readonly resolution: AgentTeamInterruptResolution;
    readonly reason?: string;
}
export interface AgentTeamAuthorizedJoinChannelRequest extends AgentTeamJoinChannelRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedRemoveChannelMemberRequest extends AgentTeamRemoveChannelMemberRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedJoinWorkspaceRequest extends AgentTeamJoinWorkspaceRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedLeaveWorkspaceRequest extends AgentTeamLeaveWorkspaceRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedSendMessageRequest extends AgentTeamSendMessageRequest {
    readonly actor: AgentTeamHumanActor | AgentTeamAssistantActor | AgentTeamMemberActor;
    /** Metadata the Host resolved from the attachment cache before the append. */
    readonly resolvedAttachments?: readonly AgentTeamMessageAttachment[] | undefined;
}
export interface AgentTeamAuthorizedReplyRequest extends AgentTeamReplyRequest {
    readonly actor: AgentTeamHumanActor | AgentTeamMemberActor;
    /** Metadata the Host resolved from the attachment cache before the append. */
    readonly resolvedAttachments?: readonly AgentTeamMessageAttachment[] | undefined;
}
export interface AgentTeamAuthorizedClaimRequest extends AgentTeamClaimRequest {
    readonly actor: AgentTeamHumanActor | AgentTeamMemberActor;
}
export interface AgentTeamAuthorizedTaskRequest extends AgentTeamTaskRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedTasksBatchRequest extends AgentTeamTasksBatchRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedPromoteThreadRequest extends AgentTeamPromoteThreadRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedThreadAttentionRequest extends AgentTeamThreadAttentionRequest {
    readonly actor: AgentTeamHumanActor | AgentTeamMemberActor;
}
export interface AgentTeamAuthorizedThreadReadRequest extends AgentTeamThreadReadRequest {
    readonly actor: AgentTeamHumanActor | AgentTeamMemberActor;
}
export interface AgentTeamAuthorizedEditMessageRequest extends AgentTeamEditMessageRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedRecallMessageRequest extends AgentTeamRecallMessageRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedRemoveMemberRequest extends AgentTeamRemoveMemberRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedArchiveMemberRequest extends AgentTeamArchiveMemberRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedUpdateChannelRequest extends AgentTeamUpdateChannelRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedArchiveChannelRequest extends AgentTeamArchiveChannelRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedUpdateMemberRequest extends AgentTeamUpdateMemberRequest {
    readonly actor: AgentTeamHumanActor;
}
export interface AgentTeamAuthorizedDmRequest extends AgentTeamDmRequest {
    readonly actor: AgentTeamMemberActor;
}
/** Construction hooks used to make durable operation creation deterministic in tests. */
export interface AgentTeamLedgerOptions {
    readonly operationId?: () => AgentTeamOperationId;
    readonly occurredAt?: () => string;
    readonly ref?: (kind: 'channel' | 'message' | 'task' | 'thread' | 'claim' | 'activity' | 'interrupt') => string;
    /**
     * Single-writer fence (see ledger-fence.ts): consulted before every queued
     * ledger call. A false answer means another host claimed the ledger's write
     * authority, so this instance marks itself superseded and refuses further
     * calls instead of interleaving a fork. Absent means an unfenced ledger,
     * which is every in-process test and any host that does not wire the fence.
     */
    readonly ownsAuthority?: () => Promise<boolean>;
}
/** Internal append result indicating whether this call committed a new record. */
export interface AgentTeamLedgerResult<T> {
    readonly value: T;
    readonly committed: boolean;
}
/**
 * Outcome of one Thread read. A read that committed always carries the receipt
 * of the operation it wrote; a read that committed nothing — an already-read
 * Thread — answers with the current picture instead, and only a retry of a
 * read that did commit still carries that original receipt.
 */
export type AgentTeamThreadReadOutcome = {
    readonly value: AgentTeamThreadReadResult & {
        readonly receipt: AgentTeamOperationReceipt;
    };
    readonly committed: true;
} | {
    readonly value: AgentTeamThreadReadResult;
    readonly committed: false;
};
interface AgentTeamDurableMemberResult {
    readonly receipt: AgentTeamOperationReceipt;
    readonly member: AgentTeamAgentMember;
}
export type { AgentTeamDurableMemberResult };
/**
 * The one tombstone behind every recalled-instruction render: after a recall the
 * body survives in the ledger for audit only, so every derived surface —
 * directory subjects, inbox gists, model-facing fact lines — shows this instead
 * of the withdrawn text. Exported because the model-facing tool renders from the
 * same constant rather than coining its own.
 */
export declare const AGENT_TEAM_RECALLED_BODY_TOMBSTONE = "[instruction withdrawn by the user]";
/**
 * Which of the two durable Thread-read forms one record holds. Both schemas are
 * strict and structurally disjoint — only the pre-receipt snapshot carries the
 * Thread picture — so `thread` decides it for every stored record.
 */
export declare function isThreadReadSnapshot(data: AgentTeamThreadReadData): data is AgentTeamThreadReadSnapshot;
/** The Thread and optional Task one read targeted, whichever form the record holds. */
export declare function threadReadTargetOf(data: AgentTeamThreadReadData): {
    readonly threadRef: AgentTeamThreadRef;
    readonly taskRef?: AgentTeamTaskRef | undefined;
};
/** Replay and append logic behind the Agent Team service interface. */
export declare class AgentTeamLedger {
    private readonly table;
    /** Live projection; record validation replays build independent Projection values instead. */
    private readonly state;
    private readonly confirmations;
    private readonly createOperationId;
    private readonly createOccurredAt;
    private readonly createRef;
    private operationTail;
    /**
     * Runtime human display name. Durable identity stays `member:human`; only
     * the handle read by @ matching and handle-uniqueness follows this value.
     * The Host syncs it from the `agent-team-human` settings namespace; the
     * ledger never persists it, so a rename affects only later resolutions.
     */
    private humanHandle;
    /**
     * Head of the durable records the constructor's record-level replay
     * validated, adoptable once by the invariant mount. See `validateAtMount`.
     */
    private bootValidation;
    /**
     * Sequence of the newest committed record that invalidated the shared
     * projection — the durable position the Client's change cursors compare
     * against, rebuilt by replay like every other index.
     *
     * Records whose commit is private read progress or audit-only
     * (`changeScopesOf` derives no scope for them) never move it, so one
     * Member's Thread read cannot make a parked Client believe that something it
     * watches changed. Being a ledger position rather than a process counter, it
     * also stays monotone across a restart.
     */
    private projectionVersion;
    /**
     * Committed-operation count per Workspace, maintained incrementally on every
     * live apply and rebuilt by replay. It is written only when `applyTo` targets
     * the live state, so a record-validation scratch projection never disturbs it.
     * The idle-continuation watcher compares it between passes to tell whether a
     * single Workspace's own activity reset its quiet hold — the global position
     * cannot, because any other Workspace's writes move that too.
     */
    private readonly workspacePositionCache;
    private readonly ownsAuthority;
    /** Latched once the fence answers false: later calls fail without re-reading the lock. */
    private authorityLost;
    constructor(table: KvTable<AgentTeamOperationId, AgentTeamOperation>, options?: AgentTeamLedgerOptions);
    /** Current human display name for @ matching and uniqueness checks. */
    humanDisplayHandle(): string;
    /**
     * Sync the runtime human display name from Host settings. Never persisted:
     * a rename affects only later @ resolutions and handle checks.
     */
    setHumanDisplayHandle(handle: string): void;
    initialize(request?: AgentTeamInitializeRequest): Promise<AgentTeamLedgerResult<AgentTeamOperationReceipt>>;
    createChannel(request: AgentTeamAuthorizedCreateChannelRequest): Promise<AgentTeamLedgerResult<AgentTeamCreateChannelResult>>;
    /** Human rename of one Channel's display facts; identity refs are immutable. */
    updateChannel(request: AgentTeamAuthorizedUpdateChannelRequest): Promise<AgentTeamLedgerResult<AgentTeamUpdateChannelResult>>;
    addMember(request: AgentTeamAuthorizedAddMemberRequest): Promise<AgentTeamLedgerResult<AgentTeamDurableMemberResult>>;
    /** Human edit of one Member's mutable facts; identity, preset, and lifecycle state are preserved. */
    updateMember(request: AgentTeamAuthorizedUpdateMemberRequest): Promise<AgentTeamLedgerResult<AgentTeamDurableMemberResult>>;
    suspendMember(request: AgentTeamAuthorizedSetMemberStateRequest): Promise<AgentTeamLedgerResult<AgentTeamDurableMemberResult>>;
    resumeMember(request: AgentTeamAuthorizedSetMemberStateRequest): Promise<AgentTeamLedgerResult<AgentTeamDurableMemberResult>>;
    /**
     * Move one enabled Member onto a fresh Session: the durable operation
     * records the sessionId transition while identity, memory, and binding
     * survive. The Host disposes the old handle and archives the previous
     * Session log around this write, so the next turn starts empty.
     */
    renewMemberSession(request: AgentTeamAuthorizedRenewMemberSessionRequest): Promise<AgentTeamLedgerResult<AgentTeamDurableMemberResult>>;
    /**
     * Move one enabled Member onto its next context generation as itself. The
     * actor is the calling Member — the Host executes the transition but is
     * never the business actor — and the durable data records only the
     * verifiable envelope (previous/new Session anchors, the successful handoff
     * tool-result seq, checkpoint seed lineage, trigger). The private handoff
     * prose stays in the Member's own Session log. An exact retry resolves to
     * the recorded outcome; the same requestId with different data collides.
     */
    rolloverMemberSession(request: AgentTeamAuthorizedRolloverMemberSessionRequest): Promise<AgentTeamLedgerResult<AgentTeamDurableMemberResult>>;
    /**
     * Pin one Member's unfinished session onto a restorable checkpoint. The
     * actor is the interrupted Member itself — the Host records this only
     * through its running turn — and the durable data carries the resume
     * pointer plus the bounded semantic description; the full private state
     * stays in the Member's own Session log and memory. One pending entry per
     * (Member, checkpoint): a repeated record of the same anchor resolves to
     * the entry already on the stack rather than duplicating it. An exact
     * retry by requestId resolves to the recorded outcome.
     */
    recordMemberInterrupt(request: AgentTeamAuthorizedRecordInterruptRequest): Promise<AgentTeamLedgerResult<{
        readonly receipt: AgentTeamOperationReceipt;
        readonly interrupt: AgentTeamMemberInterrupt;
    }>>;
    /**
     * Close one pending interrupt. `resumed` is written by the Host inside the
     * checkpoint-return transition that consumed the entry; `released` closes
     * it without returning — by the Member itself, or by the Human through the
     * Client. The pending stack forgets the entry; the operation stays for
     * replay, so the ledger keeps the whole interrupt history without a
     * second store.
     */
    resolveMemberInterrupt(request: AgentTeamAuthorizedResolveInterruptRequest): Promise<AgentTeamLedgerResult<{
        readonly receipt: AgentTeamOperationReceipt;
        readonly interruptRef: AgentTeamInterruptRef;
        readonly resolution: AgentTeamInterruptResolution;
    }>>;
    /** The Member's pending interrupts, newest recorded first — the order the resume protocol walks. */
    pendingInterruptsForMember(memberId: AgentTeamMemberId): readonly AgentTeamMemberInterrupt[];
    /** The pending interrupt pinned to one checkpoint ref, if any — the join the resume transition closes through. */
    pendingInterruptForCheckpoint(memberId: AgentTeamMemberId, checkpointRef: AgentTeamContextCheckpointRef): AgentTeamMemberInterrupt | undefined;
    getMember(memberId: AgentTeamMemberId): AgentTeamAgentMember | undefined;
    /**
     * The retired Session this Member most recently left through a renewal or
     * rollover — the lineage parent a crash between the durable binding commit
     * and the new Session's activation must reconstruct a handoff from. Read
     * from the audit projection; the Member record itself only names the
     * current Session.
     */
    previousSessionForMember(memberId: AgentTeamMemberId): SessionId | undefined;
    /**
     * The latest session transition this Member committed: the retired Session
     * and the target it moved onto, through either a renewal or a rollover.
     * Crash recovery binds carried-input redelivery to the recorded target —
     * the CURRENT Session being that target proves the old generation's
     * unconsumed input still belongs here, regardless of whether the handoff
     * itself already landed.
     */
    lastTransitionForMember(memberId: AgentTeamMemberId): {
        readonly previousSessionId: SessionId;
        readonly targetSessionId: SessionId;
    } | undefined;
    /**
     * The Thread a Task overlay lives on, or undefined for an unknown or
     * archived-Channel Task. Read-only input for attributing claim-mutation
     * boundaries to the Thread whose context they entered.
     */
    threadForTask(taskRef: AgentTeamTaskRef): AgentTeamThreadRef | undefined;
    /**
     * The seed envelope of this Member's most recent rollover, when that
     * rollover was a checkpoint return: the recorded source Session, the
     * exclusive end of its seeded prefix, and the checkpoint ref. A fresh
     * rollover clears the envelope. Crash recovery reads this to rebuild the
     * child generation from the recorded seed instead of an empty context.
     */
    rolloverSeedForMember(memberId: AgentTeamMemberId, targetSessionId: SessionId): {
        readonly sourceSessionId: SessionId;
        readonly sourceThroughSeq: SessionLogOffset;
        readonly checkpointRef: AgentTeamContextCheckpointRef;
    } | undefined;
    /**
     * Count one Member's active Claims on open Tasks in active Channels — the
     * read-only input to the checkpoint single-Thread coverage guard: with
     * more than one, a rewind cannot be proven to stay inside one Thread.
     */
    activeClaimCountForMember(memberId: AgentTeamMemberId): number;
    /**
     * One Member's active Claims on open Tasks in active Channels, oldest
     * first — the read-only input for the retirement notice's released-Claims
     * list.
     */
    activeClaimsForMember(memberId: AgentTeamMemberId): readonly AgentTeamClaim[];
    /**
     * The finished work one Member left behind, derived from operations — the
     * read-only input to the supervision retirement notice. Directions are the
     * Member's `done` Claims, Tasks are the ones those Claims finished and the
     * Human then accepted or closed, and participation counts the Threads the
     * Member wrote a Message in or held a Claim on. Archived Channels stay in
     * the record: the notice is a historical account, not a live work surface.
     */
    completedWorkForMember(memberId: AgentTeamMemberId): AgentTeamCompletedWork;
    listMembers(): readonly AgentTeamAgentMember[];
    /**
     * The durable ledger position: the count of committed operations. Unlike the
     * Client-facing projection version it moves on every commit, including
     * private read progress — the idle-continuation watcher compares it between
     * passes so any Team activity resets the quiet hold.
     */
    position(): number;
    /**
     * Committed operations attributable to one Workspace. Unlike {@link position}
     * this moves only when that Workspace's own operations commit, so the
     * continuation watcher's per-Workspace quiet holds can ignore activity in
     * unrelated Workspaces. Member lifecycle records count under the Member's
     * default Workspace (`member.workspaceId`), matching how their brand scopes.
     */
    positionInWorkspace(workspaceId: WorkspaceId): number;
    /**
     * The Workspaces one committed operation belongs to. Operations that carry an
     * explicit `data.workspaceId` are scoped there directly; Member lifecycle
     * records fall back to the Member's default Workspace (`data.member.workspaceId`).
     * `team/initialized` belongs to no Workspace.
     */
    private operationWorkspaces;
    /**
     * The active Channels one Member belongs to inside one Workspace, oldest
     * first. Read-only projection over the membership index — the supervised
     * handover uses it to give a replacement the same reach its predecessor had.
     */
    channelsForMember(memberId: AgentTeamMemberId, workspaceId: WorkspaceId): readonly AgentTeamChannelRef[];
    /**
     * The enabled Agent Members of one Channel, sorted for deterministic order.
     * Read-only projection over the membership index — broadcast notices
     * (supervised handover, context reset) use it to reach every live Member the
     * notice concerns; the Human is addressed through the `@human` body mention
     * instead, and the sender is excluded by the caller.
     */
    enabledChannelMembers(channelRef: AgentTeamChannelRef): readonly AgentTeamMemberId[];
    joinChannel(request: AgentTeamAuthorizedJoinChannelRequest): Promise<AgentTeamLedgerResult<AgentTeamJoinChannelResult>>;
    removeChannelMember(request: AgentTeamAuthorizedRemoveChannelMemberRequest): Promise<AgentTeamLedgerResult<AgentTeamRemoveChannelMemberResult>>;
    /**
     * Join one Agent Member to one additional Workspace. Participation is a
     * pure relation — no Session is created or moved; the Member's Session
     * stays rooted in its default Workspace and collaboration in the joined
     * Workspace is ledger work addressed by the workspaceId.
     */
    joinWorkspace(request: AgentTeamAuthorizedJoinWorkspaceRequest): Promise<AgentTeamLedgerResult<AgentTeamJoinWorkspaceResult>>;
    /**
     * Withdraw one Agent Member from one of its non-default Workspaces. The
     * default Workspace cannot be left — ending it is the archive path. Every
     * active Claim the Member holds on the Workspace's Threads releases with
     * public Activities, its Attention and markers on those Threads clear, and
     * its Channel memberships there end; identity, Session, and remaining
     * participations are untouched.
     */
    leaveWorkspace(request: AgentTeamAuthorizedLeaveWorkspaceRequest): Promise<AgentTeamLedgerResult<AgentTeamLeaveWorkspaceResult>>;
    /**
     * Archive one Channel: hidden from every surface, facts kept recoverable.
     * Every active Claim on the Channel's Threads releases with one public
     * Activity per (owner, Thread), and every Member's Attention and markers
     * for those Threads clear — a hidden Channel must not leave Tasks stuck in
     * progress behind it or phantom unread counts.
     */
    archiveChannel(request: AgentTeamAuthorizedArchiveChannelRequest): Promise<AgentTeamLedgerResult<AgentTeamArchiveChannelResult>>;
    sendMessage(request: AgentTeamAuthorizedSendMessageRequest): Promise<AgentTeamLedgerResult<AgentTeamSendMessageResult>>;
    reply(request: AgentTeamAuthorizedReplyRequest): Promise<AgentTeamLedgerResult<AgentTeamReplyResult>>;
    /**
     * Human correction of one Human-sent Message. The Message identity never
     * moves; the body is replaced and every mentioned Member who already read
     * the old body gets a fresh direct marker, so the corrected instruction is
     * re-delivered as unread work instead of diverging silently from what the
     * Members saw.
     */
    editMessage(request: AgentTeamAuthorizedEditMessageRequest): Promise<AgentTeamLedgerResult<AgentTeamEditMessageResult>>;
    /**
     * Human retraction or deletion of one Human-sent Message. Both modes stamp
     * `recalledAt`, remove every direct marker the Message still holds, and
     * advance the Thread revision; `deleted` additionally removes the fact from
     * every timeline surface. The Thread anchor is undeletable — it defines the
     * Thread's identity on every projection that reads it, and retraction hides
     * its body while keeping the Thread meaningful.
     */
    recallMessage(request: AgentTeamAuthorizedRecallMessageRequest): Promise<AgentTeamLedgerResult<AgentTeamRecallMessageResult>>;
    promoteThread(request: AgentTeamAuthorizedPromoteThreadRequest): Promise<AgentTeamLedgerResult<AgentTeamPromoteThreadResult>>;
    changeClaim(request: AgentTeamAuthorizedClaimRequest): Promise<AgentTeamLedgerResult<AgentTeamClaimResult>>;
    changeTask(request: AgentTeamAuthorizedTaskRequest): Promise<AgentTeamLedgerResult<AgentTeamTaskResult>>;
    /**
     * The one Task-resolution commit behind both Human write paths — the
     * Thread-page single write (which has already cleared the unread and
     * baseRevision fences) and the Human batch (whose selection is its own
     * intent). Guards, Claim transitions, and the team/task-changed operation
     * live here exactly once; a refused transition throws and each caller
     * reports that in its own shape.
     */
    private commitTaskChange;
    /**
     * Human batch resolution: every requested Task resolves inside one
     * serialized turn, each as its own team/task-changed operation whose
     * requestId derives from the batch's, so a retried batch replays the
     * committed Tasks instead of re-committing them. The Host resolves each
     * Thread's revision at commit time, and the unread and baseRevision fences
     * that guard a Thread-page write do not apply here: the selection comes
     * from the Task list the Host itself projected, so demanding a prior read
     * of every Thread would end the batch before it began. One refused Task
     * never blocks the rest — its outcome carries the ledger's own reason, and
     * an already-resolved Task is reported as such rather than as an error.
     */
    changeTasks(request: AgentTeamAuthorizedTasksBatchRequest): Promise<AgentTeamLedgerResult<AgentTeamTasksBatchResult>>;
    removeMember(request: AgentTeamAuthorizedRemoveMemberRequest): Promise<AgentTeamLedgerResult<AgentTeamRemoveMemberResult>>;
    /**
     * Archive one Member: hidden from every surface, data kept recoverable.
     * The release shape matches removal — active Claims release with public
     * Activities and the Member's Attention/markers clear — because a hidden
     * Member must not leave Tasks stuck in progress or phantom unread counts.
     */
    archiveMember(request: AgentTeamAuthorizedArchiveMemberRequest): Promise<AgentTeamLedgerResult<AgentTeamArchiveMemberResult>>;
    changeAttention(request: AgentTeamAuthorizedThreadAttentionRequest): Promise<AgentTeamLedgerResult<AgentTeamThreadAttentionResult>>;
    /**
     * Append one Member-to-Member direct message as an audit-only operation.
     * A DM is pure delivery: no Channel, Thread, revision, attention, or
     * markers change, so apply() is a marker and no projection state moves.
     */
    sendDm(request: AgentTeamAuthorizedDmRequest): Promise<AgentTeamLedgerResult<AgentTeamDmResult>>;
    /**
     * Bounded adjacent context for a DM relay: the truncated body of the most
     * recent earlier DM between the two sessions, newest first. Returns
     * undefined when this is their first exchange. `excluding` skips the
     * operation id of the DM being delivered right now, so the context line is
     * the adjacent prior exchange rather than a self-reference. Direction
     * labels are from the reader's perspective: the reader is the recipient of
     * the DM being delivered, so messages the reader sent are `you → them`.
     */
    dmHistoryBetween(senderSessionId: SessionId, recipientMemberId: AgentTeamMemberId, excluding?: AgentTeamOperationId): string | undefined;
    /**
     * The ledger boundary to scan a Member's post-completion report from when
     * the completion itself is a Session timestamp rather than an operation:
     * the sequence of the last operation committed at or before the given
     * `occurredAt` (ISO strings compare lexicographically). Sequence 0 means
     * nothing was committed that early — everything in the log follows the stop.
     */
    positionAtOccurredAt(occurredAt: string): number;
    /**
     * Whether one Member addressed the Leader since a ledger position: a
     * Channel message or Thread reply it sent whose delivered mentions name the
     * Leader, or a DM from it to the Leader. The completion liaison reads this
     * to decide whether a finished Member reported; the scan walks the ordered
     * log backwards and stops at the first operation older than the boundary.
     */
    memberReportedToSince(memberId: AgentTeamMemberId, leaderId: AgentTeamMemberId, sinceSequence: number): boolean;
    /**
     * The Member's recent authored Message bodies, newest first, bounded — the
     * history window the Host's dispatch-relevance judgement reads. The scan
     * walks the ordered log backwards and stops once the window fills, the same
     * shape the liaison's report scan pays.
     */
    recentMemberMessageBodies(memberId: AgentTeamMemberId, limit: number): readonly string[];
    /**
     * The content of the Task the Member most recently took part in: the anchor
     * Message of the Thread behind its newest Claim — the Task's opening body,
     * which is what an incoming assignment is measured against. Taking part means
     * claiming, so a Member that finished a Task without posting in its Thread
     * still has one; undefined when it never claimed anything.
     */
    latestTaskContentOf(memberId: AgentTeamMemberId): string | undefined;
    /** The Message one send/reply operation authored; every other kind has none. */
    private authoredMessageOf;
    attentionStatus(actor: AgentTeamHumanActor | AgentTeamMemberActor, request: {
        workspaceId: WorkspaceId;
        threadRef?: AgentTeamThreadRef | undefined;
        taskRef?: AgentTeamTaskRef | undefined;
    }): AgentTeamThreadAttentionStatus;
    inbox(actor: AgentTeamHumanActor | AgentTeamMemberActor, request: AgentTeamInboxRequest): AgentTeamInbox;
    memberInbox(actor: AgentTeamMemberActor, request: {
        readonly limit?: number;
    }): AgentTeamInbox;
    private inboxForWorkspaces;
    /**
     * The one person a row names: whoever committed the fact that row's instant
     * came from — a Message's sender, an activity's actor — resolved to the handle
     * the row draws. Resolving it here is what spares every Client row a Member
     * view of its own, and a Member the roster no longer names still reads as
     * themselves through their raw id rather than as nobody.
     */
    private inboxActorFor;
    /**
     * The row-drawing form of one Member for surfaces outside the ledger's own
     * projections — the Host's Thread digest resolves author names through this
     * same path, so a name never reads differently on two surfaces.
     */
    actorFor(memberId: AgentTeamMemberId): AgentTeamInboxActor;
    /**
     * The clock and decision material every row shows: when the Thread opened,
     * who last replied and when, and whether it still waits on the Human. The
     * decision flag is a Thread fact, not a reader fact — an open Task awaiting
     * acceptance, or the newest Message that named the Human asked for a call
     * (see `namesHumanDecisionAsk`) and came after the Human's own last word —
     * so an Agent reading its own Inbox never flips the same Thread on its own
     * mentions.
     */
    private inboxThreadClock;
    /**
     * One Member as a row draws them: the id carries the identity hue, the handle
     * the initial. The Human is the one Member the Agent roster never holds, so
     * their row reads the runtime display name rather than falling back to the
     * durable `member:human` id — the same name every other seat and @ matching
     * already use.
     */
    private memberActor;
    /**
     * The people a Task still has on it, resolved the way a row draws them: owners
     * of its live Claims, in claim order, deduped. A released Claim is not work,
     * and a done or closed Task keeps its Claims as history rather than as
     * presence — deliberately the same rule the Channel feed applies to the same
     * Task, so 「谁在这个 Task 上」 never acquires a second definition.
     */
    private liveClaimOwners;
    /**
     * The Human Inbox's 「最近活跃」 slice: the Threads this reader has written in
     * — the durable way back into work instead of a mention-only queue.
     * Participation is the whole admission rule: a reader who replied to somebody
     * else's Thread is here whether or not they follow it, and so is one who
     * started a Thread nobody has answered yet, because starting one is writing
     * its anchor. Attention deliberately plays no part — it decides what notifies
     * a reader (a reply does not implicitly follow a Thread), and reading it here
     * as well is what once hid every Thread a reader had replied to without
     * following. A Thread the reader later unfollowed stays: they did take part
     * in it, and unfollowing stops the notifications, not the record. Every
     * Thread still holding unread is excluded because the queue above already
     * carries it, and the slice is newest-activity first, bounded by
     * `RECENT_INBOX_LIMIT`. Rows are the same shape as unread rows with every
     * count at zero — they are the same row to render.
     */
    private recentInboxItems;
    /**
     * Threads that can hold unread facts for one reader, from the per-reader
     * derived indexes: Attention follows plus direct and activity markers.
     * Every unread source is covered — ordinary unread requires Attention, and
     * marker unread requires a marker — so no full Thread scan is needed.
     */
    private inboxCandidateThreads;
    /** Model-visible notification material derived from the recipient's current durable unread state. */
    notificationFacts(memberId: AgentTeamMemberId, request?: AgentTeamInboxRequest): readonly {
        readonly item: AgentTeamInboxItem;
        readonly facts: readonly AgentTeamThreadReadFact[];
    }[];
    readThread(request: AgentTeamAuthorizedThreadReadRequest): Promise<AgentTeamThreadReadOutcome>;
    threadObservations(actor: AgentTeamHumanActor, request: AgentTeamThreadObservationsRequest): AgentTeamThreadObservations;
    /** Every operation carrying an inbox delta drives the Inbox projection; the payload shape decides, not a per-kind list. */
    private attentionDelta;
    /** Attachment ids referenced by any stored Message — the GC's keep-set oracle. */
    referencedAttachmentIds(): Set<AgentTeamAttachmentId>;
    threadHistory(actor: AgentTeamHumanActor | AgentTeamMemberActor, request: AgentTeamThreadHistoryRequest): AgentTeamThreadHistory;
    listClaims(actor: AgentTeamHumanActor | AgentTeamMemberActor, request: {
        workspaceId: WorkspaceId;
        taskRef: AgentTeamTaskRef;
    }): AgentTeamClaimList;
    getTask(taskRef: AgentTeamTaskRef): AgentTeamTask | undefined;
    getClaim(claimRef: AgentTeamClaimRef): AgentTeamClaim | undefined;
    /** Navigation facts for message-body Thread refs; unknown refs are omitted. */
    resolveThreadRefs(workspaceId: WorkspaceId, threadRefs: readonly AgentTeamThreadRef[]): AgentTeamResolvedThreadRef[];
    /** Navigation facts for message-body Task refs; unknown refs are omitted. */
    resolveTaskRefs(workspaceId: WorkspaceId, taskRefs: readonly AgentTeamTaskRef[]): AgentTeamResolvedTaskRef[];
    /**
     * The Human Task list projection: every Task in the Workspace, its home
     * Channel ordinal order, with the facts one row draws without a per-row
     * Member or Thread view. Status follows the one derived rule the results
     * and radar use, so the list never disagrees with a Thread heading about
     * where a Task stands. Sub-task trees assemble client-side from
     * `parentTaskRef`; the ledger stays flat, exactly like the projection it
     * derives from.
     */
    tasksForWorkspace(request: AgentTeamTasksRequest): AgentTeamTasks;
    /**
     * The per-Member working-queue projection: one queue per visible Agent
     * Member of the Workspace. 「Current」 is the Tasks the Member holds a live
     * Claim on (active or done — a finished Claim still awaits Human
     * acceptance, so the work stays its until the Task resolves); 「queued」 is
     * the unclaimed `todo` Tasks in Channels the Member has joined, which is
     * exactly what it could claim next. Rows are the Task-list rows, so the
     * Client renders one grammar on both surfaces.
     */
    memberTasksForWorkspace(request: AgentTeamMemberTasksRequest): AgentTeamMemberTasks;
    /**
     * Open Tasks across every Workspace for the Host's idle continuation
     * watcher; not an RPC surface. Status follows the same derived rule as the
     * Task list, but the watcher's open set stops at `in_review`: a Task that
     * finished its Claims now waits for Human acceptance, which is not work to
     * remind stopped Agents about, so the watcher and the Human Task list
     * intentionally disagree about that one status.
     */
    incompleteTasksForWatch(): readonly (AgentTeamTaskRow & {
        readonly workspaceId: WorkspaceId;
    })[];
    /** The Workspace one Task lives in, or undefined when its Channel is archived (hidden from every surface). */
    private workspaceOfTask;
    /** One Task-list row; the single mapping behind the Human read and the watcher. */
    private taskRowFor;
    view(request: AgentTeamViewRequest, memberId?: AgentTeamMemberId): AgentTeamView;
    status(): AgentTeamStatus;
    validate(): void;
    /**
     * Validate the durable ledger for the invariant's mount check, reusing the
     * constructor's record-level replay once instead of paying a second identical
     * one at startup.
     *
     * The adoption is gated on the operations table's single-writer identity —
     * this ledger's commit path is the only caller of `table.put` — so an
     * unchanged record count, head sequence and head operation id mean a
     * mount-time replay would re-derive precisely the records the constructor
     * already re-derived against its own scratch projection. Any commit between
     * construction and mount, and every later call, falls back to the full
     * replay. The check is never narrowed: the reused conclusion is still that
     * same independent replay of every durable record.
     */
    validateAtMount(): void;
    hasCommitted(requestId: AgentTeamRequestId): boolean;
    /** Return one stored committed operation by id. */
    getOperation(operationId: AgentTeamOperationId): AgentTeamOperation | undefined;
    /**
     * Claim releases are thread-visible facts: an open Channel page and every
     * affected Thread page must refetch alongside the workspace-wide change. Each
     * released activity contributes its own Thread scope plus the Channel that
     * owns its Task, deduplicated against the caller's initial scopes — which is
     * why the caller passes them in rather than the helper inventing them.
     */
    private withReleasedActivityScopes;
    /** One workspace change scope per Workspace the Member participates in — member-level commits wake every panel that lists it. */
    private memberWorkspaceScopes;
    /**
     * Durable position of the newest shared-projection commit: the version every
     * change waiter outside the presence scope observes. It only moves when a
     * commit has scopes somebody could refetch (`changeScopesOf`), never for
     * private read progress or an audit-only record.
     */
    projectionSequence(): number;
    /** Scopes whose projections one committed operation invalidates; undefined wakes every waiter. */
    changeScopesOf(operation: AgentTeamOperation): readonly AgentTeamChangeScope[] | undefined;
    /** Members whose Inbox projection may have changed; the Host notifies only live ones. */
    affectedMembersOf(operation: AgentTeamOperation): readonly AgentTeamMemberId[];
    /**
     * Members that may be executing a Human Message right now: mentioned by it
     * and having read through it, so its body has already reached them. The Host
     * force-stops the running subset before an edit or recall emits its wake;
     * mention-less readers cannot be told apart from other followers, and the
     * Human itself never executes.
     */
    executorsOfMessage(messageRef: AgentTeamMessageRef): readonly AgentTeamMemberId[];
    private touchedThreadRefs;
    private replay;
    private validateRecords;
    private validateOperation;
    /**
     * Validation of one operation's Inbox delta against the projection it was
     * derived from.
     *
     * Direct marker references resolve through the replay-derived Message index:
     * this runs once per inbox-carrying record, so a rescan of the Message list
     * here would make every record cost the whole ledger. The index is written by
     * the same fact appends that build `factsByThread`, so a lookup sees exactly
     * the records replayed before this one and can never reach a Message that
     * arrives later — which is why the operation's own entity, not yet in the
     * projection, needs the `additional*` fallbacks. The commit path resolved the
     * projection first and then its own record, and that precedence is kept.
     */
    private validateInboxDelta;
    /**
     * Replay validation of one departure's release snapshot against the
     * projection it was derived from. `memberId` scopes everything to a single
     * departing Member; `undefined` validates every owner, which is what
     * archiving a whole Channel releases. The two scopes differ in exactly four
     * ways, all of them visible here rather than spread over two copies:
     *
     * 1. released Claims are owner-filtered for a Member, unfiltered for a Channel;
     * 2. Activities group per (owner, Thread) with owners sorted, which for a
     *    single departing Member collapses to one Activity per Thread — the shape
     *    the commit path writes;
     * 3. the inbox cleanup covers the departing Member's Attention and markers, or
     *    every Member's on the archived Channel's Threads;
     * 4. the failure message names which of the two paths lost its cleanup.
     */
    private validateReleaseCleanup;
    private validateMessageInbox;
    /**
     * The inbox delta a Message send or Thread reply must carry: a start-attention
     * per unfollowed recipient plus one direct marker per mention. A top-level
     * send starts every mentioned Member; a reply only starts unfollowed ones.
     * Since Human replies started following the replied Thread, the current
     * writer adds the sender's start-attention; `humanJoinsReplyThread` selects
     * that shape against the legacy one that left the sender unfollowed.
     */
    private messageInboxExpectation;
    private validateMentions;
    private validMentionTarget;
    private apply;
    private applyTo;
    /**
     * Replay the departure snapshot a releasing operation carries. The order is
     * replay semantics, not style: Claims land before the Activities that
     * reference them, and Tasks/Threads before the inbox delta that reads them.
     * Each caller still applies its own identifying writes (member, membership,
     * channel) around this call.
     */
    private applyReleaseSnapshot;
    /** Facts arrive in ledger sequence order, so global and per-thread lists stay sorted by append only. */
    private appendMessageFact;
    private appendActivityFact;
    /** In-place swap of one Message fact: the identity and sequence never move, so list order survives. */
    private replaceMessageFact;
    /** Erase one Message fact from every timeline surface; the ledger record itself stays for audit. */
    private removeMessageFact;
    /** Display ordinals are a per-Channel creation counter; the workspace filter happens at read time. */
    private recordTaskNumber;
    /**
     * Replay-order Attention observations, appended from committed Inbox deltas
     * only (the hypothetical read projection applies its delta directly). The
     * follow/unfollow decision mirrors the full replay scan it replaces: a
     * removal records only when Attention existed, and a set records unless it
     * is the Thread-creating Message (initial Attention) or merely advances the
     * same follow's watermark. Removals are evaluated before sets, exactly like
     * the scan's loop order.
     */
    private recordAttentionObservations;
    private appendObservation;
    private applyInboxDelta;
    /** Insert into the Member's Thread bucket keeping the sequence order the read path must see. */
    private insertBucketedMarker;
    private removeBucketedMarker;
    private prepareRead;
    /**
     * Derive the durable receipt of one Thread read from a prior projection: the
     * Thread it targeted, the watermark it reaches, the Attention row it writes
     * and the Inbox delta it consumes. This is the whole durable content of a
     * receipt-shaped read and the only thing `validateRecords` re-derives for
     * one; the picture derivation below builds on the same result, so the two can
     * never drift.
     */
    private prepareReadReceiptFrom;
    /** Derive the only legal durable result of one Thread read from a prior projection. */
    private prepareReadFrom;
    private readFactFrom;
    private unreadFor;
    private unreadForFrom;
    /**
     * The single authority on "this fact is unread for this reader". The picture
     * derivation and the remaining-count derivation both go through it, so the
     * count a read reports can never disagree with the facts it lists. Marker
     * membership arrives as key sets: the caller may be looking at a state the
     * projection has not applied yet.
     */
    private isUnreadFact;
    /**
     * Unread count once this read's own Inbox delta has been applied, derived
     * without materializing a hypothetical projection. The delta can only touch
     * the reader's own Attention row and its own marker keys in one Thread, and
     * every lookup in `isUnreadFact` is scoped to that same (member, Thread)
     * pair, so the post-delta state is the Attention row the receipt already
     * derived plus those marker keys with the delta's own removals and additions
     * applied.
     */
    private remainingUnreadAfter;
    private visibleToFollower;
    private threadFacts;
    private threadFactsFrom;
    /**
     * The one per-fact instant projection: a fact's wall-clock time is the
     * occurredAt of the ledger operation that committed it, looked up by
     * sequence inside the same read snapshot. Every agent-facing surface
     * (Thread facts, notifications, DM history, mutation results) resolves
     * through this single path, never a second parallel lookup.
     */
    private occurredAtForFactFrom;
    private messageInboxDelta;
    /**
     * The edit re-delivery delta: direct markers re-added exactly for the
     * mentioned Members who have already read through the Message. Members who
     * never read it keep their original marker and will simply read the new
     * body; re-adding for them would collide with the live marker.
     */
    private editRedeliveryDeltaFrom;
    /** The recall cleanup delta: every direct marker still held on the Message, removed. */
    private recallCleanupDeltaFrom;
    private closeThreadInbox;
    private closeThreadInboxFrom;
    /**
     * Acceptance notifies every done Claim owner — pre-finished (the normal
     * flow) and atomically completed (early acceptance) alike — through
     * activity markers regardless of whether they still follow the Thread.
     * The actor never notifies itself. Legacy records without the acceptance
     * discriminator keep the old completed-only wake semantics on replay.
     */
    private acceptThreadInbox;
    private acceptThreadInboxFrom;
    private reopenThreadInbox;
    private reopenThreadInboxFrom;
    /** Promotion wakes every current follower; the Human actor never follows, so no recipient filter is needed. */
    private promoteThreadInbox;
    private promoteThreadInboxFrom;
    private removeMemberThreadInbox;
    private removeMemberThreadInboxFrom;
    /** Attention and marker cleanup for EVERY Member on the given Threads. */
    private channelArchivalInbox;
    private channelArchivalInboxFrom;
    private inboxDelta;
    private startAttention;
    private followAttention;
    private followAttentionFrom;
    private currentTail;
    private attentionFor;
    private attentionForFrom;
    private isFollowing;
    private isFollowingFrom;
    private directMarkersFor;
    private directMarkersForFrom;
    private activityMarkersForFrom;
    private issueConfirmation;
    private consumeConfirmation;
    private assertMentionTargets;
    private unreadRequired;
    private staleRevision;
    private releaseSummaries;
    private threadsForActivities;
    private claimsForTask;
    private claimsForTaskFrom;
    private claimsForVisibleTasks;
    /**
     * The team_view「活跃 task thread」radar for a Workspace: every visible Task
     * still in flight — in_progress or in_review, the two states a live Claim
     * keeps a Task in — newest activity first. Unlike `recentInboxItems`, this is
     * not a participation slice: admission is the Task being active in a Channel
     * the reader can see, whether or not the reader wrote in it, and a Thread
     * still holding the reader's unread is not excluded. Rows carry the same
     * `liveClaimOwners`口径 the Inbox and Channel feed already use, so 「谁在这个
     * Task 上」 never gains a second definition. Archived Channels are already
     * absent from `visibleTasks`, so their Tasks never reach here.
     */
    private activeTaskThreads;
    private tasksForClaims;
    /** Resolve one Task's Thread for a workspace-authorized actor; Member actors must belong to the Task's Channel. */
    private threadForActor;
    /** Business outcomes that defer a thread write: unread work first, then a stale revision. */
    private deferredThreadWrite;
    /** Commit projections shared by the Message-sent and Thread-replied results. */
    private committedMessageResult;
    private threadAnchor;
    private threadAnchorFrom;
    private threadFactKey;
    /**
     * Display numbers for Tasks: one counter per home Channel, in creation
     * order. This is the single numbering authority — Channel cards, Thread
     * headings, cross-channel ref resolution, and inbox renders all show the
     * ordinal the Task holds inside its own Channel. The ordinals are derived
     * at replay time (`taskNumberByTask`); this read only filters them to one
     * Workspace.
     */
    private taskNumbers;
    private hasActiveClaim;
    private hasActiveClaimFrom;
    private deriveResolvedTaskStatus;
    private deriveTaskStatus;
    private setMemberState;
    private assertActorForWorkspace;
    private assertHumanActor;
    private assertAssistantActor;
    private assertMemberActor;
    /** Shortest accepted UUID abbreviation after the branded prefix. */
    private static readonly MIN_REF_UUID_PREFIX;
    private isRefAbbreviationTail;
    /**
     * Full map key for one branded ref, tolerating a unique UUID abbreviation.
     * Exact refs win; an abbreviated ref (prefix plus at least 6 hex chars,
     * hyphens ignored) resolves only when it matches exactly one key. Returns
     * undefined for unknown or ambiguous refs so lenient callers can degrade
     * without throwing.
     */
    private uniqueRefKey;
    /** uniqueRefKey with the established unknown/ambiguous error contract and hints. */
    private requireRefKey;
    /** Agents strip the branded prefix or abbreviate UUIDs when echoing refs; point at the fix instead of a bare lookup failure. */
    private unknownRefHint;
    private requireTask;
    private requireThread;
    private channelRefForThread;
    private channelRefForThreadFrom;
    private threadContextForActor;
    private threadContextFrom;
    private requireChannel;
    /** Guard for every mutating or Channel-scoped surface flow: archived Channels reject. */
    private requireActiveChannel;
    /** Thread-mutation guard: the Channel owning the Thread must still be active. */
    private assertThreadChannelActive;
    private requireMember;
    private requireMemberChannel;
    private isChannelMember;
    private isChannelMemberFrom;
    /** Every Thread of the Channel, taskful or taskless — the scope both cleanup validators replay against. */
    private channelThreadRefs;
    private channelThreadRefsFrom;
    /** The Workspace authorization question: does this Member participate in this Workspace. */
    participatesIn(memberId: AgentTeamMemberId, workspaceId: WorkspaceId): boolean;
    private participatesInFrom;
    /** Every Workspace the Member participates in: the default first, then the rest sorted. */
    workspacesOf(memberId: AgentTeamMemberId): readonly WorkspaceId[];
    private workspacesOfFrom;
    /** Whether two Members share at least one Workspace participation — the handle-uniqueness scope. */
    private participationOverlapFrom;
    /** Every Thread in the Workspace — the scope a Workspace leave replays its cleanup against. */
    private workspaceThreadRefs;
    private workspaceThreadRefsFrom;
    private assertJoinableMember;
    private normalizeRecipients;
    private normalizeUnique;
    /**
     * Names a Message body may address in one Channel: every live Member of that
     * Channel plus the Human. A name outside this set stays prose, which is what
     * keeps an incidental name-drop from reaching someone the Channel cannot
     * deliver to.
     *
     * The Human is reachable under two names: the current display handle and the
     * permanent `human` alias, so a rename never silently orphans `@human`
     * (matching ignores case, and chips render the display name either way).
     * The alias yields when another candidate already answers to it, so one
     * written name never notifies two different Members; enrollment reserves the
     * literal, so that yield only ever covers data predating the reservation.
     */
    private mentionCandidatesFor;
    /**
     * Merge the `@Handle` mentions authored in `body` into an explicit recipient
     * set. Body mentions are the primary channel now: an Agent has no recipient
     * parameter to forget, and the same scan serves Human input typed by hand.
     * The result stays a plain recipient set, so every downstream projection —
     * delivery markers, chip rendering, confirmation — is unchanged.
     */
    private mergeBodyMentions;
    /**
     * Whether one Member has ever held Attention on one Thread. Committed Inbox
     * deltas append a follow/unfollow observation, and the live index covers the
     * Thread-creating Message whose initial Attention is never observed — so the
     * two together answer "was this Member ever part of this Thread" without
     * adding a second durable authority.
     */
    private everParticipated;
    private everParticipatedFrom;
    /**
     * Split the Agent recipients an existing Thread cannot deliver to: those the
     * body named that the Thread has never carried. The send still commits — a
     * text mention must never fail the write — and the author is told through the
     * result, because inviting a Member into an existing Thread stays a Human
     * decision.
     */
    private undeliverableRecipients;
    private normalizeDirection;
    private assertHandleAvailable;
    private assertHandleAvailableFrom;
    /** Provider route and model id are exact identifiers; only whitespace-only values are rejected. */
    private assertModelSelection;
    /**
     * Capability allow-list entries are exact identifiers (skill names,
     * reserved tool names); only whitespace-only values are rejected. Unknown
     * names are intent, not errors — committing must stay replayable across
     * Harness upgrades, so divergence is derived at activation instead.
     */
    private assertCapabilities;
    /** The task-start policy is the closed continue/fresh pair; the window override is an integer floored at 8192 tokens. */
    private assertContextControl;
    /**
     * Prompt profile commit rule: section names must be non-blank and the custom
     * paragraph must fit the UTF-8 byte bound, measured on the normalized form
     * that will be stored. The replay schema stays shape-only, so a tightened
     * commit rule can never make an old ledger unreplayable.
     */
    private assertPromptProfile;
    private initialization;
    private assertInitializationRecord;
    private assertSameInitialization;
    private assertSameChannelCreation;
    private assertSameMemberAdd;
    private assertSameMemberState;
    private assertSameMemberSessionRenewed;
    private assertSameMemberInterruptRecorded;
    private assertSameMemberInterruptResolved;
    private assertSameMemberSessionRolledOver;
    private assertSameChannelUpdate;
    private assertSameMemberUpdate;
    private assertSameChannelJoin;
    private assertSameChannelMemberRemoval;
    private assertSameWorkspaceJoin;
    private assertSameWorkspaceLeave;
    private assertSameChannelArchival;
    private assertSameDm;
    private dmResult;
    private assertSameMessage;
    private assertSameMessageEdit;
    private assertSameMessageRecall;
    /**
     * Resolve the optional sub-task parent of a Task creation: full or
     * unambiguous abbreviated ref, in this Workspace, same Channel as the new
     * Task, and still open. Cross-Channel parents would fork the per-Channel
     * numbering a Task row shows, so they are refused instead of silently
     * renumbered; a closed parent takes no new sub-tasks.
     */
    private resolveParentTaskRef;
    private assertSameReply;
    private assertSamePromotion;
    private assertSameClaim;
    private assertSameTask;
    private assertSameRemoval;
    private assertSameArchival;
    private assertSameAttention;
    private assertSameThreadRead;
    private sameTask;
    private sameTaskIdentity;
    private sameClaim;
    private sameClaimIdentity;
    private sameThread;
    private sameMemberIdentity;
    /** sameMemberIdentity minus the sessionId: every durable Member fact a session renewal must carry over unchanged. */
    private sameMemberFacts;
    private sameActor;
    private sameList;
    private attentionKey;
    private directMarkerKey;
    private activityMarkerKey;
    private addMembership;
    private addRef;
    private throwRequestCollision;
    private channelResult;
    private channelUpdateResult;
    private memberResult;
    /** The recorded value of one interrupt operation; the same shape the stack query and the replay return. */
    private interruptValue;
    private interruptResult;
    private interruptResolveResult;
    private joinResult;
    private channelMemberRemovalResult;
    private workspaceJoinResult;
    private workspaceLeaveResult;
    private channelArchivalResult;
    private messageResult;
    private replyResult;
    /** Ledger-side results stop short of `stoppedMembers`: the Host force-stop loop owns that field. */
    private messageEditResult;
    private messageRecallResult;
    private claimResult;
    private taskResult;
    private attentionResult;
    private promotionResult;
    /**
     * The Thread picture a read answers with, derived from the projection the
     * read resolved against. Committed reads, no-op reads and retries all share
     * this one derivation, so a read that writes nothing still returns the same
     * Attention, facts, watermark and unread count a committed one would.
     */
    private readPicture;
    private receipt;
    private removalResult;
    private archivalResult;
    private operationBase;
    private nextSequence;
    private ref;
    private committed;
    private resolved;
    private sortedRecords;
    /**
     * Repairs releases up to 0.1.9 whose Channel archival and Channel
     * member-removal inbox cleanup was scoped to taskful Threads only (the
     * collector read the Task projection), so archiving or member removal in a
     * Channel holding a taskless Thread with Attention or markers wrote an
     * incomplete inbox and every later load rejected the record, leaving the
     * profile unable to boot. Records carrying exactly that legacy cleanup are
     * repaired in memory the same way pre-envelope Thread reads are; any other
     * inbox still fails validation, so a forgery is not silently accepted.
     */
    private repairLegacyChannelCleanup;
    /** The pre-fix Channel Thread scope: only Threads carrying a Task. */
    private legacyChannelThreadRefs;
    /**
     * Ledgers written before message occurredAt existed store bare messages;
     * snapshot-shaped Thread reads resolve instants from the originating
     * operations. A receipt-shaped read carries no message at all, so it passes
     * through untouched — the load path must never touch a shape it does not
     * have, and it never writes either form back.
     */
    private normalizeOperation;
    private enqueue;
}
//# sourceMappingURL=ledger.d.ts.map