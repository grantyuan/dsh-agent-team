/**
 * Pure construction and parsing for the Prompt dialog's one-shot LLM
 * curation. The Host builds one bounded model call from the Member's live
 * prompt surface, private skills catalog, identity, and the Human's free-text
 * requirements, then parses the reply into a propose-only draft. Nothing here
 * touches the ledger — the proposal only ever backfills the dialog form, and
 * the Human commits (or discards) it through the normal member update. The
 * inputs are injectable by design: section texts and the requirements are
 * embedded verbatim, only bounded, so containment is propose-only parsing,
 * re-validation against the same snapshot, and Human review before anything
 * durable.
 *
 * @module @wowyuarm/dsh-agent-team/member-prompt-curation
 */
import type { RequestMessage } from '@deepseek-ai/dsh-llm';
/**
 * Hard wall-clock bound of the one-shot curation call. The Host races this
 * timeout against the client's cancellation signal so a stuck provider can
 * never pin the dialog (or a remote worker) for longer than one minute. The
 * clock starts before the input assembly, so the budget covers the skills
 * catalog read and the section assembly too, not only the model call.
 */
export declare const CURATE_TIMEOUT_MS = 60000;
/** Output token ceiling of the curation call; the proposal is small by design. */
export declare const CURATE_MAX_TOKENS = 4096;
/**
 * Per-section text cap inside the curation input: identity and boundaries
 * matter, not full section prose. Each truncated text ends with an ellipsis
 * so the model knows it saw a cut.
 */
export declare const CURATE_SECTION_TEXT_CAP = 1200;
/** Cap for the Human's free-text requirements inside the curation input. */
export declare const CURATE_REQUIREMENTS_CAP = 4000;
/** The custom role paragraph cap the durable edit already enforces. */
export declare const CURATE_PROMPT_BYTES = 8192;
/** One live prompt section as the curation input presents it. */
export interface CurateInputSection {
    readonly name: string;
    readonly text: string;
    /** Drop requests for a protected name are refused at consumption. */
    readonly isProtected: boolean;
    /** No current tool name maps to this section. */
    readonly proseOnly: boolean;
}
/** Everything the one-shot call sees about one Member. */
export interface CuratePromptInput {
    readonly handle: string;
    readonly description: string;
    /** The stored custom role paragraph, if any. */
    readonly currentParagraph?: string;
    /** The Member's private skills catalog names (bundled core skills first). */
    readonly skills: readonly string[];
    readonly sections: readonly CurateInputSection[];
    /** The Human's requirements, already capped by the caller or here. */
    readonly requirements: string;
}
/** The parsed model proposal; every field optional and client-reviewed. */
export interface CurateProposal {
    readonly droppedSectionNames?: readonly string[];
    readonly skillsAllow?: readonly string[];
    readonly customPrompt?: string;
}
/**
 * Leading sentence of the curation system line. Exported so the browser e2e
 * interceptor keys on the Host's own constant instead of a drifting copy.
 */
export declare const CURATE_SYSTEM_PREFIX = "You curate the system prompt of one AI team member.";
/**
 * Build the one-shot call: an identity-free system line plus one user message
 * carrying the bounded member facts and the requirements. Section texts and
 * the requirements are capped so a huge prompt surface cannot grow the call
 * without bound; the JSON shape instruction is explicit because the reply is
 * parsed defensively.
 */
export declare function buildCurateMessages(input: CuratePromptInput): {
    readonly system: string;
    readonly messages: readonly RequestMessage[];
};
/**
 * Parse the model reply defensively: tolerate Markdown fences, extract the
 * first JSON object, and type-guard every field. Unknown fields are ignored;
 * a wrong-typed field is dropped rather than fatal — except a `customPrompt`
 * over the byte cap, which is a contract violation worth failing loudly.
 * Dropped section names run through `protect` so a protected name can never
 * reach the dialog's drop set even if the model ignored its instruction.
 */
export declare function parseCurateProposal(text: string, protect: (name: string) => boolean): CurateProposal;
//# sourceMappingURL=member-prompt-curation.d.ts.map