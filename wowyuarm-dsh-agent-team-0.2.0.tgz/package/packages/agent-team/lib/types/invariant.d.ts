/**
 * Team-owned ledger divergence guard for `@wowyuarm/dsh-agent-team`.
 *
 * Harness retired its runtime invariant registry (`@deepseek-ai/dsh-invariants`,
 * DSH 0.2.1), so the check that used to be contributed to that registry now
 * mounts as a companion row of its own beside the Host. The ledger is Team
 * authority, so the guard that defends it is Team-owned too.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "agent-team-invariant";
/** Services required before the companion can validate Team state. */
export declare const inject: string[];
/** Install the ledger checks and the commit-driven replay. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=invariant.d.ts.map