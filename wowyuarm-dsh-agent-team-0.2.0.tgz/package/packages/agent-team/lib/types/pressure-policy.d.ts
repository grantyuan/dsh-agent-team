/**
 * Team-owned context pressure policy.
 *
 * The Team preset mounts `compaction-basic` with `auto: false`; this
 * coordinator owns both policy entry points instead — the proactive handoff
 * notice near the effective handoff budget and the forced CompactionEngine
 * reduction before any request at or above the effective hard limit — while
 * reusing the public CompactionEngine implementation. The hard-limit
 * translation lives in exactly one method; no caller re-derives it.
 *
 * The handoff-budget notice is an order, not advice. A Member that receives it
 * and keeps stepping without relieving its own context is given
 * {@link CONTEXT_PRESSURE_MANDATE_AFTER_STEPS} rounds to finish the atomic action
 * it was told to finish, then one reduction order, then
 * {@link CONTEXT_PRESSURE_ENFORCE_AFTER_STEPS} in total before the Host runs the
 * reduction itself — and a context it cannot prove back under the handoff budget
 * stops being the Member's problem to carry: the request is blocked and the
 * Member is handed to the supervision chain's fresh-context reset. Without that
 * consequence the notice was provably ignorable, and an ignoring Member burned
 * hours of failing turns before anything acted.
 *
 * Fail-closed rule: at the hard limit, a compaction that no-ops, throws, is
 * cancelled, or does not advance the durable surface must block the model
 * request (reject the step) rather than knowingly submit over the Team limit.
 * A blocked Member keeps its log and reports a recoverable error.
 * @module @wowyuarm/dsh-agent-team/pressure-policy
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { CompactionEngine } from '@deepseek-ai/dsh-compaction';
import type { AgentTeamMemberId } from './types.ts';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import { type SessionEventFold } from './session-event-cursor.ts';
/**
 * Stable summary of the one-shot rollover pressure notice. It is a durable
 * marker: the notice's own presence in a Session's log is what latches the
 * policy, so the wording is read back and must not drift.
 */
export declare const CONTEXT_PRESSURE_NOTICE_SUMMARY = "Context pressure: prepare a handoff";
/**
 * Stable summary of the mandate that follows a pressure notice the Member never
 * acted on: the same durable read-back rule as
 * {@link CONTEXT_PRESSURE_NOTICE_SUMMARY} — the mandate has been issued exactly
 * once per generation because this marker is in the Session's own log.
 */
export declare const CONTEXT_PRESSURE_MANDATE_SUMMARY = "Context pressure: reduce now or be reset";
/**
 * Model steps a Member is given after the pressure notice before the Host orders
 * the reduction. The notice tells the Member to finish the atomic action it is
 * in and then reduce; three further steps cover that action plus a memory write
 * and the reduction call themselves.
 */
export declare const CONTEXT_PRESSURE_MANDATE_AFTER_STEPS = 3;
/**
 * Model steps a Member is given, since the same notice, before the Host runs the
 * reduction itself. The count is cumulative, so the order issued past
 * {@link CONTEXT_PRESSURE_MANDATE_AFTER_STEPS} gets two steps of its own: the one
 * it names as its deadline, and one more for a reduction call that lands on a
 * step boundary.
 */
export declare const CONTEXT_PRESSURE_ENFORCE_AFTER_STEPS = 5;
/**
 * Whether one Member failure diagnostic is a pressure-policy request block:
 * the policy itself refused the model request — an unknown route capacity, a
 * failed or refused hard-limit compaction, a spent forced-compaction budget, an
 * unproven reduction, or a handoff-budget order the Member never acted on and
 * the Host could not carry out on its behalf either. A Member carrying such a
 * diagnostic has every later turn refused before any model call, so
 * continuation nudging cannot make progress; only a fresh context generation
 * (the supervision reset) or a changed route can. The manual compaction path's
 * failures do not block requests and do not classify.
 */
export declare function isPressureRequestBlockDiagnostic(diagnostic: string): boolean;
/** Whether one failure diagnostic says the context no longer fits its route. */
export declare function isContextCapacityFailureDiagnostic(diagnostic: string): boolean;
/**
 * Whether this Session's own span already carries the pressure notice: either
 * surfaced as a `user/message` or still queued in a durable
 * `agent/inbox/spliced` insert. Expressed as a fold rather than a scan because
 * the answer is monotone — once delivered it stays delivered for the
 * generation — so the cursor only ever has to read events it has not seen.
 */
export declare const PRESSURE_NOTICE_FOLD: SessionEventFold<boolean, SessionEvent>;
/**
 * The reduction mandate's durable delivery fold — the same monotone shape as
 * {@link PRESSURE_NOTICE_FOLD}, read back under its own summary so a restart
 * never re-issues an order this generation already carries.
 */
export declare const PRESSURE_MANDATE_FOLD: SessionEventFold<boolean, SessionEvent>;
/**
 * One pressure-notice text. The wording is the engine's — the same sentence a
 * fresh-context handoff is asked for through — so the notice and the rollover
 * tool cannot drift apart; Team supplies only its own labels and input shape.
 */
export declare function contextPressureNoticeText(input: {
    readonly usageTokens: number;
    readonly handoffAt: number;
    readonly hardLimit: number;
    readonly activeClaims: readonly string[];
    readonly runningJobs: readonly string[];
}): string;
/**
 * The reduction order that follows a pressure notice the Member never acted on.
 * Team's own wording, because the consequence is Team's: the notice asked, this
 * commands, and it names the two things the Member owes before its next model
 * step — persist what must survive, then reduce the context — and what happens
 * when a second warning is ignored as well.
 */
export declare function contextPressureMandateText(input: {
    readonly usageTokens: number;
    readonly handoffAt: number;
    readonly hardLimit: number;
    readonly activeClaims: readonly string[];
    readonly runningJobs: readonly string[];
}): string;
export interface PressurePolicyOptions {
    /** Resolve the live Agent of one Member. */
    readonly agentForMember: (memberId: AgentTeamMemberId) => Agent | undefined;
    /** Resolve the durable Member of one live Agent. */
    readonly memberForAgent: (agent: Agent) => {
        readonly memberId: AgentTeamMemberId;
        readonly sessionId: Agent['id'];
    } | undefined;
    /** Resolve the Member-scoped compaction engine. */
    readonly compactionForAgent: (agent: Agent) => CompactionEngine | undefined;
    /** Effective budgets for one Member's current route; undefined means the route window is unknown. */
    readonly limitsForAgent: (agent: Agent) => Promise<{
        readonly usageTokens: number;
        readonly hardLimit: number;
        readonly handoffAt: number;
    } | undefined> | {
        readonly usageTokens: number;
        readonly hardLimit: number;
        readonly handoffAt: number;
    } | undefined;
    /** The model-visible active-Claim labels for one Member's notice. */
    readonly activeClaimLabels: (memberId: AgentTeamMemberId) => readonly string[];
    /** The model-visible running-job labels for one Member's notice. */
    readonly runningJobLabels: (memberId: AgentTeamMemberId) => readonly string[];
    /** Report a Member failure with a recoverable diagnostic. */
    readonly failed: (memberId: AgentTeamMemberId, sessionId: Agent['id'], diagnostic: string) => void;
    /**
     * Report that a recorded request block has ended: a pre-step proved the
     * pressure receded below the hard limit, so a hard-limit block no longer
     * describes this Member's live Session. Absent, stale block records persist.
     */
    readonly healed?: (memberId: AgentTeamMemberId) => void;
    /**
     * Hand a Member whose context the Host cannot reduce in place to the
     * supervision coercion chain: the forced reduction failed, was refused by the
     * route, or left the pressure at or above the budget the Member was ordered to
     * get back under. The chain's step is the Host's fresh-context reset, so an
     * ignored warning ends with a new generation rather than another turn into the
     * same oversized context. Absent, the policy only blocks the request and waits
     * for the supervision pass to read the block.
     */
    readonly escalate?: (memberId: AgentTeamMemberId, diagnostic: string) => void;
    /**
     * The other-LLM summarizer fallback, run when the Member-scoped engine's
     * forced reduction throws: tries the Host catalog's other configured routes
     * (bounded) and reports whether the durable surface advanced. Absent, the
     * coordinator fails closed on the original failure exactly as before.
     */
    readonly compactWithFallback?: (agent: Agent, memberId: AgentTeamMemberId, signal: AbortSignal) => Promise<boolean>;
    /** Log one coordinator diagnostic. */
    readonly log: (message: string) => void;
}
export declare class PressurePolicyCoordinator {
    private readonly options;
    /**
     * Retry budget per agent for the current provider-overflow sequence.
     * Process-only by design: a restart re-earns one sequence per chain.
     */
    private readonly overflowRetries;
    /**
     * Forced hard-limit compactions already spent per agent in the current
     * recovery chain. Each successful model request or any observed dip below
     * the hard limit re-arms the budget; while the chain stays open, at most one
     * surface rewrite is attempted. Bounding the rewrite cadence is what keeps a
     * hard-limit Member from compacting on every step — each rewrite invalidates
     * the provider's prompt cache, so a compaction loop that never gets below the
     * limit would re-prefill the whole context per request.
     */
    private readonly forcedCompactions;
    /**
     * Agents whose current route refuses dsh compaction outright with the
     * `dsh_compaction_refused` marker: the routed proxy owns compression on
     * that lane and keeps requests under the real model window, so the policy
     * submits without dsh compaction instead of failing closed on a proof the
     * lane can never produce (raw dsh-side tokens never drop there).
     */
    private readonly proxyOwnedLanes;
    /**
     * Whether the one-shot notice was already delivered, folded incrementally per
     * Member. The scan below is a monotone "has this ever happened" fold over the
     * Session's own events, so a cursor can replace re-scanning the whole log on
     * every step; identity guarding falls back to a cold fold when the Member's
     * Session changed under the entry.
     */
    private readonly noticeSeen;
    /** The reduction order's own durable delivery latch, same fold idiom. */
    private readonly mandateSeen;
    /**
     * Model steps this policy has seen at or above the handoff budget since the
     * notice landed, per agent. Process-only by design like the retry budgets: a
     * restart re-earns the allowance, while the order and the enforcement it gates
     * stay durable facts of the Session through their own folds.
     */
    private readonly overBudgetSteps;
    /** Forced handoff-budget reductions already spent per agent in this episode. */
    private readonly forcedHandoffReductions;
    private disposed;
    constructor(options: PressurePolicyOptions);
    /**
     * The one-shot pressure notice is durable Session evidence, not process
     * state: a `CONTEXT_PRESSURE_NOTICE_SUMMARY` notice already surfaced as a
     * `user/message`, or still queued in a durable `agent/inbox/spliced`
     * insert (a steered notice surfaces only at the next step boundary, and a
     * Host restart replays the splice before surfacing), marks the current
     * generation as already notified. A resume or restart stays quiet; a
     * rollover starts a fresh Session whose own event span has no notice yet,
     * which is exactly the documented re-arm.
     */
    private noticeDelivered;
    /** Whether this generation already carries the reduction order. */
    private mandateDelivered;
    /** Advance one durable-delivery latch and return its folded value. */
    private advanceLatch;
    dispose(): void;
    /** A successful assistant response ends any open overflow-recovery sequence. */
    onAssistantMessage(agent: Agent): void;
    /**
     * Pre-step policy for one Member agent: below the handoff budget nothing
     * happens; at the handoff budget one structured notice per generation is
     * steered into the running turn; past the notice's allowance an order follows
     * that commands the reduction and the memory write; past the order's
     * allowance the Host runs the reduction itself; at the hard limit the request
     * is forced through compaction first and fails closed when that cannot be
     * proven. Returns the decision for the step: `continue` forwards, `reject`
     * blocks.
     */
    onPreStep(agent: Agent, signal: AbortSignal): Promise<{
        readonly kind: 'continue' | 'reject' | 'notice';
    }>;
    /** Steer one of this policy's own notices; a failed steer is logged, never fatal to the step. */
    private steerPressure;
    /**
     * The consequence of an ignored order: the Host runs the reduction the Member
     * would not run itself and requires the same proof every continuing request
     * needs — the measured pressure is now below the handoff budget. A lane whose
     * proxy owns compression is left alone, because its raw reading never drops
     * and the provider's own oversize refusal is what names a context there that
     * truly no longer fits; the supervision chain resets that one. Everywhere else
     * a reduction that throws, no-ops, cannot be measured, or lands still over the
     * budget blocks the request and hands the Member to that chain on the spot: a
     * Member that will not give its context up, and cannot be shrunk in place, is
     * given a fresh one rather than another turn into the same wall.
     * @returns whether the request may proceed.
     */
    private enforceHandoffReduction;
    /** Record the block this policy refuses the request with, and open the coercion chain on it. */
    private blockUnreducedContext;
    /**
     * Provider-overflow recovery: one bounded compact-and-retry sequence per
     * open failure chain. Returns whether the request may retry once.
     */
    onRequestError(agent: Agent, failure: {
        readonly code?: string;
    }, signal: AbortSignal): Promise<boolean>;
    /**
     * The one Team hard-limit translation: force a CompactionEngine reduction in
     * the current Agent/Session and prove the pressure actually dropped below the
     * hard limit before continuing. One rewrite is attempted per recovery chain —
     * a chain closes on a successful request or on any observed dip below the
     * limit — and a compaction that leaves the context at or above the limit
     * fails closed: submitting anyway would exceed the Team limit with a cache
     * the next rewrite invalidates, compounding into the compact-per-step loop
     * this bound exists to prevent. Background jobs are untouched — compaction
     * never cancels or discards them.
     * @returns whether the request may proceed.
     */
    private enforceHardLimit;
}
//# sourceMappingURL=pressure-policy.d.ts.map