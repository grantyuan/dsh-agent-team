/**
 * Team-owned provider-overflow recovery.
 *
 * The Team preset mounts `compaction-basic` with `auto: false`; this
 * coordinator owns the one reactive compaction entry point left. The Host
 * does not police context size: there is no pre-step usage ladder, no pressure
 * notice, no Host-forced reduction, and no request block. A Member manages its
 * own context through the rollover and checkpoint tools, and a failure that
 * actually surfaces feeds the supervision chain's failure counter — three
 * consecutive `agent/error` turns end in the fresh-context reset there.
 *
 * The one exception is the provider refusing a request because the context no
 * longer fits its route: one bounded compact-and-retry sequence per open
 * failure chain tries to save the request before the failure surfaces. The
 * retry stays bounded — one per chain, re-armed only by a successful request —
 * because each surface rewrite invalidates the provider's prompt cache, and a
 * compaction loop that never gets below the limit would re-prefill the whole
 * context per request.
 * @module @wowyuarm/dsh-agent-team/pressure-policy
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { CompactionEngine } from '@deepseek-ai/dsh-compaction';
import type { AgentTeamMemberId } from './types.ts';
export interface PressurePolicyOptions {
    /** Resolve the durable Member of one live Agent. */
    readonly memberForAgent: (agent: Agent) => {
        readonly memberId: AgentTeamMemberId;
        readonly sessionId: Agent['id'];
    } | undefined;
    /** Resolve the Member-scoped compaction engine. */
    readonly compactionForAgent: (agent: Agent) => CompactionEngine | undefined;
    /**
     * The other-LLM summarizer fallback, run when the Member-scoped engine's
     * overflow compaction throws: tries the Host catalog's other configured
     * routes (bounded) and reports whether the durable surface advanced. Absent,
     * the coordinator gives up on the original failure exactly as before.
     */
    readonly compactWithFallback?: (agent: Agent, memberId: AgentTeamMemberId, signal: AbortSignal) => Promise<boolean>;
    /** Log one coordinator diagnostic. */
    readonly log: (message: string) => void;
}
export declare class PressurePolicyCoordinator {
    private readonly options;
    /**
     * Retry budget per agent for the current provider-overflow sequence.
     * Process-only by design: a restart re-earns one sequence per chain.
     */
    private readonly overflowRetries;
    /**
     * Agents whose current route refuses dsh compaction outright with the
     * `dsh_compaction_refused` marker: the routed proxy owns compression on
     * that lane and keeps requests under the real model window, so no retry is
     * attempted there and the overflow surfaces instead — the supervision
     * failure counter owns what happens next.
     */
    private readonly proxyOwnedLanes;
    private disposed;
    constructor(options: PressurePolicyOptions);
    dispose(): void;
    /** A successful assistant response ends any open overflow-recovery sequence. */
    onAssistantMessage(agent: Agent): void;
    /**
     * Provider-overflow recovery: one bounded compact-and-retry sequence per
     * open failure chain. Returns whether the request may retry once.
     */
    onRequestError(agent: Agent, failure: {
        readonly code?: string;
    }, signal: AbortSignal): Promise<boolean>;
}
//# sourceMappingURL=pressure-policy.d.ts.map