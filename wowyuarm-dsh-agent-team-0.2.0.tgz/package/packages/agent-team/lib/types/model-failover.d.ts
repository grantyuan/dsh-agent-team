/**
 * LLM route failover policy for Team Members.
 *
 * A Member may pin an ordered list of backup routes (`modelFallbacks`). When
 * its live route keeps failing with provider-side errors a retry cannot fix —
 * rate limits, overload, transient network — the Host promotes the next backup
 * route on the Member's own session (`agent.model.select`), so work continues
 * on a usable API instead of burning context resets on a dead route. This
 * module owns only the counting policy and the notice texts; the Host owns the
 * session switch, the durable facts, and where the notices are posted.
 *
 * The streak is per route: switching to a backup starts that backup's own
 * budget, and a clean turn clears the current route's streak. A fresh
 * generation (activation, renewal, rollover) restarts at the pinned primary —
 * the recorded switch lives in the old session's log, not in the Member's
 * durable pin.
 *
 * @module @wowyuarm/dsh-agent-team/model-failover
 */
import type { AgentTeamModelSelection } from './types/entities.ts';
/** Consecutive recoverable route failures that trigger one promotion. */
export declare const MODEL_FAILOVER_THRESHOLD = 3;
/** Stable first line for the failover notices, like the other coordinator markers. */
export declare const MODEL_FAILOVER_MARKER = "LLM route failover:";
/** One Member's live failover memory. */
export interface RouteFailureState {
    /** `${provider}/${model}` of the route the streak counts against. */
    routeKey: string;
    consecutive: number;
    /** How many backups have already been promoted (also the next candidate index). */
    promoted: number;
    /** True while the promotion's session switch is in flight. */
    switching: boolean;
}
export declare function routeKeyOf(selection: AgentTeamModelSelection): string;
/**
 * Record one recoverable route failure. Returns the backup selection to
 * promote when the streak crosses the threshold (and marks the state
 * switching), or undefined to keep retrying the current route. A route change
 * observed between errors restarts the streak on the new route.
 */
export declare function noteRouteFailure(state: RouteFailureState | undefined, currentRoute: AgentTeamModelSelection, fallbacks: readonly AgentTeamModelSelection[]): {
    readonly next: RouteFailureState;
    readonly promote: AgentTeamModelSelection | undefined;
};
/** A clean turn clears the current route's streak; the promoted index stays. */
export declare function clearRouteStreak(state: RouteFailureState | undefined, currentRoute: AgentTeamModelSelection): RouteFailureState | undefined;
/** The session switch settled: release the latch. */
export declare function settlePromotion(state: RouteFailureState | undefined): RouteFailureState | undefined;
/**
 * The failover notice: what died, what replaced it, and the standing offer to
 * the Human — the pinned primary is unchanged, so a renewal or a manual edit
 * returns the Member to it. Plain text with the `@human` mention, like every
 * other coordinator notice.
 */
export declare function modelFailoverNoticeText(input: {
    readonly handle: string;
    readonly failed: AgentTeamModelSelection;
    readonly promoted: AgentTeamModelSelection;
    readonly candidateIndex: number;
    readonly candidateCount: number;
}): string;
/**
 * The exhausted-latch notice: supervision's automatic remedies are spent and
 * the Member is the Human's to take over. This is the durable counterpart of
 * the process-local latch — without it the give-up would be invisible.
 */
export declare function supervisionExhaustedNoticeText(input: {
    readonly handle: string;
    readonly trigger: string;
}): string;
//# sourceMappingURL=model-failover.d.ts.map