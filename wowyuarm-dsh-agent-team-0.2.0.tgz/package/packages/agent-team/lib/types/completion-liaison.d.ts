/**
 * Team-owned completion liaison.
 *
 * The continuation watcher asks one designated leader when the whole Team has
 * gone quiet. This policy covers the narrower per-Member moment the operator
 * asked for: a Member finishes its work (a `completed` stop whose last round
 * carried the 任务结束 marker) and goes idle. At that point:
 *
 * - if the Workspace has an enabled designated leader other than the Member
 *   itself, and the Member addressed no report to that leader after finishing
 *   (a Channel message naming the leader or a DM — the scan runs over the
 *   ledger tail since the completion), the Host posts one report-check notice
 *   for the leader, so unfinished coordination surfaces immediately instead
 *   of waiting for the whole Team to idle;
 * - if the Workspace has no such leader, the Host pushes the Workspace's
 *   open Tasks directly to the Member itself and lets it decide autonomously
 *   whether to continue. The push states one contract: a Member that declines
 *   begins its final reply with the exact words 拒绝继续. When that refusal
 *   lands at the Member's next marker stop, the Host stops pushing Tasks to
 *   the Member for the process lifetime and relays the Member's own feedback
 *   to `@human` in the Channel — the Human, not the policy, arbitrates next.
 *
 * Evaluation is a periodic pass (like supervision and the continuation
 * watcher), armed behind the same restore gate, so a report that arrives
 * seconds after the completion lands inside the grace window and no notice
 * fires. A cooldown latch per (Member, Workspace, branch) keeps a Member that
 * stops round after round without reporting from re-prompting every pass.
 *
 * Every state here is process-local by design — episodes, decisions, the
 * refused set, and latches are reconstructible, exactly like the watcher's
 * counters — while every effect (the posted notices and the relayed feedback)
 * is an ordinary ledger Message operation. A restart re-earns the policy's
 * memory: a previously refused Member may be pushed once more and refuses
 * again, which the operator reads as acceptable churn against the alternative
 * of a new ledger fact kind.
 * @module @wowyuarm/dsh-agent-team/completion-liaison
 */
import type { AgentTeamContextCheckpointRef, AgentTeamInterruptRef, AgentTeamMemberId } from './types.ts';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace';
import type { ContinuationTask } from './continuation-watcher.ts';
/**
 * The exact opening words a Member must use to decline a Task push. Stable:
 * it is quoted verbatim into the push body, so the instruction the model
 * reads and the check that acts on it never drift apart.
 */
export declare const LIAISON_REFUSAL_PHRASE = "\u62D2\u7EDD\u7EE7\u7EED";
/** How often the liaison pass runs once the Host has restored its Members. */
export declare const LIAISON_INTERVAL_MS: number;
/**
 * How long a finished Member gets to address its own report before the
 * liaison acts. Reports usually ride inside the completion round or follow a
 * breath later; the window keeps the race honest without delaying a real
 * gap by more than one pass.
 */
export declare const LIAISON_REPORT_GRACE_MS = 60000;
/** A repeat notice for the same (Member, Workspace, branch) never fires inside this window. */
export declare const LIAISON_COOLDOWN_MS: number;
/** An unevaluated completion episode is dropped once the Member has been busy (or gone) this long. */
export declare const LIAISON_EPISODE_TTL_MS: number;
/** A Task push whose decision never reached a marker stop is forgotten after this long. */
export declare const LIAISON_DECISION_TTL_MS: number;
/** The refused Member's reply quoted into the `@human` feedback, bounded. */
export declare const LIAISON_FEEDBACK_MAX_CHARS = 400;
/** Stable first lines: they name the notice in a Channel and match the watcher's marker convention. */
export declare const LIAISON_REPORT_CHECK_MARKER = "Team report check:";
export declare const LIAISON_TASK_PUSH_MARKER = "Task push (no Team leader designated):";
export declare const LIAISON_DECLINED_PUSH_MARKER = "Task push declined:";
export declare const LIAISON_INTERRUPT_PUSH_MARKER = "Interrupt resume check:";
/**
 * Stable summary of the private resume notice steered into the finished
 * Member's own Session. The context projection reads it as a pure reminder —
 * it never anchors a timeline boundary — and the text restates the full
 * current stack on every delivery, so an older unread instance carries the
 * same information as the newest.
 */
export declare const INTERRUPT_PUSH_SUMMARY = "Interrupt resume check: pending interrupted sessions await continuation";
/** One pending interrupt as the resume lane presents it to the Member. */
export interface LiaisonInterrupt {
    readonly interruptRef: AgentTeamInterruptRef;
    readonly checkpointRef: AgentTeamContextCheckpointRef;
    readonly label: string;
}
/** The enabled designated leader one notice addresses. */
export interface LiaisonLeader {
    readonly memberId: AgentTeamMemberId;
    readonly handle: string;
}
export interface CompletionLiaisonOptions {
    /** The Workspaces one Member participates in, at evaluation time. */
    readonly workspacesOf: (memberId: AgentTeamMemberId) => readonly WorkspaceId[];
    /** Current presence of one Member. */
    readonly presenceOf: (memberId: AgentTeamMemberId) => 'available' | 'working' | 'error' | 'unavailable';
    /** The enabled designated leader of one Workspace, or undefined. */
    readonly leaderOf: (workspaceId: WorkspaceId) => LiaisonLeader | undefined;
    /** True when the Member addressed the Leader (a Channel message naming them or a DM) at or after the completion. */
    readonly reportedToLeaderSince: (memberId: AgentTeamMemberId, leaderId: AgentTeamMemberId, sinceSequence: number) => boolean;
    /** The Workspace's open Tasks at pass time; an empty list never pushes. */
    readonly openTasksIn: (workspaceId: WorkspaceId) => readonly ContinuationTask[];
    /**
     * The Member's pending interrupt stack, newest first — read from the
     * durable ledger projection, so the resume drive survives resets and
     * restarts. An empty list means the lane is silent for this Member.
     */
    readonly interruptsOf: (memberId: AgentTeamMemberId) => readonly LiaisonInterrupt[];
    /** The Member's handle for message bodies; undefined once the Member left the roster. */
    readonly handleOf: (memberId: AgentTeamMemberId) => string | undefined;
    /**
     * Steer the private resume notice into the finished Member's own Session
     * (a runtime delivery like the context-reset notice, never a ledger
     * Message). A throw is logged and the lane stays retryable.
     */
    readonly pushInterrupts: (input: {
        readonly memberId: AgentTeamMemberId;
        readonly memberHandle: string;
        readonly interrupts: readonly LiaisonInterrupt[];
    }) => Promise<void>;
    /** Post the report-check notice for the leader. A throw is logged; the cooldown still latches. */
    readonly notifyLeader: (input: {
        readonly memberId: AgentTeamMemberId;
        readonly memberHandle: string;
        readonly workspaceId: WorkspaceId;
        readonly leader: LiaisonLeader;
    }) => Promise<void>;
    /** Post the open-Task push addressed to the Member itself — only ever a Member that is not the Workspace's designated Leader. */
    readonly pushTasks: (input: {
        readonly memberId: AgentTeamMemberId;
        readonly memberHandle: string;
        readonly workspaceId: WorkspaceId;
        readonly tasks: readonly ContinuationTask[];
    }) => Promise<void>;
    /** Relay a refusing Member's own feedback to `@human` in the Channel. */
    readonly notifyHumanFeedback: (input: {
        readonly memberId: AgentTeamMemberId;
        readonly memberHandle: string;
        readonly workspaceId: WorkspaceId;
        readonly feedbackText: string;
    }) => Promise<void>;
    /** Log one coordinator diagnostic. */
    readonly log: (message: string) => void;
    readonly intervalMs?: number;
    readonly graceMs?: number;
    readonly cooldownMs?: number;
    readonly episodeTtlMs?: number;
    readonly decisionTtlMs?: number;
    readonly now?: () => number;
}
/**
 * The liaison pass over the three maps above: expire stale decisions, then
 * evaluate episodes whose Member has stayed idle past the grace window.
 * Overlapping passes are skipped, never queued — like every other Host pass.
 */
export declare class CompletionLiaison {
    private readonly options;
    private readonly episodes;
    private readonly decisions;
    private readonly refused;
    private readonly latched;
    private readonly intervalMs;
    private readonly graceMs;
    private readonly cooldownMs;
    private readonly episodeTtlMs;
    private readonly decisionTtlMs;
    private readonly now;
    private timer;
    private passRunning;
    private disposed;
    constructor(options: CompletionLiaisonOptions);
    /** Begin the periodic pass; called once the Host has restored every Member. */
    start(): void;
    /**
     * Observe one marker-completed stop: it closes any open Task-push decision
     * (a captured refusal is relayed and suppresses all later pushes for this
     * process) and opens one fresh report-check episode. `completedAt` carries
     * the stop's own timestamp for a boot-retroactive episode — a Member whose
     * marker stop was cut across a Host restart still earns its report check
     * once the new process is watching; live callers leave it at now.
     */
    onCompletedStop(memberId: AgentTeamMemberId, sinceSequence: number, completedAt?: number): void;
    /**
     * Observe one assistant response: while a Task push awaits its decision,
     * a reply that opens with the exact refusal phrase records the refusal
     * verbatim (bounded). Only the reply's opening carries the contract — an
     * echo of the phrase mid-sentence stays prose.
     */
    onAssistantText(memberId: AgentTeamMemberId, text: string): void;
    /** One pass; a test or an operator may drive it directly with a chosen clock. */
    runPass(now?: number): Promise<void>;
    dispose(): void;
    /** The per-Workspace branch for one finished Member. */
    private evaluateNow;
    private latchedFor;
    private latch;
    /** Fire-and-forget a delivery: a throw is logged, never rethrown into the pass. */
    private fire;
}
/** The report-check notice: the leader is told a teammate finished, idled, and owes a report. */
export declare function liaisonReportCheckText(input: {
    readonly leaderHandle: string;
    readonly memberHandle: string;
}): string;
/**
 * The private resume notice: the Member that just closed a task is told its
 * own interrupted stack, newest first — the LIFO order the persona's
 * interruption protocol resumes in. The refs are printed bare (never in the
 * `Thread: <ref>` shape a boundary fold would anchor on), and every delivery
 * restates the full current stack.
 */
export declare function liaisonResumePushText(input: {
    readonly interrupts: readonly LiaisonInterrupt[];
}): string;
/** The Task push: the Member owns the decision to continue. */
export declare function liaisonTaskPushText(input: {
    readonly memberHandle: string;
    readonly tasks: readonly ContinuationTask[];
}): string;
/**
 * The @human relay of a declined push, quoting the Member's own feedback. It
 * posts under the refusing Member's own voice (the auto-prune notice shape):
 * a Human-voiced message could never deliver an `@human` mention to itself,
 * and the decision being relayed is the Member's own.
 */
export declare function liaisonFeedbackText(input: {
    readonly feedbackText: string;
}): string;
//# sourceMappingURL=completion-liaison.d.ts.map