/**
 * Single-writer fence for the Agent Team ledger.
 *
 * The ledger authority assumes exactly one AgentTeam host writes the domain:
 * `nextSequence` is an in-memory counter and the Harness storage domain
 * performs no cross-process or cross-context coordination (its contract
 * declares cross-process ownership out of scope). Two live ledgers over one
 * storage file therefore interleave and fork the operation chain at the first
 * shared write — which fail-closes only at the next replay. A patch-reload
 * that leaks its old service instance is enough to create that state, so the
 * fence enforces the single-writer rule at the Team layer:
 *
 * - claim-on-mount: the newest holder takes authority unconditionally, so a
 *   legitimate remount is never blocked by the instance it replaces;
 * - superseded holders stop: every earlier holder in the same process is
 *   marked through a module registry, and any holder elsewhere through the
 *   lock-file nonce, before their next ledger call commits anything.
 *
 * The check is per ledger call, so the residual race window is one in-flight
 * commit, not an ongoing fork; closing that window completely would need
 * compare-and-swap at the storage layer, which the Harness declares out of
 * scope. The lock lives in the directory named by the Host row's
 * composition-only `ledgerDirectory` config, shipped in the bundle patch
 * beside the SQLite ledger route; a Host without that config is unfenced.
 * @module
 */
/** One host instance's claim on the ledger's single write authority. */
export declare class LedgerFence {
    readonly lockPath: string;
    readonly nonce: `${string}-${string}-${string}-${string}-${string}`;
    private superseded;
    constructor(lockPath: string);
    /**
     * Take write authority for this instance: last claim wins. Any earlier fence
     * on the same path — old patch-reload survivor included — is marked
     * superseded and its next ledger call stops before committing.
     */
    claim(): Promise<void>;
    /**
     * Whether this instance still owns the authority. The registry check is the
     * in-process fast path; the file nonce check is what stops a holder that a
     * different process (or context) overwrote. A missing or foreign lock is
     * never treated as a transient read error: losing the read is losing the
     * write.
     */
    owns(): Promise<boolean>;
    /**
     * Clean hand-off on dispose: the holder removes its own lock and nothing
     * else. A fence already superseded by a newer claim leaves the newer
     * holder's file untouched.
     */
    release(): Promise<void>;
    markSuperseded(): void;
}
/** The fence for the dshHome storage directory that hosts the ledger domain. */
export declare function ledgerFenceFor(storageDirectory: string): LedgerFence;
//# sourceMappingURL=ledger-fence.d.ts.map