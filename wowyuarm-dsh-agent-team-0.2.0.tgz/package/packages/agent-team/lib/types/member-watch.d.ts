/**
 * Team-owned Member watch monitor.
 *
 * A designated leader can place a standing watch over one teammate with the
 * `team_watch` tool. The watch itself is durable ledger state (an ordinary
 * `team/member-watch-started` operation), so a restart re-reads who is watching
 * whom instead of forgetting the leader's standing instruction; this module is
 * only the sampling policy on top of it.
 *
 * Each pass samples every active watch at its own cadence and reports back to
 * the watching leader when something the leader would want to know changed:
 *
 * - the observed state moved (healthy / settling / stopped), which covers
 *   running, idle, failed and unavailable in the vocabulary supervision uses;
 * - the state has lasted longer than the watch's stall threshold — "stopped
 *   for five minutes" is one notice, not one per pass;
 * - the target picked up or dropped running Tasks.
 *
 * Every notice is an ordinary ledger Message from the Team Assistant to the
 * leader, so it lands in the leader's Inbox and its Thread like any other Team
 * fact. Process state here (last sample, last state, per-episode stall latch)
 * is deliberately process-local and reconstructible: a restart re-samples and
 * re-reports the current state once, which reads as a fresh baseline rather
 * than as lost history.
 *
 * @module @wowyuarm/dsh-agent-team/member-watch
 */
import type { AgentTeamMemberId, AgentTeamMemberWatch } from './types.ts';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace';
/** How often the watch pass runs once the Host has restored its Members. */
export declare const MEMBER_WATCH_PASS_INTERVAL_MS: number;
/** Stable first line: it names the notice in the leader's Inbox and matches the other coordinator markers. */
export declare const MEMBER_WATCH_MARKER = "Team watch:";
/** One running Task as the watch notice lists it. */
export interface MemberWatchTask {
    readonly taskRef: string;
    readonly taskNumber?: number;
    readonly status: string;
    readonly subject: string;
}
/** One observation of a watched Member, read fresh at each sample. */
export interface MemberWatchSample {
    /** The supervision state: the same three words the leader's supervision panel reads. */
    readonly state: 'healthy' | 'settling' | 'stopped';
    readonly presence: 'available' | 'working' | 'error' | 'unavailable';
    /** Human-readable diagnostic when the Member is not healthy. */
    readonly diagnostic?: string;
    /** Tokens currently in the Member's context, when the meter could measure them. */
    readonly contextTokens?: number;
    /** The route's effective context window, when it is known. */
    readonly contextWindow?: number;
    /** Completed conversation turns across the Member's rollover lineage. */
    readonly turns: number;
    /** The Tasks the Member currently holds, in Task-list order. */
    readonly tasks: readonly MemberWatchTask[];
}
/** One leader-facing notice the monitor emits. */
export interface MemberWatchNotice {
    readonly watch: AgentTeamMemberWatch;
    readonly leaderMemberId: AgentTeamMemberId;
    readonly memberId: AgentTeamMemberId;
    readonly workspaceId: WorkspaceId;
    /** The watching leader's handle: the notice's mention target. */
    readonly leaderHandle: string;
    /** The watched Member's handle, as the notice names it. */
    readonly handle: string;
    /** 'transition' | 'stalled' | 'tasks' — why this notice fired. */
    readonly reason: 'transition' | 'stalled' | 'tasks';
    readonly sample: MemberWatchSample;
    /** How long the sampled state has lasted at notice time. */
    readonly stateMinutes: number;
    /** True on the first sample of a process: the baseline, not a change. */
    readonly baseline: boolean;
}
export interface MemberWatchMonitorOptions {
    /** Every active watch, oldest first — the durable read the pass iterates. */
    readonly watches: () => readonly AgentTeamMemberWatch[];
    /** The Member's handle for the notice body; undefined once the Member left the roster. */
    readonly handleOf: (memberId: AgentTeamMemberId) => string | undefined;
    /** The watching leader's handle: the notice wakes that Member by mention. */
    readonly leaderHandleOf: (memberId: AgentTeamMemberId) => string | undefined;
    /** One fresh observation of the watched Member, or undefined when it cannot be read. */
    readonly sampleOf: (memberId: AgentTeamMemberId, workspaceId: WorkspaceId) => Promise<MemberWatchSample | undefined>;
    /** Post the notice to the watching leader. A throw is logged and the next pass retries. */
    readonly notify: (notice: MemberWatchNotice) => Promise<void>;
    /** Log one coordinator diagnostic. */
    readonly log: (message: string) => void;
    readonly intervalMs?: number;
    readonly now?: () => number;
}
/**
 * The periodic watch pass. Overlapping passes are skipped, never queued — the
 * same contract every other Host pass keeps.
 */
export declare class MemberWatchMonitor {
    private readonly options;
    private readonly memories;
    private readonly intervalMs;
    private readonly now;
    private timer;
    private passRunning;
    private disposed;
    constructor(options: MemberWatchMonitorOptions);
    /** Begin the periodic pass; called once the Host has restored every Member. */
    start(): void;
    /** One pass; a test or an operator may drive it directly with a chosen clock. */
    runPass(now?: number): Promise<void>;
    dispose(): void;
    private sample;
    private sameTasks;
    /** Fire one notice: a throw is logged, never rethrown into the pass. */
    private fire;
}
/** The leader-facing watch notice: one line naming the reason, then the observed facts. */
export declare function memberWatchNoticeText(input: MemberWatchNotice): string;
//# sourceMappingURL=member-watch.d.ts.map