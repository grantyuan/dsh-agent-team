/**
 * The external-agent HTTP gateway: one more transport into the Team Host,
 * beside the Remote (the Web Client) and the member tools (model calls). It
 * serves external harnesses that have no live Session here — they join as
 * Members whose sessions never activate and collaborate by polling. Authority
 * stays in the ledger: every route forwards to a member-keyed Host entry
 * point (see `AgentTeamExternalCore`), and the gateway holds no Team facts of
 * its own.
 *
 * Auth rests on one boot secret. The join route demands the secret as its
 * bearer token; each Member's credential is `HMAC-SHA256(secret, memberId)` —
 * stateless, restart-stable, and per-Member, so one leaked member token
 * cannot act as another. Whoever holds the boot secret can derive any member
 * token: that is the accepted trust model for a single-operator localhost
 * deployment, and binding the listener beyond localhost means accepting it
 * for a wider network.
 */
import type { AgentTeamAddExternalMemberRequest, AgentTeamAddMemberResult, AgentTeamDmRequest, AgentTeamDmResult, AgentTeamExternalContextResult, AgentTeamHeartbeatRequest, AgentTeamInbox, AgentTeamJobMessageResult, AgentTeamMemberId, AgentTeamReplyRequest, AgentTeamReplyResult, AgentTeamSendMessageRequest, AgentTeamSendMessageResult, AgentTeamThreadHistory, AgentTeamThreadHistoryRequest, AgentTeamThreadReadRequest, AgentTeamThreadReadResult, AgentTeamView, AgentTeamViewRequest } from './types.ts';
export declare const EXTERNAL_API_DEFAULT_PORT = 43110;
/**
 * The member-keyed Host surface the gateway forwards to — the structural
 * subset of the Team Host the gateway actually needs. The Host satisfies it
 * directly; tests substitute a ledger-backed adapter.
 */
export interface AgentTeamExternalCore {
    addExternalMember(request: AgentTeamAddExternalMemberRequest): Promise<AgentTeamAddMemberResult>;
    inboxForMember(memberId: AgentTeamMemberId, request: {
        readonly workspaceId: AgentTeamViewRequest['workspaceId'];
        readonly limit?: number;
    }): AgentTeamInbox;
    viewForMember(memberId: AgentTeamMemberId, request: AgentTeamViewRequest): AgentTeamView;
    readThreadForMember(memberId: AgentTeamMemberId, request: AgentTeamThreadReadRequest): Promise<AgentTeamThreadReadResult>;
    threadHistoryForMember(memberId: AgentTeamMemberId, request: AgentTeamThreadHistoryRequest): AgentTeamThreadHistory;
    sendMessageForMember(memberId: AgentTeamMemberId, request: AgentTeamSendMessageRequest): Promise<AgentTeamSendMessageResult>;
    replyForMember(memberId: AgentTeamMemberId, request: AgentTeamReplyRequest): Promise<AgentTeamReplyResult>;
    /**
     * Record one heartbeat (activity note + bounded conversation snapshot).
     * Latest-wins per Member; the Host keeps it process-local and derives the
     * Member's presence freshness from it.
     */
    heartbeatForMember(memberId: AgentTeamMemberId, request: AgentTeamHeartbeatRequest): Promise<AgentTeamExternalContextResult>;
    /**
     * The member's DM poll: DMs reach internal members through their live
     * sessions and never enter the Inbox, so this is how an external member
     * ever sees one. Ascending, cursor-keyed by ledger sequence.
     */
    dmsForMember(memberId: AgentTeamMemberId, request: {
        readonly workspaceId: AgentTeamViewRequest['workspaceId'];
        readonly afterSequence?: number;
        readonly limit?: number;
    }): {
        readonly dms: readonly {
            readonly operationId: string;
            readonly sequence: number;
            readonly occurredAt: string;
            readonly direction: 'in' | 'out';
            readonly peerMemberId: AgentTeamMemberId;
            readonly body: string;
        }[];
        readonly hasMore: boolean;
    };
    /**
     * DM commit for an external sender. A recipient with no live session yields
     * the recorded-not-delivered outcome (the tool surface's shape), never a
     * thrown delivery error: the gateway maps results to statuses, and a DM
     * that reached the ledger durably is a 200, not a failure.
     */
    dmForMember(memberId: AgentTeamMemberId, request: AgentTeamDmRequest): Promise<AgentTeamDmResult | AgentTeamExternalDmUndelivered>;
    /**
     * One background job's script report, authenticated by the job token the
     * Host spawned the child with (never a member credential). The Host owns
     * token validation; a throw here is the gateway's 401/404.
     */
    jobMessageForJob(jobId: string, token: string, body: string): Promise<AgentTeamJobMessageResult>;
}
/** One DM that reached the ledger but found no live session to wake. */
export interface AgentTeamExternalDmUndelivered {
    readonly kind: 'dm-sent';
    readonly recipientMemberId: AgentTeamMemberId;
    readonly recipientHandle: string;
    readonly delivered: false;
    readonly deliveryNote: string;
}
/** The join response: the caller's durable identity plus its derived credential. */
export interface AgentTeamExternalJoinResult {
    readonly memberId: AgentTeamMemberId;
    readonly handle: string;
    readonly token: string;
    readonly workspaceIds: readonly string[];
}
export interface AgentTeamExternalApiOptions {
    readonly port: number;
    readonly token: string;
    readonly bind?: string;
}
export declare class AgentTeamExternalApi {
    private readonly core;
    private readonly options;
    private server;
    constructor(core: AgentTeamExternalCore, options: AgentTeamExternalApiOptions);
    /** Bind and listen; a bind failure propagates so the Host boot fails fast. */
    start(): Promise<this>;
    /** The resolved listen port once bound (an ephemeral port resolves at listen time). */
    get boundPort(): number | undefined;
    stop(): Promise<void>;
    /** The per-Member credential: stateless, so it survives restarts without a token store. */
    private memberToken;
    /** One external operation id, namespaced per Member; `clientRequestId` makes a retried send land once. */
    private requestId;
    private handle;
    /** Constant-time credential checks; the member header and bearer must pair. */
    private authenticate;
    private bearerOf;
    private join;
    /**
     * A script's progress report for one background job. The bearer is the job
     * token (not a member credential); the Host validates it against the live
     * job. A body bound keeps a chatty script from flooding the Channel.
     */
    private jobMessage;
    private sendMessage;
    /** A committed send is 200; every ledger rejection keeps its kind on 409. */
    private messageOutcome;
    /** Heartbeat payload bounds live here so a bad beat is a 400, not a host error. */
    private heartbeatOf;
    private threadRequest;
    private serveClientFile;
    private readJsonBody;
    private positiveInt;
    /** A sequence cursor: a safe non-negative integer, 0 meaning from the beginning. */
    private cursorInt;
    private optionalPositiveInt;
    private respond;
}
/** A client-visible rejection with its HTTP status decided at the boundary. */
export declare class RequestError extends Error {
    readonly status: number;
    readonly kind: string;
    constructor(status: number, kind: string, message: string);
}
//# sourceMappingURL=external-api.d.ts.map