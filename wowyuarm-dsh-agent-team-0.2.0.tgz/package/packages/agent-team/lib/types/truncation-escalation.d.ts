/**
 * Team-owned output-truncation escalation.
 *
 * The response guard heals a Member that stops by itself mid-work. This policy
 * covers the stop the provider forces instead: a turn that ends at the
 * per-request output-token cap (`turn/end` reason `max-tokens`). The Member's
 * reply is cut off and the partial answer stays in its Session; the guard's
 * bounded in-loop nudges may spend themselves re-running one oversized answer
 * that hits the cap again, and when they stand down the Member simply sits
 * stopped — the same call the Web UI offers the Human as "send continue".
 * Escalation therefore wakes the Workspace's designated leader
 * (`member.leader`) to decide what happens to the Member: order a chunked
 * restart, reassign the work, or leave it stopped for the Human.
 *
 * One episode per Member: the truncation stop delivers once to every
 * Workspace where an enabled leader other than the Member herself is
 * designated, then latches per (Member, Workspace) for
 * {@link TRUNCATION_ESCALATION_COOLDOWN_MS} — a Member that keeps truncating
 * inside one window is the same unresolved situation, not new information. A
 * clean marker stop closes the episode, so the next truncation escalates
 * fresh. A Member with no eligible leader anywhere logs once per episode
 * instead of spamming every stop.
 *
 * Episodes and latches are process-local, exactly like the watcher's
 * counters, and every notice is an ordinary ledger Message, so a crash around
 * a delivery replays as a normal ledger. Deliberate boundary: the activation
 * tail-scan never re-opens a truncated turn across a restart — the cap is
 * reached while the Host is watching, and a Member restored over old
 * truncated work stays quiet until it moves again.
 * @module @wowyuarm/dsh-agent-team/truncation-escalation
 */
import type { AgentTeamMemberId } from './types.ts';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace';
/** A repeat escalation for the same (Member, Workspace) never fires inside this window. */
export declare const TRUNCATION_ESCALATION_COOLDOWN_MS: number;
/**
 * Stable first-line marker of the escalation notice. It names the notice in a
 * Channel and follows the watcher's and liaison's marker convention.
 */
export declare const TRUNCATION_ESCALATION_MARKER = "Output truncation check:";
/** The enabled designated leader one escalation addresses. */
export interface TruncationLeader {
    readonly memberId: AgentTeamMemberId;
    readonly handle: string;
}
export interface TruncationEscalationOptions {
    /** The Workspaces one Member participates in, at stop time. */
    readonly workspacesOf: (memberId: AgentTeamMemberId) => readonly WorkspaceId[];
    /** The enabled designated leader of one Workspace, or undefined. */
    readonly leaderOf: (workspaceId: WorkspaceId) => TruncationLeader | undefined;
    /** The Member's handle for message bodies; undefined once the Member left the roster. */
    readonly handleOf: (memberId: AgentTeamMemberId) => string | undefined;
    /** Post the escalation notice for one leader. A throw is logged; the latch still holds. */
    readonly notify: (input: {
        readonly memberId: AgentTeamMemberId;
        readonly memberHandle: string;
        readonly workspaceId: WorkspaceId;
        readonly leader: TruncationLeader;
    }) => Promise<void>;
    /** Log one coordinator diagnostic. */
    readonly log: (message: string) => void;
    readonly cooldownMs?: number;
    /** Clock seam for the cooldown; tests drive it directly. */
    readonly now?: () => number;
}
/**
 * The event-driven policy behind {@link truncationEscalationText}: called
 * from the Host's `turn/end` observation, it never runs a pass of its own.
 */
export declare class TruncationEscalator {
    private readonly options;
    private readonly latched;
    private readonly missingLeaderLogged;
    private readonly cooldownMs;
    private readonly now;
    private disposed;
    constructor(options: TruncationEscalationOptions);
    /** Observe one output-token-cap stop and escalate it to the eligible leaders. */
    onTruncatedStop(memberId: AgentTeamMemberId): void;
    /** A clean marker stop closes the Member's episode: the next truncation is a fresh event. */
    onCleanStop(memberId: AgentTeamMemberId): void;
    dispose(): void;
    private latch;
    /** Fire-and-forget a delivery: a throw is logged, never rethrown into the event listener. */
    private fire;
}
/**
 * The escalation notice: posted by the Host in the Team Assistant's voice into
 * the leader's Channel, it names the truncated Member and states the one
 * expectation — the leader decides what happens to it. The `@` mention
 * delivers through the ordinary Inbox path, waking the leader into a turn.
 */
export declare function truncationEscalationText(input: {
    readonly leaderHandle: string;
    readonly memberHandle: string;
}): string;
//# sourceMappingURL=truncation-escalation.d.ts.map