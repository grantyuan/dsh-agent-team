/**
 * Pure construction and parsing for the Thread digest — the one-shot LLM call
 * that gives the Human a plain-language recap of a whole Thread, so opening a
 * message answers 「what happened and what do I need to decide」 before the
 * timeline is read. The same propose-only shape as Prompt curation: nothing
 * here touches the ledger, the digest never becomes a Team fact, and the only
 * durable action a reader can take from it is a normal reply the Client sends
 * through the existing write path.
 *
 * Inputs are injectable by design: message bodies and author handles are
 * embedded verbatim, only bounded, so a long Thread cannot grow the call
 * without bound and the tolerant reply parsing stays testable without a live
 * provider. The call is assembly-free by construction: the seam receives only
 * these two strings — the digest system instruction and the bounded
 * transcript — never tools, skills, MCP, memory or any Member's identity.
 * @module @wowyuarm/dsh-agent-team/thread-digest
 */
import type { RequestMessage } from '@deepseek-ai/dsh-llm';
/** Wall-clock bound of one digest call, raced against the client's signal. */
export declare const DIGEST_TIMEOUT_MS = 60000;
/** Output budget of the digest call; the recap is small by design. */
export declare const DIGEST_MAX_TOKENS = 1024;
/** Per-message cap inside the digest input; long bodies are read for gist. */
export declare const DIGEST_MESSAGE_CAP = 1200;
/** How many Messages the digest call reads at most, oldest first. */
export declare const DIGEST_MESSAGE_LIMIT = 60;
/** Caps the reply parser enforces on each digest field. */
export declare const DIGEST_SUMMARY_CAP = 600;
export declare const DIGEST_KEY_POINT_LIMIT = 6;
export declare const DIGEST_KEY_POINT_CAP = 200;
export declare const DIGEST_QUESTION_CAP = 300;
export declare const DIGEST_OPTION_LIMIT = 4;
export declare const DIGEST_OPTION_CAP = 200;
/** Stable first line of the system instruction, exported for the browser e2e key. */
export declare const DIGEST_SYSTEM_PREFIX = "You summarize one AI team collaboration Thread for its human lead.";
/** One Thread Message as the digest call sees it. */
export interface ThreadDigestMessage {
    readonly author: string;
    readonly text: string;
    /** Handles this Message names, empty when it names nobody. */
    readonly mentions: readonly string[];
}
/** Everything one digest call sees. */
export interface ThreadDigestInput {
    readonly channelName?: string;
    /** The Task's durable status when the Thread carries one, e.g. `in_review (awaiting acceptance)`. */
    readonly taskStatus?: string;
    readonly messages: readonly ThreadDigestMessage[];
}
/** The parsed digest; `summary` is the one required field. */
export interface ThreadDigestParsed {
    readonly summary: string;
    readonly keyPoints: readonly string[];
    readonly needsHumanDecision: boolean;
    readonly decisionQuestion?: string;
    readonly options?: readonly string[];
    /** Only alongside options: `multiple` when the model read a combinable ask. */
    readonly optionSelection?: 'single' | 'multiple';
}
/**
 * Build the one-shot call: one system line plus one user turn carrying the
 * bounded transcript. The JSON shape is spelled out because the reply is
 * parsed defensively, and the model is told to answer in the language of the
 * Thread — the reader of a Chinese Thread gets a Chinese recap.
 */
export declare function buildDigestMessages(input: ThreadDigestInput): {
    readonly system: string;
    readonly messages: readonly RequestMessage[];
};
/**
 * Parse the model reply defensively: tolerate fences, extract the first JSON
 * object, type-guard every field, and drop anything out of contract — a
 * wrong-typed or over-cap field is trimmed or ignored rather than fatal. An
 * options list without a question is meaningless, so it is dropped together.
 * A reply with no usable summary fails loudly: without it the panel has
 * nothing to show.
 */
export declare function parseThreadDigest(text: string): ThreadDigestParsed;
//# sourceMappingURL=thread-digest.d.ts.map