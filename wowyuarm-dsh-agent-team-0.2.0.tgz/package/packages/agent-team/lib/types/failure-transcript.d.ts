/**
 * Failure-transcript rendering for the doctor diagnostic Member.
 *
 * Turning one Member's Session into the research material a doctor agent
 * reads is a pure rendering problem: fold the Session's own events into a
 * bounded, model-facing transcript, keeping the tail (where the failure
 * lives) and the budget (so a 100k-token wedge cannot become a 100k-token
 * prompt). The transcript is framed as a research subject, never as
 * instructions — the transcript's own text is untrusted data, and the
 * rendering plus the analysis prompt say so explicitly.
 *
 * The same event fold also feeds the Human-facing session-history page, in a
 * `multiline` mode that keeps the stored text whole — line breaks and all —
 * because the reviewer reads the entry as authored. The page bounds transport
 * by paging entries; the fold never cuts content.
 * @module @wowyuarm/dsh-agent-team/failure-transcript
 */
/** Hard character budget of one rendered transcript (tail-kept). */
export declare const DOCTOR_TRANSCRIPT_MAX_CHARS = 60000;
/** Hard event budget of one rendered transcript; the tail is kept. */
export declare const DOCTOR_TRANSCRIPT_MAX_EVENTS = 400;
/** One Session event, narrowed to the shape the fold actually reads. */
export interface TranscriptEvent {
    readonly type: string;
    readonly time: number;
    readonly data?: unknown;
}
/**
 * One model-visible transcript line, split into the role/text pair both
 * surfaces render from. `system` is the rendered system prompt, `team` a
 * Member-to-Member relay, and `notice` a Host-injected Team notice or
 * context envelope — the three kinds the Human reviewer asked to tell apart
 * from ordinary Human input. `error` and `warning` are outcomes the stored
 * log carries outside the message surface (a failed turn, a tool that
 * refused, a model attempt that never committed) and only the Human review
 * fold emits: the audit page must show the whole process, not just the
 * messages that survived.
 */
export interface TranscriptEntry {
    readonly role: 'system' | 'notice' | 'team' | 'user' | 'assistant' | 'tool-call' | 'tool-result' | 'error' | 'warning';
    readonly text: string;
}
/**
 * `multiline` mode keeps the stored line breaks and the entry's full text, so
 * a Markdown-rendering surface can show the text as authored; the default
 * folds every entry to a single bounded line, which is what the doctor's
 * model-facing transcript needs.
 */
export declare function transcriptEntryOf(event: TranscriptEvent, options?: {
    readonly multiline?: boolean;
}): TranscriptEntry | undefined;
/**
 * The Human-facing fold as the review page consumes it: one event renders to
 * zero, one, or several entries. An `agent/inbox/spliced` batch is where the
 * agent loop carried a Member's wake input onto the model-visible surface —
 * Team relays and notices included — so the page reads each inserted message
 * on its own lane instead of dropping the batch. The fold also renders the
 * outcomes that never reach the message surface — a turn that failed, was
 * cancelled or blocked, a model attempt that committed no reply, a tool's
 * structured failure, a context compaction — because the audit page owes the
 * Human the whole real process, not just the messages that survived. The
 * doctor's single-line fold deliberately keeps ignoring splices and these
 * outcome events: its budget and ordering are the tail-evidence contract
 * that surfaces failures to the model.
 */
export declare function humanTranscriptEntriesOf(event: TranscriptEvent): readonly TranscriptEntry[];
/** Render one event line, or undefined for events the transcript does not show. */
export declare function renderTranscriptEvent(event: TranscriptEvent): string | undefined;
/**
 * Fold one Session's events into the bounded transcript. The tail is what
 * survives: earlier lines collapse into an omission marker once either budget
 * binds, because a Member that ends abnormally carries the evidence at the end
 * of its log. Event timestamps are Host-local instants; the transcript reports
 * sequence, which is the ordering authority Team facts actually use.
 */
export declare function renderFailureTranscript(events: readonly TranscriptEvent[], options?: {
    readonly maxEvents?: number;
    readonly maxChars?: number;
}): string;
/**
 * The doctor's one analysis prompt: the failed Member's transcript as the
 * research subject plus the reporting contract. The framing is explicit that
 * the transcript is data, not instructions — a wedged Member's log can carry
 * arbitrary injected text, and the doctor must treat it as evidence.
 */
export declare function doctorAnalysisPrompt(input: {
    readonly failedHandle: string;
    readonly failureDiagnostic?: string;
    readonly channelRefs?: readonly string[];
    readonly transcript: string;
}): string;
//# sourceMappingURL=failure-transcript.d.ts.map