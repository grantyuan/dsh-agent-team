/**
 * The Member prompt section-usage projection: how often one Member actually
 * called the tools a prompt section describes, folded on demand from the
 * Member's own session logs across the rollover lineage.
 *
 * The projection is never persisted — the Prompt dialog and the auto-prune
 * sweep compute it when they run, from the same events the session reader
 * already serves. A "turn" is the session log's own `turn/start`/`turn/end`
 * pair, so completed turns are read, not guessed. The candidate window folds
 * backwards from now and closes at whichever limit the walk hits first: the
 * last {@link PRUNE_WINDOW_TURNS} completed turns or
 * {@link PRUNE_WINDOW_DAYS} days. An unreadable archived generation (or an
 * ancestor walk that hits the depth cap while the window is still open) degrades
 * the fold to what was readable and flags it `partial` — a partial fold must
 * never drive an automatic drop, because unreadable history can only ever
 * under-count.
 *
 * @module @wowyuarm/dsh-agent-team/member-section-usage
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/**
 * Candidate-window turn depth: zero mapped calls within the last 20 completed
 * turns makes a tool-mapped section a prune candidate. Fixed here with the day
 * bound — the one place the window is defined.
 */
export declare const PRUNE_WINDOW_TURNS = 20;
/**
 * Candidate-window time depth in days: the shorter of the two bounds closes
 * the window, whichever the backward walk reaches first.
 */
export declare const PRUNE_WINDOW_DAYS = 14;
/**
 * How many archived generations one usage walk may read. Deep lineages bound
 * the walk the way the continuity timeline bounds its own; a window still open
 * past the cap is reported partial rather than silently truncated.
 */
export declare const MAX_USAGE_ANCESTORS = 16;
/** One session event, exactly the Harness shape the session logs carry. */
export type UsageEvent = SessionEvent;
/** One lineage generation's OWN events (the inherited prefix excluded) and its lineage parent, if any. */
export interface UsageGeneration {
    readonly ownEvents: readonly UsageEvent[];
    readonly parentSession?: string;
}
/** The one generation read the walker needs; `ok: false` is the degrade path. */
export type UsageAncestorRead = {
    readonly ok: true;
    readonly generation: UsageGeneration;
} | {
    readonly ok: false;
};
/**
 * Running state of one backward usage fold. `counts` accumulates `tool/call`
 * names within the window; `turnsClosed` counts the completed turns the walk
 * has passed; `closed` ends the walk (the window boundary was reached);
 * `partial` marks a fold that could not prove completeness inside the window.
 */
export interface UsageFold {
    readonly counts: ReadonlyMap<string, number>;
    readonly turnsClosed: number;
    readonly closed: boolean;
    readonly partial: boolean;
    /** Fold origin instant; the day bound measures backwards from here. */
    readonly now: number;
}
export declare function emptyUsageFold(now: number): UsageFold;
/**
 * Fold one generation's own events into the walk. Events arrive in log order
 * (oldest first) and are consumed newest-first, so the window closes at the
 * first boundary the backward walk reaches: an event older than the day bound,
 * or the turn/start that opens the {@link PRUNE_WINDOW_TURNS}-th completed
 * turn. That closing turn's own calls stay inside the window — the window is
 * the 20 most recent completed turns in full — so the walk continues one
 * turn-span past the closing `turn/end`. Turn numbers restart per generation,
 * so the seen-turn set is generation-local; the only state carried across
 * generations is the remaining turn budget.
 */
export declare function foldGenerationUsage(fold: UsageFold, events: readonly UsageEvent[]): UsageFold;
/**
 * Walk one Member's lineage newest-first and fold the candidate window's tool
 * calls. The walk stops at the window boundary, an exhausted parent chain
 * (complete — everything the lineage holds is folded), a failed ancestor read
 * (partial — degrade to what was readable), or the ancestor cap while the
 * window is still open (partial — the same under-count risk as a failed read).
 */
export declare function foldLineageUsage(start: UsageGeneration, readAncestor: (sessionId: string) => Promise<UsageAncestorRead>, now: number): Promise<UsageFold>;
//# sourceMappingURL=member-section-usage.d.ts.map