/**
 * Dispatch-time context relevance, decided by a model.
 *
 * A `fresh` Member (每个任务全新上下文) that finished its work keeps a live
 * Session full of the task it just closed. Renewing it before the next
 * assignment is the point of the policy — unless the next assignment really
 * continues that work, in which case the erase throws away the thing the new
 * task needs. That is a semantic question ("same lane, reworded" versus "a new
 * card in the same repository"), and a lexical measure cannot tell them apart:
 * measured against this Team's live ledger, whole-text overlap put both in the
 * same band. So the Host asks a model.
 *
 * Only one thing reaches the model: the incoming assignment against the Member's
 * recent work — its last few authored Messages plus the content of the Task it
 * most recently claimed. The answer is one bounded number, the Host applies the
 * threshold, and nothing durable is written: the judgement is an ephemeral
 * delivery decision, never a Team fact.
 *
 * This module is pure construction and parsing — the same shape the Prompt
 * dialog's curation call uses — so the prompt contract and the tolerant reply
 * parsing stay testable without a live provider.
 * @module @wowyuarm/dsh-agent-team/context-relevance
 */
import type { RequestMessage } from '@deepseek-ai/dsh-llm';
/** The model's score must reach this for the dispatch to keep the live context. */
export declare const CONTEXT_RELEVANCE_THRESHOLD = 0.6;
/** How many of the Member's own recent Messages the judgement reads. */
export declare const DISPATCH_HISTORY_MESSAGE_LIMIT = 5;
/** Wall-clock bound of one judgement call; a stuck provider must not pin a dispatch. */
export declare const RELEVANCE_JUDGE_TIMEOUT_MS = 20000;
/** The reply is one small JSON object, so the output budget stays tiny. */
export declare const RELEVANCE_JUDGE_MAX_TOKENS = 256;
/** Per-item cap inside the judgement input; long Task bodies are read for topic, not in full. */
export declare const RELEVANCE_JUDGE_ITEM_CAP = 1200;
/** Cap on the incoming assignment body inside the judgement input. */
export declare const RELEVANCE_JUDGE_TASK_CAP = 4000;
/** Stable first line of the system instruction, exported for the browser e2e key. */
export declare const RELEVANCE_JUDGE_SYSTEM_PREFIX = "You decide whether one new assignment continues a member's current work.";
/** Everything one judgement sees. */
export interface RelevanceJudgeInput {
    readonly handle: string;
    /** The assignment being dispatched. */
    readonly task: string;
    /** The Member's recent work, newest first: authored Messages, then its latest claimed Task. */
    readonly history: readonly string[];
}
/** One-shot model call: system line plus the single user turn carrying both sides. */
export declare function buildRelevanceJudge(input: RelevanceJudgeInput): {
    readonly system: string;
    readonly messages: readonly RequestMessage[];
};
/**
 * The model's relevance score, or undefined when the reply carries no usable
 * number. Parsing is deliberately tolerant — the reply rides a normal assistant
 * turn whose trailing completion marker, prose, or markdown fence must not turn
 * a readable score into a failure — and out-of-range numbers are clamped.
 */
export declare function parseRelevanceScore(text: string): number | undefined;
//# sourceMappingURL=context-relevance.d.ts.map