/**
 * Team-owned Member supervision policy.
 *
 * A Member that stops in the middle of claimed work does not bring itself back:
 * a runtime error leaves it in an error presence, a failed activation leaves it
 * with no Session at all, and `recovery.ts` stands down after three consecutive
 * recoverable failures and leaves the Member to the operator. This policy is the
 * Host's automatic last resort on top of that. Every pass looks at every enabled
 * Member, and for each one:
 *
 * - an abnormally stopped Member (including a nominally running one that has
 *   produced no durable Session event for {@link SUPERVISION_HUNG_MS} — a wedge,
 *   not work) gets one bring-up attempt per pass, up to
 *   {@link SUPERVISION_MAX_RESTART_ATTEMPTS};
 * - {@link SUPERVISION_MAX_CONSECUTIVE_FAILURES} `agent/error` occurrences with
 *   no clean turn end between them, or {@link SUPERVISION_WINDOW_FAILURES}
 *   occurrences inside {@link SUPERVISION_FAILURE_WINDOW_MS} however separated,
 *   prove it cannot make progress even while it runs. Failure counting is the
 *   Host's whole progress judgment: the context itself is never policed, so a
 *   context the route refuses is just one more failing turn, and the third one
 *   in a row ends in the same reset.
 *
 * Once proven, the Host resets the Member's context itself — the same
 * fresh-context renewal the Human menu performs, privately noticed to the
 * reset Member alone; nothing is broadcast to the Team, because the Member
 * re-orients from its memory and the durable Team history and asks its
 * teammates about whatever stays unclear. The archive-and-replace handover is
 * the last resort when that reset did not heal it: the replacement carries
 * the failed Member's role, private memory, and Channel reach — never its
 * Session log — and asks the Human admin in Channel to reassign the released
 * work.
 *
 * The chain is driven by {@link MemberSupervisor.runTick}, which the periodic
 * pass runs: the Host's open escalations advance first, so a reset that never
 * committed is retried and a reset that did not heal reaches the handover, and
 * a Member the chain already owns is left to it instead of being spent more
 * bring-up nudges. A pass that only ran the bring-up budget would keep waking a
 * Member whose chain had stalled — nudges that change nothing, forever.
 *
 * "Abnormally stopped" is deliberately the dead-or-erroring shape, not the
 * merely-unproductive one: `unavailable` (no live Session, failed activation) or
 * an error presence. A Member that is live and idle with open Claims is waiting
 * by design, and interrupting or replacing it would be a fabricated failure.
 *
 * Counters are process-local by design, exactly like the pressure policy's
 * overflow retry: a restart re-earns the budget, while every durable result
 * (the reset, archival, the new Member, the released Claims, the notice Message)
 * is an ordinary ledger operation, so a crash mid-escalation replays as a normal
 * ledger and never as a half-faked Team fact.
 * @module @wowyuarm/dsh-agent-team/supervisor
 */
import type { AgentTeamCompletedWork, AgentTeamMemberId } from './types.ts';
/** How often one supervision pass runs once the Host has restored its Members. */
export declare const SUPERVISION_INTERVAL_MS: number;
/** Bring-up attempts a stopped Member gets before it is replaced instead. */
export declare const SUPERVISION_MAX_RESTART_ATTEMPTS = 3;
/** Consecutive `agent/error` occurrences that replace a Member outright. */
export declare const SUPERVISION_MAX_CONSECUTIVE_FAILURES = 3;
/**
 * Windowed failure rate: this many `agent/error` occurrences inside
 * {@link SUPERVISION_FAILURE_WINDOW_MS} count as "multiple failures in twenty
 * minutes" even when a clean turn separates them — a Member that keeps
 * erroring on every retry of the same work cannot make progress, however often
 * a turn technically ends.
 */
export declare const SUPERVISION_WINDOW_FAILURES = 3;
/** The rolling window {@link SUPERVISION_WINDOW_FAILURES} failures are counted in. */
export declare const SUPERVISION_FAILURE_WINDOW_MS: number;
/**
 * A Member whose Agent has been running with no durable Session event for this
 * long reads as hung ("stuck"): a healthy turn produces events continuously,
 * so half an hour of silence while nominally running is a wedge, not work.
 */
export declare const SUPERVISION_HUNG_MS: number;
/** What one pass observes about one Member. */
export type MemberSupervisionState = 
/** Live and reachable: any open failure record is cleared. */
'healthy'
/** A transition the policy must not interrupt (context rollover, running turn). */
 | 'settling'
/** Abnormally stopped: no live Session, or an error presence. */
 | 'stopped';
/** Why the policy gave up on one Member. */
export type SupervisionTrigger = 'abnormal-stop' | 'consecutive-failures' | 'failure-rate' | 'hung';
export interface SupervisorOptions {
    /** Every enabled Member: the watch list. */
    readonly candidates: () => readonly AgentTeamMemberId[];
    /** Current supervision state of one watched Member. */
    readonly stateOf: (memberId: AgentTeamMemberId) => MemberSupervisionState;
    /** One bounded bring-up attempt; the next pass re-reads the state to judge it. */
    readonly restart: (memberId: AgentTeamMemberId) => Promise<void>;
    /**
     * One proven episode: the Host opens the coercion chain with its own
     * private context reset, and the archive-and-replace handover follows on a
     * later pass only while the Member still reads abnormal. `restartAttempts`
     * is the bring-up count already spent, which the handover notice reports
     * verbatim.
     */
    readonly replace: (memberId: AgentTeamMemberId, trigger: SupervisionTrigger, restartAttempts: number) => Promise<void>;
    /**
     * Advance the Host's open coercion chains, run by {@link MemberSupervisor.runTick}
     * ahead of every periodic bring-up pass: a reset that never committed retries
     * here, and a reset that did not heal becomes the handover. Absent, the tick
     * degenerates to the bring-up pass alone (a policy-only harness).
     */
    readonly advanceEscalations?: () => Promise<void>;
    /**
     * Whether the coercion chain already owns this Member. While it does, the
     * pass spends no bring-up nudge: the chain's own step is the remedy, and a
     * nudge only keeps the Member running past the boundary that step waits on.
     */
    readonly escalationOpen?: (memberId: AgentTeamMemberId) => boolean;
    /** Log one coordinator diagnostic. */
    readonly log: (message: string) => void;
    readonly intervalMs?: number;
    readonly maxRestartAttempts?: number;
    readonly maxConsecutiveFailures?: number;
    readonly windowFailures?: number;
    readonly failureWindowMs?: number;
}
export declare class MemberSupervisor {
    private readonly options;
    private readonly watched;
    private readonly intervalMs;
    private readonly maxRestartAttempts;
    private readonly maxConsecutiveFailures;
    private readonly windowFailures;
    private readonly failureWindowMs;
    private timer;
    private passRunning;
    /** Serializes the whole periodic tick (escalation advance plus bring-up pass). */
    private tickRunning;
    private disposed;
    constructor(options: SupervisorOptions);
    /** Begin the periodic pass; called once the Host has restored every Member. */
    start(): void;
    dispose(): void;
    /**
     * Observe one `agent/error` occurrence. A Member that fails
     * {@link SUPERVISION_MAX_CONSECUTIVE_FAILURES} times without ever finishing a
     * turn cleanly starts the coercion chain on the spot — waiting for the next
     * pass would only burn more of the same failing route. The consecutive
     * streak is judged first because it is the sharper evidence; the rolling
     * window then still catches the Member that keeps failing on every retry of
     * the same work however often a turn technically ends. Only the watch list
     * is counted: an erroring Member with no open Claim has nothing to hand
     * over yet, and the pass leaves it to the operator exactly as
     * `recovery.ts` does.
     *
     * `diagnostic` is the recorded failure text, kept for future classification;
     * a caller with no text to record passes none and is judged on the failure
     * counts alone.
     */
    onError(memberId: AgentTeamMemberId, diagnostic?: string): void;
    /** A turn that ended without an error: the failure streak is over. */
    onCleanTurn(memberId: AgentTeamMemberId): void;
    /**
     * One periodic supervision tick: the Host's open coercion chains advance
     * first, then the bring-up pass runs. The whole tick is serialized like a
     * single pass — a slow chain step skips its turn rather than queueing another
     * tick behind it — so escalation and bring-up never run concurrently for the
     * same Member.
     */
    runTick(): Promise<void>;
    /**
     * One supervision pass. Overlapping passes are skipped rather than queued: a
     * pass that is still running when the timer fires is doing its job, and the
     * handover it performs is serialized on the Host's lifecycle queue anyway.
     */
    runPass(): Promise<void>;
    private entryFor;
    /**
     * How many `agent/error` occurrences one Member recorded inside `windowMs`.
     * The Host's status surface reports this so a supervisor tool can show the
     * same "multiple failures in twenty minutes" evidence the policy acts on.
     */
    recentFailureCount(memberId: AgentTeamMemberId, windowMs: number): number;
    private replace;
}
/**
 * The next generation handle for a replaced Member: `<role>-2`, `<role>-3`, …
 *
 * Archival hides a Member without releasing its handle (an archived Member still
 * claims its name in the ledger's uniqueness check), so a replacement always
 * takes a numbered generation. The numbering is per role, not per failure: a
 * trailing `-N` on the failed handle is read as its generation and the next one
 * follows it, so a role that keeps dying walks `builder-2 → builder-3` instead of
 * stacking `builder-2-2-2`. Every earlier generation — archived or live — is
 * skipped, and comparison follows the ledger's own handle normalization so a
 * replacement can never fork the `@` namespace.
 */
export declare function nextReplacementHandle(base: string, takenHandles: Iterable<string>): string;
/** One released Claim summarized for the admin handover notice. */
export interface SupervisionReleasedClaim {
    readonly direction: string;
    readonly taskNumber: number;
}
/**
 * A best-effort plain-language recap of the retired Member's final Session,
 * produced by the one-shot propose-only digest. It is not a Team fact: it is
 * appended to the retirement notice only when the call resolved in time.
 */
export interface SupervisionSessionRecap {
    readonly summary: string;
    readonly keyPoints: readonly string[];
}
/**
 * The structured retirement notice posted into the affected business Channel
 * when a Member is archived and replaced. It is a plain-text headed block — the
 * Team Assistant's voice renders literally in the Client, so the body carries no
 * Markdown — listing the retirement cause, the work the Member finished in
 * service (from the ledger projection), the work left unclaimed again (the
 * released Claims), and the succession line.
 *
 * `sessionRecap` is optional and best-effort: when the retired Member's final
 * Session was recapable, its summary rides the notice as a `Final Session
 * recap` block; when the call timed out, aborted, or failed, the notice is
 * unchanged apart from the missing block.
 *
 * `addressedHandle` names who the reassignment ask mentions — the designated
 * leader when the notice is delivered to them, `human` when it falls back to a
 * Channel broadcast — so the same body reaches whoever is expected to act.
 */
export declare function supervisionRetirementNotice(input: {
    readonly failedHandle: string;
    readonly replacementHandle: string;
    readonly addressedHandle: string;
    readonly trigger: SupervisionTrigger;
    readonly restartAttempts: number;
    readonly maxRestartAttempts: number;
    readonly maxConsecutiveFailures: number;
    readonly maxWindowFailures: number;
    readonly maxFailureWindowMs: number;
    readonly completedWork: AgentTeamCompletedWork;
    readonly releasedClaims: readonly SupervisionReleasedClaim[];
    readonly sessionRecap?: SupervisionSessionRecap;
}): string;
//# sourceMappingURL=supervisor.d.ts.map