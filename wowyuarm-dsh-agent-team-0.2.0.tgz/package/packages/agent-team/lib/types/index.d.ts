/**
 * Durable Agent Team Host capability.
 *
 * The Host owns the append-only collaboration ledger and all Member lifecycle
 * effects. Session history and browser state are projections, never Team facts.
 * @module @wowyuarm/dsh-agent-team
 */
import { Context, Service, type Volatile } from '@deepseek-ai/cordis';
import { type Agent } from '@deepseek-ai/dsh-agent';
import { SessionId } from '@deepseek-ai/dsh-session';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace';
import { type ContextProjectionConfig, type ContextTimelineSource } from '@wowyuarm/dsh-context-continuity';
import { type AgentTeamDurableMemberResult } from './ledger.ts';
import { type ThreadDigestMessage } from './thread-digest.ts';
import { type TranscriptEntry } from './failure-transcript.ts';
import type { AgentTeamAddMemberRequest, AgentTeamAddMemberResult, AgentTeamAgentMember, AgentTeamAgentMemberStatus, AgentTeamArchiveChannelRequest, AgentTeamArchiveChannelResult, AgentTeamArchiveMemberRequest, AgentTeamArchiveMemberResult, AgentTeamChangesRequest, AgentTeamChangesResult, AgentTeamClaimList, AgentTeamClaimRequest, AgentTeamClaimResult, AgentTeamClientMemberStatus, AgentTeamContextCheckpointRef, AgentTeamCreateChannelRequest, AgentTeamCreateChannelResult, AgentTeamDiagnoseMemberRequest, AgentTeamDiagnoseMemberResult, AgentTeamEnvironmentRequest, AgentTeamEnvironmentResult, AgentTeamResetMemberRequest, AgentTeamResetMemberResult, AgentTeamSupervisionStatus, AgentTeamGetAttachmentRequest, AgentTeamGetAttachmentResult, AgentTeamGetHumanAvatarRequest, AgentTeamGetHumanAvatarResult, AgentTeamHumanProfileRequest, AgentTeamHumanProfileResult, AgentTeamPutHumanAvatarRequest, AgentTeamPutHumanAvatarResult, AgentTeamRemoveHumanAvatarRequest, AgentTeamRemoveHumanAvatarResult, AgentTeamInbox, AgentTeamInboxRequest, AgentTeamJoinChannelRequest, AgentTeamJoinChannelResult, AgentTeamJoinWorkspaceRequest, AgentTeamJoinWorkspaceResult, AgentTeamLeaveWorkspaceRequest, AgentTeamLeaveWorkspaceResult, AgentTeamMemberId, AgentTeamMemberInterrupts, AgentTeamMemberInterruptsRequest, AgentTeamResolveMemberInterruptRequest, AgentTeamResolveMemberInterruptResult, AgentTeamRecordInterruptToolRequest, AgentTeamRecordInterruptToolOutcome, AgentTeamListInterruptsToolOutcome, AgentTeamReleaseInterruptToolRequest, AgentTeamReleaseInterruptToolOutcome, AgentTeamMemberPromptView, AgentTeamMemberPromptViewRequest, AgentTeamMemberSessionsRequest, AgentTeamMemberSessionSummary, AgentTeamMemberSessionTranscriptRequest, AgentTeamMemberSessionTranscript, AgentTeamCurateMemberPromptRequest, AgentTeamCurateMemberPromptResult, AgentTeamMemberResult, AgentTeamMembersRequest, AgentTeamResolveTaskRefsRequest, AgentTeamResolveTaskRefsResult, AgentTeamResolveThreadRefsRequest, AgentTeamResolveThreadRefsResult, AgentTeamEditMessageRequest, AgentTeamEditMessageResult, AgentTeamOperationReceipt, AgentTeamPromoteThreadRequest, AgentTeamPromoteThreadResult, AgentTeamPutAttachmentRequest, AgentTeamPutAttachmentResult, AgentTeamRecallMessageRequest, AgentTeamRecallMessageResult, AgentTeamRecoverMemberRequest, AgentTeamRecoverMemberResult, AgentTeamClearMemberContextRequest, AgentTeamClearMemberContextResult, AgentTeamCompactMemberContextRequest, AgentTeamCompactMemberContextResult, AgentTeamRolloverSessionRequest, AgentTeamDmRequest, AgentTeamDmResult, AgentTeamRemoveChannelMemberRequest, AgentTeamRemoveChannelMemberResult, AgentTeamRemoveMemberRequest, AgentTeamRemoveMemberResult, AgentTeamReplyRequest, AgentTeamReplyResult, AgentTeamSendMessageRequest, AgentTeamSendMessageResult, AgentTeamSetHumanProfileRequest, AgentTeamSetHumanProfileResult, AgentTeamSetMemberStateRequest, AgentTeamStatus, AgentTeamTask, AgentTeamTaskRequest, AgentTeamTaskResult, AgentTeamTasks, AgentTeamTasksBatchRequest, AgentTeamTasksBatchResult, AgentTeamTasksRequest, AgentTeamMemberTasks, AgentTeamMemberTasksRequest, AgentTeamSummarizeThreadRequest, AgentTeamSummarizeThreadResult, AgentTeamThreadAttentionRequest, AgentTeamThreadAttentionResult, AgentTeamThreadAttentionStatus, AgentTeamThreadHistory, AgentTeamThreadHistoryRequest, AgentTeamThreadReadRequest, AgentTeamThreadReadResult, AgentTeamThreadObservations, AgentTeamThreadObservationsRequest, AgentTeamUpdateChannelRequest, AgentTeamUpdateChannelResult, AgentTeamUpdateMemberRequest, AgentTeamView, AgentTeamViewRequest } from './types.ts';
export { agentTeamDomainSpec, agentTeamOperationSchema } from './spec.ts';
export type * from './types.ts';
export { AGENT_TEAM_HUMAN_HANDLE, AGENT_TEAM_HUMAN_MEMBER_ID, AGENT_TEAM_ASSISTANT_HANDLE, AGENT_TEAM_ASSISTANT_MEMBER_ID, AGENT_TEAM_INITIALIZE_REQUEST_ID, AGENT_TEAM_RECALLED_BODY_TOMBSTONE } from './ledger.ts';
export { HUMAN_PROFILE_DEFAULT_NAME, HUMAN_PROFILE_REPO_URL, HUMAN_PROFILE_SETTINGS_NAMESPACE, HUMAN_PROFILE_SETTINGS_SCHEMA, HUMAN_PROFILE_VERSION, assertValidHumanName, normalizeHumanName } from './human-profile.ts';
export { humanAvatarsRoot } from './human-avatar.ts';
export { AGENT_TEAM_TOOL_NAMES } from './member-runtime.ts';
/** Process-stable marker carried by the final Team message tool definition. */
export declare const AGENT_TEAM_PRESET_MARKER: unique symbol;
/** The widest timeline window there is; the ref gate reads at this width so no printed ref is unreachable. */
export declare const MAX_TIMELINE_LIMIT = 24;
/**
 * Fold one retired Member's final-Session transcript into the digest's message
 * shape: the newest {@link DIGEST_RETIREMENT_ENTRY_LIMIT} entries, the Member's
 * own turns labelled by its handle, everyone else by lane.
 */
export declare function retirementRecapDigestMessages(handle: string, entries: readonly TranscriptEntry[]): readonly ThreadDigestMessage[];
/**
 * Derive one route's pressure budgets from its model information:
 * `hardLimit = window − outputReserve` where the reserve is the model's
 * disclosed default per-request output cap floored at 16K — a request that
 * may spend that many tokens on the answer cannot also fill the window with
 * context; `handoffAt = hardLimit − handoffReserve` where the reserve is
 * `max(8K, 4% of window)` — the deeper the window, the more room a single
 * forced compaction must leave behind, since one reduction is not guaranteed
 * to clear an arbitrary overrun. Both floors at zero: a route narrower than
 * its reserves prices no usable budget instead of a negative one.
 */
export declare function deriveContextPressureBudget(routeWindow: number, defaultMaxTokens?: number): {
    readonly hardLimit: number;
    readonly handoffAt: number;
};
/** Mark the preset's `team_message` definition as an Agent Team consumer. */
export declare function markAgentTeamPreset<T extends object>(definition: T): T;
/**
 * Whether the running dsh loads workspace packages from source via tsx.
 *
 * The Harness `tsconfig.base.json` maps `@deepseek-ai/*` package names onto
 * `src/` directories; tsx honors those paths, so a CLI launched with
 * `node --import tsx/esm apps/cli/src/bin.ts` imports `@deepseek-ai/dsh-scope`
 * from `src/index.ts` while a profile-installed bundle resolves the compiled
 * `lib/index.js` — two module instances with independent scope keys.
 */
export declare function isTsxDevMode(): boolean;
/**
 * The activation diagnostic for a dsh-scope module-instance mismatch.
 *
 * `agentPresets.mount` already rejected an unscoped context, so a scope key
 * the harness sees but this bundle does not can only mean the two sides
 * loaded different physical copies of `@deepseek-ai/dsh-scope`.
 */
export declare function teamPresetScopeMismatchMessage(tsxDevMode: boolean): string;
export interface AgentTeamCommitted {
    readonly receipt: AgentTeamOperationReceipt;
}
/**
 * A DM was durably recorded but its session injection could not run (no live
 * handle, or the wake itself failed). The recorded DM stays durable; the
 * sender should not blindly retry — the recipient recovers it through its DM
 * history once its session is live again.
 */
export declare class AgentTeamDmDeliveryError extends Error {
    readonly recipientMemberId: AgentTeamMemberId;
    readonly recipientHandle: string;
    constructor(recipientMemberId: AgentTeamMemberId, recipientHandle: string, message: string);
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        agentTeam: AgentTeam;
    }
    interface Events {
        /** One new Team operation is durable and visible through Host projections. */
        'agent-team/committed'(event: AgentTeamCommitted): void;
    }
}
/** Tool-side request for one context rollover; the Host validates without side effects. */
export interface AgentTeamNewContextToolRequest {
    readonly memberId: AgentTeamMemberId;
    /** Selected checkpoint ref from `context_timeline`; absent means fresh. */
    readonly checkpointRef?: AgentTeamContextCheckpointRef;
    readonly relatedFiles?: readonly {
        readonly path: string;
        readonly reason: string;
    }[];
}
/** Tool-side validation outcome: which rollover mode a successful call will take. */
export interface AgentTeamNewContextToolOutcome {
    readonly mode: 'fresh' | 'from-checkpoint';
}
/** Tool-side request for one explicit checkpoint; the Host validates without side effects. */
export interface AgentTeamCheckpointToolRequest {
    readonly memberId: AgentTeamMemberId;
    /** Provider-issued call id of this tool call; the stable ref derives from it. */
    readonly callId: string;
    readonly name: string;
}
/** Tool-side checkpoint validation outcome: the deterministic ref the result will carry. */
export interface AgentTeamCheckpointToolOutcome {
    readonly checkpointRef: AgentTeamContextCheckpointRef;
    readonly name: string;
}
/** Tool-side request for the bounded structural context timeline. */
export interface AgentTeamTimelineToolRequest {
    readonly memberId: AgentTeamMemberId;
    readonly limit?: number;
}
/** One structural timeline item: a checkpoint or boundary candidate with pricing. */
export interface AgentTeamTimelineItem {
    /** Opaque stable ref; the selection surface for `context_rollover.checkpointRef`. */
    readonly checkpointRef: string;
    /** Semantic label: the model-supplied checkpoint name or boundary label. */
    readonly name: string;
    /** Which structural source produced this item. */
    readonly source: 'agent' | 'team-boundary' | 'handoff' | 'compaction' | 'head';
    /** Approximate tokens a return would retain (the prefix through this anchor). */
    readonly retainedTokens: number;
    /** Approximate tokens a return would discard (the suffix after this anchor). */
    readonly discardedTokens: number;
    /**
     * Threads whose facts entered this Session's model context by this anchor
     * (delivered Team notices only — never unread ledger activity). Empty when
     * nothing attributable was delivered.
     */
    readonly affectedThreads: readonly string[];
    /** Whether `context_rollover` accepts this ref as a seed target. */
    readonly restorable: boolean;
    /** When not restorable, the concise reason. */
    readonly reason?: string;
    /** Session the candidate anchors in; present for non-current-generation sources. */
    readonly sourceSessionId?: SessionId;
}
/** Tool-side timeline outcome: usage plus the bounded structural candidate list. */
export interface AgentTeamTimelineToolResult {
    readonly usageTokens: number;
    readonly hardLimit: number;
    readonly handoffAt: number;
    readonly items: readonly AgentTeamTimelineItem[];
    /**
     * The unreadable ancestor that ended the lineage walk early, when one did:
     * history is complete through the last listed source and provably absent
     * beyond it. Never a Member-availability fact.
     */
    readonly incompleteFrom?: {
        readonly sessionId: SessionId;
        readonly reason: string;
    };
}
/**
 * Config of the Team Host row: the Human profile (see human-profile.ts) plus
 * the composition-only `ledgerDirectory`. The settings service derives every
 * form from the owning plugin's Config, so the profile is this plugin's own
 * config rather than a section of its own; both profile fields arrive volatile,
 * which is what lets an edit reach the running Host without remounting it.
 * `ledgerDirectory` is static boot input naming the directory that holds the
 * shared SQLite ledger file, where the Host claims its single-writer lock (see
 * ledger-fence.ts); a Host never told it (test harnesses, non-file media) runs
 * unfenced. The row is presentation-owned (`auto: false`), so it renders no
 * settings control.
 */
export interface Config {
    name: Volatile<string>;
    avatarRef: Volatile<string | undefined>;
    ledgerDirectory?: string;
}
/** Host owner of the single Agent Team in one dshHome. */
export default class AgentTeam extends TypertRemoteService {
    config: Config;
    static Config: import("@deepseek-ai/schemastery").default<Schemastery.ObjectS<NoInfer<{
        name: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        avatarRef: import("@deepseek-ai/schemastery").default<string, string, "volatile">;
        ledgerDirectory: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    }>>, Schemastery.ObjectT<NoInfer<{
        name: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        avatarRef: import("@deepseek-ai/schemastery").default<string, string, "volatile">;
        ledgerDirectory: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    }>>, "plain">;
    static inject: string[];
    private domain?;
    private ledger?;
    private readonly handles;
    /** Live Member per session id; drives the root session/event listener. */
    private readonly memberBySessionId;
    /** Live selection refs let model edits take effect without disposing the Session. */
    private readonly modelSelections;
    /** Agent ids with a turn in flight; restarts must wait for the boundary. */
    private readonly runningAgents;
    /** Per-Member runtime state: tool restrictions, skill mounts, warnings, private memory. */
    private readonly memberRuntime;
    /**
     * The single seam for every per-Session stored read: handle lifecycle and
     * failure normalization live here, so a DSH persistence-interface change is
     * adapted once, and consumers choose policy by failure category instead of
     * matching error text.
     */
    private readonly sessionReader;
    /**
     * Why one Member shows error presence, per failure source. Reads prefer
     * activation, then runtime, then compaction; slots clear independently, so
     * a recovered runtime error re-reveals an outstanding compaction failure.
     * Keyed by Member rather than Session so a restarted Session cannot leak
     * stale keys; each runtime/compaction record carries the Session it
     * happened in, so a record left over from an earlier generation can be
     * recognized as stale instead of reading as the Member's current state.
     */
    private readonly memberFailures;
    /**
     * Last durable Session-event timestamp per Member, process-local. Hung
     * detection reads it: a Member whose Agent stays `running` while this
     * timestamp ages past the supervision threshold is stuck, not working.
     */
    private readonly memberActivity;
    /**
     * How far the supervision escalation chain has advanced per flagged Member,
     * process-local like the counters it extends. Step one posts the alert so
     * any fellow Member (or the Human) can act through `team_supervise`; step
     * two is the Host's own fallback context reset; step three is the
     * archive-and-replace last resort. Steps advance one per supervision pass
     * while the Member stays abnormal, and an entry is dropped as soon as the
     * Member reads healthy again.
     */
    private readonly supervisionEscalation;
    /**
     * The best-effort final-Session recap per Member in the coercion chain. The
     * digest runs outside the ledger queue from the give-up onward and drops its
     * result into a mutable slot that the later handover reads without waiting;
     * an entry lives only while its escalation does.
     */
    private readonly retirementRecaps;
    private readonly pressurePolicy;
    private readonly notifiedInbox;
    private attachmentGcTimer?;
    /**
     * New-release check behind the settings footnote. Memory-only and
     * background-refreshed, so the profile read path never waits on the
     * network and every failure settles as "no update known".
     */
    private readonly humanUpdateCheck;
    private readonly recovery;
    /**
     * LLM response-shape guard: a completed model round that ends the turn with
     * no tool call and no proper completion marker is a faulty round, and a
     * bounded "continue" nudge keeps the Member going. See `response-guard.ts`.
     */
    private readonly responseGuard;
    /**
     * The automatic last resort behind {@link recovery}: a Member that still holds
     * active Claims and cannot be brought back is archived and replaced by a
     * same-role generation that inherits its private memory and Channels, and asks
     * the Human admin in Channel to reassign the released work. See
     * `supervisor.ts` for the pass policy.
     */
    private readonly supervisor;
    /**
     * The idle-continuation policy behind the Task list: when every enabled
     * Agent sits `available`, open Tasks remain, and no ledger write landed for
     * the quiet hold, it fires one nudge per episode at the Workspace's
     * designated leader (`member.leader`). See `continuation-watcher.ts` for the
     * pass policy and `announceContinuationNudge` for the delivery; the read
     * lambdas all guard the pre-restore window where `this.ledger` is still
     * unset, reading as "nothing to watch".
     */
    private readonly continuationWatcher;
    /**
     * The per-Member completion liaison: a Member that finishes on the 任务结束
     * marker and stays idle gets checked — report to the designated leader, or
     * an open-Task push to the Member itself when the Workspace has no leader,
     * whose explicit refusal (a reply opening with 拒绝继续) is relayed to
     * `@human`. See `completion-liaison.ts` for the pass policy and the three
     * `*Liaison*` deliveries below for the message shapes; the read lambdas
     * guard the pre-restore window exactly like the watcher's, and
     * `reportedToLeaderSince` reads `true` (nothing to do) before the ledger
     * exists.
     */
    private readonly completionLiaison;
    /**
     * Output-truncation escalation: a turn the provider cut off at the
     * output-token cap leaves the Member idle on a truncated answer, and the
     * designated leader — not the Host — decides how to proceed. See
     * `truncation-escalation.ts` for the episode policy and
     * `notifyLeaderOfTruncation` for the delivery; the read lambdas guard the
     * pre-restore window exactly like the watcher's and the liaison's.
     */
    private readonly truncationEscalation;
    /**
     * Team's domain half of the continuity projection: the durable ref naming,
     * the Team-notice rule, and the boundary judgement (committed messages,
     * claim changes, first Thread arrivals). Its claim attribution resolves the
     * Task's Thread through the ledger, which is why the resolver reads
     * `this.ledger` lazily — the fold may run before the domain is open, and an
     * unattributed boundary is still a valid anchor.
     */
    private readonly contextProjectionHost;
    /**
     * Context self-management: the one deep module that turns a Member's
     * successful `context_rollover` tool result into its next private context
     * generation. The ledger owns the binding audit, the engine's projection
     * unit owns intent, and this coordinator owns only reconstructible process
     * state. See docs/architecture/README.md and docs/team-collaboration/README.md.
     */
    private readonly contextManagement;
    private lifecycleTail;
    private accepting;
    /**
     * Single-writer claim on the ledger's file medium, taken in `init` and
     * released on dispose. A leaked patch-reload survivor of an earlier mount
     * sees itself superseded here and stops committing before it can fork the
     * chain; see ledger-fence.ts. Undefined for hosts whose ledger medium is not
     * the shared SQLite file (memory-backend test harnesses), which own the
     * ledger in-process and must not touch the DSH home.
     */
    private fence;
    /** One adoption attempt per boot: the two readiness edges fire once each, and this keeps their attempt single. */
    private legacyAdoptionStarted;
    /**
     * Members with one scheduled background compaction. The remote rejects a
     * second schedule per Member while one is pending; membership clears when
     * the background body settles (ran, dropped, or failed).
     */
    private readonly pendingCompactions;
    /**
     * Members with one scheduled fresh-start context reset (task-start
     * policy). Claim and atomic-start boundaries schedule; the dedupe keeps
     * one in-flight body per Member, and membership clears when the body
     * settles (ran, dropped, or failed).
     */
    private readonly pendingPolicyResets;
    /**
     * Fresh-start Members whose last turn ended by announcing completion (the
     * completion marker): the next dispatch — an Inbox wake carrying new unread
     * work — renews their context first and the task is delivered into the fresh
     * generation, so every task really starts from system context plus that
     * task. A completion alone never renews; the arm waits for dispatch. Restored
     * over a marker tail by a later boot as well, so a restart keeps the promise.
     */
    private readonly armedFreshStartReset;
    /**
     * Per Member, the ledger sequence up to which a sender explicitly declared
     * "this work needs their live context" ({@link AgentTeamSendMessageRequest.keepContext}):
     * the dispatch gate reads direct work newer than that sequence as a real new
     * task and direct work at or before it as the exempted delivery. Process-local
     * like the arm, and monotone by construction — a later dispatch always
     * carries a higher sequence — so one exemption can never cover a second task.
     */
    private readonly keptDispatchSequence;
    /**
     * Per Member, the dispatch whose keep-or-renew judgement is in flight at the
     * model. The Inbox gate holds every wake while one is running — the answer
     * decides whether that delivery lands in the live Session or after a renewal —
     * and one call at a time keeps a burst of dispatches from spending a call each.
     */
    private readonly judgingFreshStart;
    /**
     * The Session id of the most recent context renewal committed for each
     * Member, whatever path renewed it (Human menu, supervision, doctor, or the
     * fresh-start policy). A waiting reset body reads it as "already renewed":
     * the fresh-generation intent is satisfied, and the body must not stack a
     * second erase onto a context someone else just made fresh.
     */
    private readonly renewedSessionByMember;
    /** One in-flight auto-prune sweep per Member; the task-start twin of pendingPolicyResets. */
    private readonly pendingPruneSweeps;
    /**
     * One in-flight live runtime apply per Member; the edit twin of
     * pendingPruneSweeps. Concurrent edits coalesce into the one running body,
     * which re-applies the CURRENT ledger facts, so no edit is lost.
     */
    private readonly pendingMemberApplies;
    /**
     * Presence wake epoch: Agent running/idle/failure is runtime state with no
     * durable fact behind it, so the presence scope counts those edge wakes in
     * process. It never takes part in a projection waiter's comparison.
     */
    private presenceEpoch;
    private readonly changeWaiters;
    constructor(ctx: Context, config: Config);
    /** Current human display name; the single source for team_view and @ matching. */
    humanHandle(): string;
    /** Current human profile reference held in this Host row's Config (name + avatarRef). */
    humanProfile(): {
        readonly name: string;
        readonly avatarRef?: string | undefined;
    };
    /** Push the current Config name into the ledger's runtime @ handle. */
    private syncHumanHandle;
    /**
     * The two judgements the Config schema cannot make about a Human name: the
     * same non-empty floor as Member handles, plus global uniqueness against live
     * Members. `setHumanProfile` runs it before the write, so a colliding rename
     * rejects instead of persisting. It reads the one field it judges, so the
     * caller passes the name alone rather than a whole profile shape.
     */
    private validateHumanProfile;
    /**
     * One-time adoption of the profile facts the retired `agent-team-human`
     * settings section held (see `LEGACY_HUMAN_PROFILE_SECTION` for why the
     * upstream importer cannot carry them over). The values land in this Host
     * row's own Config through the same Remote the profile page writes, so the
     * page, the ledger's @ handle, and every avatar seat follow as after any
     * edit. Readiness has two one-way edges — the settings service arrives, the
     * ledger opens — and whichever fires second starts the attempt; only a
     * pristine profile is adopted, and one attempt per boot is its whole
     * lifetime, so adoption never loops and never re-writes.
     */
    private adoptLegacyHumanProfile;
    /** Carry the first legacy document that still has the section into a pristine profile. */
    private adoptLegacyHumanProfileNow;
    /** Open the durable ledger and restore every enabled Member independently. */
    protected [Service.init](): Promise<void>;
    /**
     * Lazy Workspace-deletion handling: a Workspace that no longer exists can
     * only be detected through the registry — there is no deletion event. A
     * dead non-default participation is withdrawn here (its Claims and
     * Attention release through the normal leave path); a dead default
     * Workspace is left alone — activation fails on its missing cwd and the
     * Member surfaces as unavailable for Human attention.
     */
    private sweepWorkspaceParticipations;
    /**
     * Whether one Member Session has durable persisted content, decided through
     * {@link SessionPersistence.stat} rather than a bare metadata listing: the
     * backend reports a still-draining session through its pending header, so a
     * resume racing a suspend's fire-and-forget final flush cannot mistake a
     * still-draining persisted Session for an unpersisted one and fork a fresh
     * generation over it.
     */
    private sessionPersisted;
    /** Resolve one exact live Agent to its durable Team Member; forks do not inherit identity. */
    memberForAgent(agent: Agent): AgentTeamAgentMember | undefined;
    /** Return every durable Member with current process availability. */
    members(): readonly AgentTeamAgentMemberStatus[];
    /** Read-only navigation lookup for branded Task refs found in message bodies. */
    resolveTaskRefs(request: AgentTeamResolveTaskRefsRequest): AgentTeamResolveTaskRefsResult;
    /** Read-only navigation lookup for branded Thread refs found in message bodies. */
    resolveThreadRefs(request: AgentTeamResolveThreadRefsRequest): AgentTeamResolveThreadRefsResult;
    /** Browser-safe Human roster, optionally filtered to one participation. */
    membersForClient(request: AgentTeamMembersRequest): readonly AgentTeamClientMemberStatus[];
    /**
     * Human read behind the Prompt dialog: the stored prompt profile, the
     * lifecycle facts it renders from, and — when the Member has a live
     * session — its actual assembled sections once, with drop/protection/stale
     * marks the dialog and the runtime listener agree on, the usage projection
     * folded from the Member's own session logs, and — with the autoPrune switch
     * on — the zero-use candidate list the confirm surface renders from.
     */
    memberPromptView(request: AgentTeamMemberPromptViewRequest): Promise<AgentTeamMemberPromptView>;
    /**
     * Human read behind the session-history dialog: every Session generation
     * this Member has run, newest first. The walk follows the stored
     * `parentSession` fork lineage from the live handle's Session — or, when no
     * generation is live, from the ledger-bound Session — the live generation
     * reads through its handle, archived ancestors through the stored-session
     * reader — capped at the same depth as the timeline and the usage fold. An
     * unreadable ancestor degrades to a metadata-less entry and ends the walk;
     * the list never claims depth it could not verify. A current binding that
     * cannot be read (a transition committed while its Session never landed)
     * degrades the same way but continues at the predecessor the ledger
     * recorded, so archived history survives the newest generation's crash. A
     * durable binding that has already moved past the live handle (a context
     * transition in progress) never enters the list: the bound Session may not
     * exist on disk yet, while the handle's generation still carries the newest
     * readable events.
     */
    memberSessions(request: AgentTeamMemberSessionsRequest): Promise<readonly AgentTeamMemberSessionSummary[]>;
    /**
     * One bounded transcript page of one generation from the same lineage walk:
     * the generation's OWN events only (the fork-inherited prefix belongs to
     * the ancestor page), newest tail first, older pages reached through the
     * returned cursor. A Session outside the Member's lineage is refused —
     * this read never becomes a general session reader.
     */
    memberSessionTranscript(request: AgentTeamMemberSessionTranscriptRequest): Promise<AgentTeamMemberSessionTranscript>;
    /**
     * The lineage walk: the requested Member's own generations newest-first,
     * then — when it carries a supervision succession edge — the predecessor's
     * generations, and so on through the chain. Each Member's own walk follows
     * the Session `parentSession` chain (fork generations) and the ledger's
     * recorded `previousSessionForMember` fallback for an unreadable current
     * binding. The whole walk is bounded by `MAX_TIMELINE_ANCESTORS`, and a
     * `seen` set keeps a corrupt cycle from looping; a missing or unreadable
     * predecessor ends the walk safely instead of throwing.
     */
    private memberSessionLineage;
    /**
     * One-shot LLM curation for the Prompt dialog, propose-only. The call rides
     * the Host context's public `llm.stream()` seam (the same in-process path
     * compaction summarizers use) on the Member's effective route, races the
     * client's cancellation signal against a fixed timeout, and returns a
     * validated proposal. It never commits anything: the only durable prompt
     * paths stay member-updated (edit) and member-added (create), and the
     * proposal only ever backfills the dialog form for the Human to review.
     * Input covers the live assembled sections (name, bounded text, protected
     * and prose marks), the private skills catalog names, the member identity,
     * and the Human's requirements; the reply is parsed defensively and every
     * proposed name is re-validated against the live section set and catalog
     * before it reaches the dialog. Requires an enabled Member with a live
     * session — the section input IS the live assembly.
     */
    curateMemberPrompt(request: AgentTeamCurateMemberPromptRequest, signal?: AbortSignal): Promise<AgentTeamCurateMemberPromptResult>;
    /** Build the bounded curation input from one live assembly and catalog. */
    private curateInput;
    /** Run the one-shot completion and parse + re-validate its proposal. */
    private curationProposal;
    /**
     * Assemble the Member's scope once (read-only, the same assembly its next
     * step gets) and derive the dialog's section entries plus the auto-prune
     * projection: the stored drop list provides dropped/stale marks, the shared
     * protection set refuses drops at consumption and marks them here, the
     * section→tools mapping flags prose-only sections and prices each section's
     * usage from the window fold, and zero-use mapped sections become the
     * candidates. Stored names the current assembly no longer knows render as
     * inert stale entries; a protected name renders protected rather than dropped
     * even when the ledger still lists it. A Member disposed mid-assemble (or any
     * assemble failure) degrades to no projection — the dialog renders its
     * no-live-session state and the Host log carries the diagnostic — instead of
     * a raw throw.
     */
    private promptSectionProjection;
    /**
     * Fold the Member's candidate window (last 20 completed turns or 14 days,
     * whichever closes first) from its own session logs across the rollover
     * lineage: the live generation folds directly, archived ancestors through
     * the stored-session reader, each contributing only its own events so the
     * fork-inherited prefix never double counts. An unreadable ancestor or a
     * lineage deeper than the walk cap degrades the fold to `partial`.
     */
    private memberWindowUsage;
    /** Emit a current baseline, then coalesced invalidations until canceled. */
    changes(request: AgentTeamChangesRequest, signal?: AbortSignal): AsyncIterable<AgentTeamChangesResult>;
    /** Return durable Team status without issuing a model request or a storage write. */
    status(): AgentTeamStatus;
    createChannel(request: AgentTeamCreateChannelRequest): Promise<AgentTeamCreateChannelResult>;
    /** Human rename of one Channel's display facts; identity refs are immutable. */
    updateChannel(request: AgentTeamUpdateChannelRequest): Promise<AgentTeamUpdateChannelResult>;
    /**
     * Archive one Channel: hidden from every surface with all facts kept. Pure
     * ledger projection change — Member sessions stay live (they may work in
     * other Channels), every active Claim on the Channel's Threads releases,
     * and affected Members' Attention clears.
     */
    archiveChannel(request: AgentTeamArchiveChannelRequest): Promise<AgentTeamArchiveChannelResult>;
    /** Create a durable Member and atomically grant its declared initial Channels. */
    addMember(request: AgentTeamAddMemberRequest): Promise<AgentTeamAddMemberResult>;
    /** Commit suspended intent, then wait for the owned AgentHandle to become quiescent. */
    suspendMember(request: AgentTeamSetMemberStateRequest): Promise<AgentTeamMemberResult>;
    /** Commit enabled intent and restore the exact persisted Session. */
    resumeMember(request: AgentTeamSetMemberStateRequest): Promise<AgentTeamMemberResult>;
    /**
     * Operator nudge for a Member that stopped making progress: complete an
     * interrupted context transition, steer a continuation prompt into its live
     * session, rebuild it after an orphaned preset composition, or re-run
     * activation when no live session exists. Runtime-only — no ledger
     * operation, no suspend. Taking over manually also cancels any pending
     * automatic recovery episode.
     */
    recoverMember(request: AgentTeamRecoverMemberRequest): Promise<AgentTeamRecoverMemberResult>;
    /**
     * Start one enabled Member from a new context: dispose the live handle,
     * archive the previous Session (its log stays on disk for history), and
     * activate a fresh Session under a new sessionId, so preset, tools, private
     * memory, and model selection all reload while the next turn carries no
     * history. The durable operation moves the Member's sessionId; identity,
     * memory path, and binding survive. A new id is what keeps the Web Client
     * seat live: a disposed generation's resident instance keeps its `removed`
     * bit forever, so renewing under the same id would leave a permanently
     * grayed session view.
     */
    clearMemberContext(request: AgentTeamClearMemberContextRequest): Promise<AgentTeamClearMemberContextResult>;
    /**
     * The one context-renewal path shared by every reset caller — the Human
     * menu's reset row, supervision's forced fallback reset, the doctor
     * diagnostic reset, and the fresh-start task policy: commit the idempotent
     * ledger renewal, retire the previous generation, activate the fresh
     * Session, and privately notice the reset Member. The fresh id derives from
     * the requestId, so a retried identical request mints the same id and the
     * ledger dedupes it instead of colliding; the format matches addMember's
     * `agent-team-<uuid>`. Callers own their own preconditions (participation,
     * enabled state, running-turn refusal) — this core only refuses a Member
     * with no live generation.
     */
    private renewMemberContextNow;
    /**
     * Privately notice the reset Member itself after its context renewal: one
     * runtime notice — never a ledger Message — telling it the Session was
     * reset, that its handle, settings, and private memory are unchanged and
     * durable Team facts survived, and how to re-orient: the injected memory
     * index names what was in hand, recent Team history is durable in the
     * ledger through `team_view`, `team_inbox`, and `team_thread`, and whatever
     * stays unclear it asks the teammates concerned instead of guessing. The
     * Team is not broadcast to: a reset moves no durable Team fact, and the
     * Member's next ordinary messages carry its state. Doctor dispatches skip
     * it — the reset is an internal step of a one-shot diagnostic whose prompt
     * arrives immediately. A failed delivery only logs: the renewal itself is
     * already durable when this runs.
     */
    private notifyMemberContextReset;
    /**
     * Human-requested in-place context compaction for one enabled Member's live
     * Session. The remote only validates and schedules: the compaction runs in
     * the background at the Member's next true idle boundary through the public
     * compaction-basic engine, so it is inserted after the Member's current
     * actions without blocking later conversation — input that arrives meanwhile
     * queues and is served once the compaction settles (runMaintenance latches
     * waking input, it never drops it).
     *
     * The engine instance is transient and carries the Human-selected
     * summarization LLM in its config; it shares the Host context's public
     * llm/tokenMeter/sessions seams and reuses exactly the implementation the
     * Team preset mounts (see docs/architecture.md). Failures surface through
     * the Member's compaction failure slot, the same diagnostic surface the
     * pressure policy reports through.
     */
    compactMemberContext(request: AgentTeamCompactMemberContextRequest): Promise<AgentTeamCompactMemberContextResult>;
    /**
     * Background body of one scheduled compaction. Waits for the Member's idle
     * boundary, then forces one useful reduction even below the pressure
     * threshold. A member that stays busy (fresh waking input between idle
     * checks) is retried a bounded number of times and then silently dropped —
     * conversation takes precedence over the optional reduction. A real
     * compaction failure reports through the compaction failure slot.
     */
    private runMemberCompaction;
    /**
     * Schedule the context reset one Member's fresh-start task-start policy
     * calls for. Claim and Human atomic-start boundaries schedule it directly;
     * an armed Member (its last turn completed with the marker) schedules it
     * when its next dispatch delivers new unread work. continue policy (the
     * absent default) never does. One in-flight body per Member: concurrently
     * overlapping schedules merge into a single reset. Returns whether a reset
     * is now scheduled or already in flight — a false tells the caller to keep
     * its own delivery (there is nothing to wait behind).
     */
    private scheduleFreshStartReset;
    /**
     * Arm the fresh-start policy after one completed stop announced the marker:
     * the renewal belongs to the next dispatch, never to the completion itself.
     * continue Members never arm, and an already-armed Member re-arming is the
     * same one pending reset.
     */
    private armFreshStartReset;
    /**
     * Whether one dispatch goes to the model for the keep-or-renew decision at
     * all. That discrimination is the Team's own judgement about its work, so it
     * runs only where a Team actually has someone who owns the call: the Workspace
     * needs an enabled designated leader. Without one the fresh-start policy
     * behaves as it always did — the next assignment renews.
     */
    private hasDesignatedLeader;
    /**
     * Ask the model whether the incoming assignment continues the work this Member
     * already holds: its last {@link DISPATCH_HISTORY_MESSAGE_LIMIT} authored
     * Messages plus the content of the Task it most recently claimed. A score of
     * {@link CONTEXT_RELEVANCE_THRESHOLD} or above keeps the live Session; every
     * other outcome — a lower score, a reply with no usable number, a provider
     * error, a timeout, or no LLM service at all — renews, because the Member's
     * own configuration promises a fresh context per task and the judgement is only
     * an exception to it. The score is logged so each erase-or-keep call stays
     * auditable.
     */
    private dispatchRelevanceKeepsContext;
    /**
     * Start the one judgement a dispatch deserves, holding its Inbox wake until
     * the answer lands: the sequence the call was made for is remembered so a
     * "keep" exempts exactly that delivery, and a second dispatch arriving while
     * the model is thinking waits its turn rather than starting a parallel call.
     * Fire-and-forget: a lost judgement must never strand a dispatch, so the body
     * always ends by releasing the hold and re-deriving the delivery.
     */
    private judgeFreshStartDispatch;
    /** Background body of one dispatch judgement: decide, release the hold, deliver. */
    private runFreshStartJudgement;
    /**
     * Background body of one scheduled fresh-start reset. A claim fires inside
     * the Member's own turn, so the reset waits for the turn boundary and
     * converges like executeMemberTransition. A generation swap while it waits
     * (a rollover, a restart resume, or any context change) re-binds the wait
     * to the live handle instead of dropping the scheduled reset with the old
     * one — bounded by {@link POLICY_RESET_MAX_BINDINGS} re-bindings. Then it
     * re-reads the Member at the boundary (a concurrent edit may have changed
     * the policy) and runs the same durable renewal the Human reset path uses.
     * When the reset renews, the activation inside delivers the rederived Inbox
     * wake — the queued dispatch reaches the fresh generation instead of the
     * doomed context. When the body gives up (policy moved, Member gone, or the
     * re-binding budget spent without renewing), it re-derives the wake on the
     * live handle itself so a gated delivery is never lost. Failures are
     * logged, never thrown and never retried — the next boundary schedules
     * its own reset.
     */
    private runFreshStartReset;
    /**
     * Schedule one auto-prune sweep behind a task-start boundary (claim or Human
     * atomic start), mirroring the fresh-start reset seam: same one-in-flight
     * dedupe, same turn-boundary wait, same serialized lifecycle body. Only a
     * Member with the autoPrune switch on sweeps; everyone else pays one ledger
     * read and never prunes.
     */
    private scheduleAutoPruneSweep;
    /**
     * Background body of one scheduled auto-prune sweep. Like the fresh-start
     * reset it waits for the turn boundary, re-reads the Member there (a
     * concurrent edit may have turned the switch off), and runs inside the
     * serialized lifecycle queue. Failures are logged, never thrown and never
     * retried — the next task start schedules its own sweep.
     */
    private runAutoPruneSweep;
    /**
     * One sweep's decision body, already holding the folded projection (the
     * fold ran before the queue; whole-file session reads must not block
     * lifecycle ops). Re-validates each candidate cheaply against the folded
     * entries — a name that no longer maps to a live, unprotected, tool-mapped
     * entry is skipped — and, with none left, does nothing. Ask mode (the
     * default, and the full-auto mode degraded by a partial usage fold —
     * unreadable history can only under-count, so a partial fold never drives
     * an automatic drop) posts the inbox notice and leaves the candidates for
     * the dialog's confirm surface. Full-auto commits the candidates as one
     * durable member update through the same echo-complete shape the Human
     * editor uses, live-applies the drop list at the settled boundary, and
     * still posts the notice naming what was pruned — every automatic drop
     * stays ledger-recorded and traceable.
     */
    private runAutoPruneBody;
    /**
     * Post one auto-prune notice on every Channel the swept Member belongs to,
     * addressed to the Human by mention so it lands in the Human inbox. Ask mode
     * asks for confirmation; full-auto documents what was committed. The notice
     * is Member-voiced, and failures are logged, never thrown — the
     * drop itself is already durable when this runs.
     */
    private announceAutoPrune;
    /**
     * One manual compaction with the summarizer fallback chain: the
     * Human-selected (or session-default) LLM first, then — when the attempt
     * fails on a real error rather than a busy Member — the Host catalog's other
     * configured routes, up to {@link MAX_COMPACTION_FALLBACK_ATTEMPTS}. A
     * persistently busy Member loses no data and is silently dropped
     * (conversation takes precedence over the optional reduction); an
     * exhausted fallback chain rethrows the original failure into
     * {@link runMemberCompaction}'s failure reporting.
     */
    private manualCompactionWithFallback;
    /** The effective model route of one Member, or the Host default when unset. */
    private currentModelSelectionOf;
    /**
     * The Host catalog's other configured provider/model pairs, excluding the
     * Member's current route — the candidate summarizers for the compaction
     * fallback. Provider enumeration never throws; a provider whose model list
     * fails is logged and skipped, and an unreachable LLM service yields no
     * candidates (the caller keeps its original failure).
     */
    private fallbackCompactionSelections;
    /**
     * The policy-side compaction fallback ({@link PressurePolicyCoordinator}'s
     * `compactWithFallback`): after the Member-scoped engine's forced reduction
     * throws, try the other configured LLM routes — up to
     * {@link MAX_COMPACTION_FALLBACK_ATTEMPTS} — and report whether any of them
     * advanced the durable surface. The coordinator still re-measures pressure
     * itself, so a fallback that ran without reducing anything fails closed
     * exactly like the original failure.
     */
    private policyCompactWithFallback;
    /**
     * Human-dispatched failure diagnosis. Resolves (or creates) the persistent
     * `doctor` Member, joins it to the failed Member's Channels so the report
     * can be traced there, starts it from a fresh context — the same renewal the
     * Human menu's reset performs — and steers the failed Member's bounded
     * session transcript into that fresh session as the research subject. The
     * doctor reports by direct message to the Human and as a Thread in the
     * failed Member's Channel; nothing in this remote waits for the analysis.
     */
    diagnoseMember(request: AgentTeamDiagnoseMemberRequest): Promise<AgentTeamDiagnoseMemberResult>;
    /**
     * Resolve the persistent doctor Member for one Workspace, creating it on
     * first use: same Team Member preset, private memory like any other Member.
     * The doctor joins the failed Member's Channels — granted atomically at
     * creation, backfilled per dispatch for a reused doctor — so the analysis
     * can be recorded as a Thread where the failed work happened, not only as a
     * direct message. A disabled or archived `doctor` blocks the plain handle,
     * so a re-creation takes the same numbered-generation path a supervision
     * replacement does.
     */
    private ensureDoctorMember;
    /**
     * The research material for one diagnosis: the failed Member's session log —
     * the live generation's own events when it still has one, the persisted log
     * otherwise — rendered as a bounded transcript, plus the Member's recorded
     * failure diagnostic (runtime first, then compaction, then activation).
     */
    private failureTranscriptFor;
    /**
     * Retire one Member's previous generation after its durable binding moved
     * onto a new Session id: drop the old handle's transient state, dispose the
     * Agent, and archive the old Session log (which stays on disk for history).
     * Shared by the Human clear path and the model-initiated rollover.
     */
    private retireMemberGeneration;
    /**
     * Execute one prepared context rollover at a true idle boundary: commit the
     * idempotent Member-actor operation, retire the previous generation, and
     * activate the fresh Session whose first model-facing context is the
     * Member's own handoff. Later non-Team input captured during the transition
     * is delivered after the handoff; the Team Inbox is rederived from the
     * ledger, never copied.
     */
    private executeMemberTransition;
    /** Ledger handle for log lines; falls back to the raw id when unknown. */
    private memberLabel;
    /**
     * Cache GC: uploads referenced by a Message survive 72h from upload so
     * Member agents keep a consumption window; orphans (never sent) go after
     * 24h. Runs once at startup and then daily — in-process only, because the
     * cache is transient by design and rebuilds nothing across restarts.
     */
    private startAttachmentGc;
    private automaticResumeText;
    private manualResumeText;
    /**
     * Steer one continuation message into a Member's live session. Throws when
     * no handle exists so the coordinator stops tracking; appends the inbox
     * snapshot whenever there is anything new to read.
     */
    private steerResume;
    /** Automatic-recovery wakeup; throwing tells the coordinator the target is gone. */
    private injectRecovery;
    /**
     * Run one supervision tick now: the periodic timer calls this, and a test or an
     * operator can drive it directly. Open escalation steps advance before the
     * pass's own bring-up budget runs — the same order the timer uses, so a chain
     * that stalled on a failed reset is retried here rather than nudged past.
     * Overlapping ticks are skipped by the policy, never queued, so a slow
     * handover cannot pile up more work behind itself.
     */
    runSupervisionPass(): Promise<void>;
    /**
     * Run one completion-liaison pass now: the periodic timer calls this, and a
     * test or an operator can drive it with a chosen clock (the grace and
     * cooldown windows measure against the passed time).
     */
    runCompletionLiaisonPass(now?: number): Promise<void>;
    /**
     * What supervision sees of one Member: a live Session whose preset composition
     * survived and no failure record. A context rollover or an in-flight turn is
     * `settling` (this policy never interrupts either) — except a turn that has
     * produced no durable Session event for {@link SUPERVISION_HUNG_MS}: a healthy
     * turn emits events continuously, so that much silence while nominally running
     * is a wedge, and the policy must act on it rather than wait forever. Anything
     * the roster reports as unreachable or erroring is the abnormal stop it acts
     * on. A Member that is live and simply idle with open Claims is waiting by
     * design. Reading healthy again drops any escalation progress: the chain only
     * ever advances while the Member stays abnormal.
     */
    private supervisionStateOf;
    /**
     * One supervised bring-up: the same repair `recoverMember` performs, chosen by
     * what is actually missing. No live Session (or an orphaned composition) is
     * rebuilt; any other live Agent that stopped mid-work gets the automatic
     * continuation prompt. The next pass judges the attempt, so a throw here only
     * means it did not help.
     */
    private restartMemberUnderSupervision;
    /**
     * The give-up entry into the coercion chain: record the episode and run the
     * Host's own context reset immediately — the same fresh-context renewal the
     * Human menu performs, privately noticed to the reset Member alone. Nothing
     * is broadcast asking teammates to reset it: the Member re-orients from its
     * memory and the durable Team history and asks its teammates about whatever
     * stays unclear. A further give-up callback for the same episode re-enters
     * here as a no-op, and the chain's last resort — the archive-and-replace
     * handover — advances in {@link runSupervisionPass} only while the Member
     * still reads abnormal after the reset.
     */
    private escalateSupervisedMember;
    /**
     * Kick off the retirement recap outside the ledger queue: a one-shot,
     * propose-only digest of the Member's final Session whose result lands in a
     * per-Member slot the later handover reads without waiting. It never enters
     * the ledger, never becomes a Team fact, and never fails the handover — a
     * timeout, abort, or model error simply leaves no recap to append.
     */
    private startRetirementRecap;
    /**
     * The best-effort recap itself: the retired Member's own final-Session
     * transcript, newest 20 entries, through the shared digest shape on the
     * Member's pinned model (the Host default when it pinned none). It reads only
     * the Member's bound Session — never an inherited ancestor — and resolves
     * `undefined` on any failure or timeout instead of throwing.
     */
    private retirementSessionRecap;
    /**
     * The recap input: the Member's own final-Session transcript folded to the
     * digest's message shape, newest 20 entries. The live handle is preferred
     * while the Member's bound Session still has one; a stored read covers the
     * case where the failed mount has already released it.
     */
    private retiredFinalSessionDigestInput;
    /**
     * Advance every open escalation while its Member is still abnormal: a reset
     * step that never committed retries, and a reset that did not heal the
     * Member becomes the archive-and-replace handover. A
     * Member that reads healthy (or left the roster) drops out of the chain —
     * a reset that healed it re-arms the gentle bring-up for any future
     * episode. Failures are logged, never thrown: the next pass retries the
     * same step.
     */
    private advanceSupervisionEscalations;
    /**
     * Delivery for the idle-continuation watcher: the nudge rides the ordinary
     * mention path in the Team Assistant's voice — the Host's own supervision
     * identity, never the Human's — posted into the leader's Channel holding
     * the most named open Tasks (ties fall back to the oldest), with the leader
     * as the only explicit recipient. A throw is caught by the watcher and
     * logged — the next episode retries.
     */
    private announceContinuationNudge;
    /**
     * Channel pick for a liaison delivery addressed at one Member: their own
     * Channels in the Workspace, ranked by how many of the named open Tasks
     * each holds (ties fall back to the oldest, like the continuation nudge),
     * so the notice lands where the work actually lives.
     */
    private liaisonChannelFor;
    /**
     * Report-check delivery: the Team Assistant's voice names the idle Member
     * in the leader's oldest Channel of the Workspace, with the leader as the
     * only explicit recipient — the ordinary Inbox path wakes them into a turn.
     */
    private notifyLiaisonLeader;
    /**
     * Truncation-escalation delivery: the Team Assistant's voice names the
     * truncated Member in the leader's Channel for the Workspace, with the
     * leader as the only explicit recipient — the ordinary Inbox path wakes
     * them into a turn where they decide what happens to the Member.
     */
    private notifyLeaderOfTruncation;
    /**
     * Open-Task push for a leaderless Workspace: the Member's busiest Channel,
     * the Member as the only explicit recipient, in the Team Assistant's voice.
     * The mention is direct work, so a fresh-context Member armed at completion
     * consumes its arm first and reads the Task list in the fresh generation.
     */
    private pushLiaisonTasks;
    /**
     * Interrupt-resume delivery: a runtime notice steered into the finished
     * Member's own Session (the context-reset notice shape — never a ledger
     * Message, since a resume is the Member's private context bookkeeping, not
     * a Team fact). It names the pending stack and the resume action so the
     * Member runs its pre-completion analysis against the durable interrupt
     * projection. A Member with no live handle throws: the lane stays retryable
     * for the next episode, exactly like the task push.
     */
    private pushLiaisonInterrupts;
    /**
     * Declined-push relay: the refusing Member speaks in its own Channel (the
     * auto-prune notice shape — it speaks for itself rather than through the
     * Team Assistant), quoting its decision verbatim so only the Channel
     * carries the feedback to the Human.
     */
    private notifyLiaisonFeedback;
    /**
     * The chain's reset step: the Host performs the same context reset the Human
     * menu performs ({@link renewMemberContextNow} — durable renewal, generation
     * retire, fresh activation, private notice), retiring the wedged generation.
     * This is the one caller allowed to retire a generation that is nominally
     * still running: a hung Member never reaches idle, so refusing running
     * Agents here would make the fallback unreachable — disposal aborts the
     * wedged turn, and the durable binding has already moved by the time the old
     * Agent dies.
     */
    private forceResetSupervisedMember;
    /**
     * The terminal supervision action: archive the Member that cannot be brought
     * back and put a same-role generation in its place.
     *
     * Every fact this writes is an ordinary ledger operation committed under the
     * Host's Human authority, inside one serialized lifecycle step, so no Remote
     * call interleaves with the handover. The successor is added and activated
     * first, and the predecessor is archived only once that activation is real;
     * a successor that cannot come up is rolled back and the failure rethrown, so
     * the escalation stays open and the next pass retries the same step rather
     * than leaving the Team with an archived Member and no live replacement. What
     * the replacement inherits is the role
     * (preset, description, pinned model, capabilities), the private memory, and
     * the Channel reach of its predecessor; never its Session log. The abandoned
     * work itself becomes durable Team facts through archival's own
     * `claims_released` Activities, and the public notice asks the Human admin to
     * reassign those Tasks to the new handle.
     */
    private handOverSupervisedMember;
    /**
     * Human edit of one Member's mutable facts. A live model selection is
     * updated in place: disposing an Agent emits session/disposed, which makes
     * the Web Client permanently mark the same Session id unavailable even when
     * Team immediately recreates it.
     */
    updateMember(request: AgentTeamUpdateMemberRequest): Promise<AgentTeamMemberResult>;
    /**
     * Schedule the live swap one capability or prompt edit of a Member calls
     * for, mirroring the fresh-start reset and auto-prune seams: the durable
     * edit answers immediately and the turn-boundary wait runs OUTSIDE the
     * serialized lifecycle queue, so a long — or hung — turn never holds the
     * edit's response, another Member's edit, or the supervision force-reset
     * behind it. One in-flight body per Member: overlapping edits coalesce,
     * because the body re-applies the CURRENT ledger facts rather than the
     * snapshot it was scheduled from. No active handle means nothing to swap:
     * activation re-applies everything from the ledger. An idle Member has no
     * boundary to wait for, so its swap stays synchronous inside the edit's own
     * queue body and the answer already reflects the live surface.
     */
    private scheduleMemberRuntimeApply;
    /**
     * Background body of one scheduled runtime apply. While the Agent runs, the
     * current turn keeps its schemas, catalog, and assembled prompt; the swap
     * happens once the turn ends, with the same Session and history surviving.
     * The handle is re-checked unconditionally after the wait — the wait may
     * have resolved because the old generation was disposed rather than because
     * the turn ended, and an external Session dispose can move the generation on
     * without the Team queue ever seeing it. A stale handle bails: the disposed
     * scope released the old restriction, section, and drop listener already, no
     * disposer leaks, and the ledger intent applies at the next activation
     * instead. Like the sweep, the body re-reads the Member at the boundary and
     * again inside the queue — lifecycle edits and suspensions can commit while
     * it waits — and a Member that is no longer stored or no longer enabled
     * drops. Failures are logged, never thrown and never retried: the durable
     * edit already landed.
     */
    private runMemberRuntimeApply;
    /**
     * Re-apply both live halves — the capability swap (restriction, then the
     * skill-selection filter) and the prompt swap (custom section, then the drop
     * listener) — from the Member's current ledger facts. Both halves always
     * run, whichever one the edit touched: each primitive is release-then-apply,
     * every release is a no-op when nothing was ever registered, and every apply
     * registers nothing when the stored field is absent (an absent allow-list, a
     * blank paragraph, an empty drop list). Re-applying an unchanged half is
     * therefore an idempotent swap of the same surface, and the coalesced body
     * stays correct for whichever halves the edits in flight actually changed.
     */
    private applyMemberRuntime;
    /** Irreversibly remove one Member, archive its Session, and delete its private namespace. */
    removeMember(request: AgentTeamRemoveMemberRequest): Promise<AgentTeamRemoveMemberResult>;
    /**
     * Archive one Member: commit the archival, stop its live session (disposal
     * only — private memory and the Session log stay on disk for a future
     * restore), and archive the Session from every grouping surface. Like
     * removal, all active Claims release and the Member's Attention clears.
     */
    archiveMember(request: AgentTeamArchiveMemberRequest): Promise<AgentTeamArchiveMemberResult>;
    /** Human-only Task resolution. Business fences are returned as typed outcomes. */
    changeTask(request: AgentTeamTaskRequest): Promise<AgentTeamTaskResult>;
    /** Human-only batch Task resolution: acceptance or closing for several Tasks in one turn. */
    changeTasks(request: AgentTeamTasksBatchRequest): Promise<AgentTeamTasksBatchResult>;
    /** Human-only promotion of a taskless Thread into a real Task plus public Message. */
    promoteThread(request: AgentTeamPromoteThreadRequest): Promise<AgentTeamPromoteThreadResult>;
    /** Human-only Channel membership grant; it never injects historical Thread bodies. */
    joinChannel(request: AgentTeamJoinChannelRequest): Promise<AgentTeamJoinChannelResult>;
    /** Human-only Channel membership removal and Channel-scoped cleanup. */
    removeChannelMember(request: AgentTeamRemoveChannelMemberRequest): Promise<AgentTeamRemoveChannelMemberResult>;
    /** Human-only Workspace participation grant; a pure relation — no Session moves. */
    joinWorkspace(request: AgentTeamJoinWorkspaceRequest): Promise<AgentTeamJoinWorkspaceResult>;
    /** Human-only Workspace participation withdrawal and Workspace-scoped cleanup. */
    leaveWorkspace(request: AgentTeamLeaveWorkspaceRequest): Promise<AgentTeamLeaveWorkspaceResult>;
    /** Human top-level Thread start; asTask attaches an optional Task overlay. */
    sendMessage(request: AgentTeamSendMessageRequest): Promise<AgentTeamSendMessageResult>;
    /**
     * Resolve uploaded ids and agent-supplied absolute paths into one attachment
     * metadata list. Paths are all validated before anything is copied, so one
     * rejection leaves the cache untouched and the message uncommitted.
     */
    private resolveMessageAttachments;
    /** Verify requested attachment ids against the cache. */
    private prepareAttachments;
    /**
     * Derive the stored body: one machine-facing `[attachment] <absolute path>`
     * line per attachment appended to the member-facing text.
     */
    private appendAttachmentLines;
    /** Upload one composer attachment into the cache; bytes are immutable once written. */
    putAttachment(request: AgentTeamPutAttachmentRequest): Promise<AgentTeamPutAttachmentResult>;
    /** Read one cached attachment back for client display; gone entries throw and the UI degrades to a chip. */
    getAttachment(request: AgentTeamGetAttachmentRequest): Promise<AgentTeamGetAttachmentResult>;
    /**
     * Human profile read for the settings page and footnote: name + avatar
     * reference from this Host row's live Config plus version facts. Human-scoped
     * (the Web Client calls it); agent tools never receive avatar bytes, only the
     * name through team_view. The new-release check stays best-effort and cached —
     * `updateAvailable` is false until a background refresh actually observes a
     * newer published release.
     */
    /**
     * Local environment check for the settings page: which DSH line this Host
     * runs against, and whether that line is inside the range this bundle
     * declares. Human-scoped and read-only — the Client renders the verdict and
     * states the range in words, and nothing here is written back.
     *
     * Synchronous like `humanProfile`: both read the installed manifest once and
     * settle immediately, and the verdict comes from the Harness's own
     * compatibility evaluator rather than a second version comparison written
     * here.
     *
     * The wire type and `EnvironmentReport` keep separate top-level field lists on
     * purpose: the contract states every fact as optional because a Transport may
     * withhold any of them, while the report is the stricter thing the checker
     * guarantees. This assignment is where the compiler holds the two together,
     * and a new required contract field fails it here.
     */
    environmentForClient(_request: AgentTeamEnvironmentRequest): AgentTeamEnvironmentResult;
    humanProfileForClient(_request: AgentTeamHumanProfileRequest): AgentTeamHumanProfileResult;
    /**
     * Upload one human avatar image into the persistent store. Human-only by
     * construction: only the Web Client calls this Remote, never agent tools.
     * The caller stores the returned ref in settings; bytes never enter the
     * TTL-bound attachment cache.
     */
    putHumanAvatar(request: AgentTeamPutHumanAvatarRequest): Promise<AgentTeamPutHumanAvatarResult>;
    /** Read one human avatar back; removed entries throw and the UI falls back to hue/initial. */
    getHumanAvatar(request: AgentTeamGetHumanAvatarRequest): Promise<AgentTeamGetHumanAvatarResult>;
    /** Remove one human avatar entry; the UI falls back to hue/initial afterwards. */
    removeHumanAvatar(request: AgentTeamRemoveHumanAvatarRequest): Promise<AgentTeamRemoveHumanAvatarResult>;
    /**
     * Overwrite the Human profile fields the caller supplies. The Host owns this
     * write because the profile is the Host row's own Config: the schema supplies
     * the shape, this method supplies the two judgements the schema cannot make
     * (a non-empty name, a name no live Member already answers to), and the
     * settings service persists the result into the active profile's patch
     * document and applies it to the running plugin live.
     *
     * No expected revision accompanies the write: the profile is two scalar
     * fields written from the Human's own pages, where the last write wins. This
     * is not a hard boundary around a user-editable document — the settings
     * service's own document opener (and a text editor) can change the stored
     * name without passing here, exactly as the retired section validator could
     * not stop it.
     */
    setHumanProfile(request: AgentTeamSetHumanProfileRequest): Promise<AgentTeamSetHumanProfileResult>;
    /** Human existing-Thread reply; unread and revision conflicts are business outcomes. */
    reply(request: AgentTeamReplyRequest): Promise<AgentTeamReplyResult>;
    /**
     * Human correction of one Human-sent Message. The executor candidates are
     * read from the pre-commit projection, the ledger commits the body swap, and
     * only then — before the commit's wake is emitted — is every Member that may
     * be executing the old body (mentioned, read through, currently running)
     * force-stopped with its Inbox intact. Cancel first, wake second: the
     * corrected instruction is re-delivered through the re-added markers and
     * replays after the aborted turn converges instead of racing it.
     */
    editMessage(request: AgentTeamEditMessageRequest): Promise<AgentTeamEditMessageResult>;
    /**
     * Human retraction or deletion of one Human-sent Message, with the same
     * pre-commit executor snapshot and force-stop ordering as the edit. A recall
     * adds no marker, so the commit wake names nobody: the stopped Members learn
     * of the withdrawal through an explicit notice, and every other reader sees
     * the tombstone (or nothing, for a deletion) on its next look.
     */
    recallMessage(request: AgentTeamRecallMessageRequest): Promise<AgentTeamRecallMessageResult>;
    /** Abort the running subset; their queued work survives (keepInbox) and the commit's wake replays it. */
    private forceStopExecutors;
    /** Plain-language withdrawal notice to force-stopped Members: this instruction is dead, the rest of the queue continues. */
    private notifyRecalledInstruction;
    /** Human's personal Attention operation. */
    changeAttention(request: AgentTeamThreadAttentionRequest): Promise<AgentTeamThreadAttentionResult>;
    /** Human Inbox projection; the Web Client consumes the direct-only slice as its mention queue. */
    inbox(request: AgentTeamInboxRequest): AgentTeamInbox;
    /**
     * Human's cross-Channel Task list: every Task with its sub-task linkage and live progress.
     */
    tasks(request: AgentTeamTasksRequest): AgentTeamTasks;
    /** Human's per-Member working queues: current Claims and unclaimed Channel work, one read for the roster. */
    memberTasks(request: AgentTeamMemberTasksRequest): AgentTeamMemberTasks;
    /** Human's durable, atomically acknowledged Thread read. */
    readThread(request: AgentTeamThreadReadRequest): Promise<AgentTeamThreadReadResult>;
    /** Human-only durable Attention observations for one Thread. */
    threadObservations(request: AgentTeamThreadObservationsRequest): AgentTeamThreadObservations;
    /** Human's non-mutating bounded Thread history. */
    threadHistory(request: AgentTeamThreadHistoryRequest): AgentTeamThreadHistory;
    /**
     * Human one-shot plain-language Thread digest: propose-only, commits
     * nothing, the same ephemeral shape as Prompt curation. The call rides the
     * Host's public `llm.stream()` seam on the Team's own configured route
     * (`digestModelSelection`) with the
     * bounded Thread transcript, names resolved through the ledger's single
     * actor resolver so a name never reads differently on two surfaces. The
     * request is assembly-free: it carries only the digest instruction and the
     * transcript — no tools, skills, MCP, memory or Member identity — exactly
     * the one-shot shape Prompt curation uses. The
     * model's decision flag is merged with the ledger's own awaiting-acceptance
     * fact: a Task open at `in_review` is waiting on the Human even if the
     * digest call glossed over it.
     */
    summarizeThread(request: AgentTeamSummarizeThreadRequest, signal?: AbortSignal): Promise<AgentTeamSummarizeThreadResult>;
    /**
     * Model route for Team semantic processing (the Thread digest today): the
     * Workspace's enabled designated leader speaks for the Team, so its pinned
     * model runs the call — a leader without a pinned model effectively holds
     * the Host default, so the Host default is used. With no designated leader,
     * the first enabled Workspace Member that pinned a model interprets through
     * that Team-configured LLM; only when nobody pinned one does the call fall
     * back to the Host default route. Pure read-side routing: it never writes
     * Member facts and never wakes anyone.
     */
    private digestModelSelection;
    /** Return the existing bounded public Workspace discovery projection. */
    view(request: AgentTeamViewRequest): AgentTeamView;
    /** Agent-only top-level Thread start. Workspace identity is verified against the live binding. */
    sendMessageForAgent(agent: Agent, request: AgentTeamSendMessageRequest): Promise<AgentTeamSendMessageResult>;
    /** Agent-only existing-Thread reply. */
    replyForAgent(agent: Agent, request: AgentTeamReplyRequest): Promise<AgentTeamReplyResult>;
    /** Agent-only personal Attention change. */
    changeAttentionForAgent(agent: Agent, request: AgentTeamThreadAttentionRequest): Promise<AgentTeamThreadAttentionResult>;
    attentionStatusForAgent(agent: Agent, request: {
        workspaceId: AgentTeamViewRequest['workspaceId'];
        threadRef?: AgentTeamThreadAttentionRequest['threadRef'] | undefined;
        taskRef?: AgentTeamTask['taskRef'] | undefined;
    }): AgentTeamThreadAttentionStatus;
    /** Agent-only Claim mutation. */
    changeClaimForAgent(agent: Agent, request: AgentTeamClaimRequest): Promise<AgentTeamClaimResult>;
    listClaimsForAgent(agent: Agent, request: {
        workspaceId: AgentTeamViewRequest['workspaceId'];
        taskRef: AgentTeamTask['taskRef'];
    }): AgentTeamClaimList;
    inboxForAgent(agent: Agent, request: {
        readonly workspaceId?: WorkspaceId;
        readonly limit?: number;
    }): AgentTeamInbox;
    readThreadForAgent(agent: Agent, request: AgentTeamThreadReadRequest): Promise<AgentTeamThreadReadResult>;
    /**
     * Context advice for one acceptance acknowledged by this read: only when
     * the read carried an unread accept activity AND the Task is still done.
     * Repeat reads (nothing unread), history-style reads, and reopened Tasks
     * carry no advice — the acceptance no longer stands.
     */
    private acceptanceContextAdvice;
    /** Price the reading Member's context against its current route's budgets. */
    private contextAdviceFor;
    private unavailableAdvice;
    /**
     * What the supervision pass reads about one fellow Member, surfaced to any
     * enabled Member through the team_supervise tool: the pass state, presence,
     * the recorded failure diagnostic, and the windowed failure count the policy
     * acts on. Read-only — no ledger operation, no mutation.
     */
    supervisionStatusForAgent(agent: Agent, request: {
        readonly workspaceId: WorkspaceId;
        readonly memberId: AgentTeamMemberId;
    }): AgentTeamSupervisionStatus;
    /**
     * A teammate's forced context reset of one abnormal fellow Member — the same
     * fresh-context renewal the Human menu's reset row performs. The caller must
     * be an enabled Member of the Workspace, the target must be enabled and read
     * abnormal to supervision (stopped, erroring, failing repeatedly, or hung),
     * and a Member cannot reset itself. A hung target is by definition still
     * running, so — unlike the Human remote — this path retires a live generation
     * without an idle refusal; disposal aborts the wedged turn.
     */
    resetMemberForAgent(agent: Agent, request: AgentTeamResetMemberRequest): Promise<AgentTeamResetMemberResult>;
    /**
     * Agent-only direct message: append the audit-only dm-sent operation, then
     * inject the body into the recipient's live session. The ledger commit is
     * the durable fact; the injection is a transient runtime effect, so a
     * missing handle or a failed wake returns a structured delivery error while
     * the recorded DM stays durable for the recipient's recovery path.
     */
    dmForAgent(agent: Agent, request: AgentTeamDmRequest): Promise<AgentTeamDmResult>;
    /** Relay body: the DM itself plus one bounded line of adjacent context. */
    private dmRelayText;
    threadHistoryForAgent(agent: Agent, request: AgentTeamThreadHistoryRequest): AgentTeamThreadHistory;
    /** Live participation addresses; paths remain owned by the Harness registry. */
    workspacesForAgent(agent: Agent): readonly {
        readonly workspaceId: WorkspaceId;
        readonly path: string | undefined;
        readonly default: boolean;
    }[];
    /** Agent-only bounded discovery projection; participation list carries registry titles when known. */
    viewForAgent(agent: Agent, request: AgentTeamViewRequest): AgentTeamView;
    /** Validate the durable ledger against an independently replayed projection. */
    validateLedger(): void;
    /**
     * Validate the durable ledger for the invariant's mount check. The
     * constructor already re-derived every durable record against its own
     * scratch projection, so this adopts that conclusion once while nothing has
     * committed since; every other call, and every commit-driven validation,
     * replays the whole table again.
     */
    validateLedgerAtMount(): void;
    /**
     * Budget + measurement for one Member's CURRENT routed selection — the
     * member-pinned model or the default selection, resolved through the LLM
     * service so a route change is honored at the next on-demand read. The budget
     * is priced from the route's OWN model information — context window plus the
     * adapter's default per-request output cap — through
     * {@link deriveContextPressureBudget}; a last persisted `request/context`
     * event still supplies the window when the resolution discloses none. This
     * pricing is passive: it feeds only the acceptance advice, the context
     * timeline, and the checkpoint-return guard, never a request decision —
     * a selection whose capacity cannot be resolved simply degrades those
     * surfaces to their unavailable or fallback presentations.
     */
    private routeLimitsForAgent;
    /**
     * Cache of resolved model information per provider/model; unknown stays
     * unknown, and a route resolved without a disclosed field stays without it.
     */
    private readonly routeInfos;
    /**
     * Resolve one selection's provider-owned model information — the context
     * window and the default per-request output cap that prices the pressure
     * budget — cached per route (one directory round-trip per route per
     * process). The LLM service is resolved lazily (not a hard inject): the
     * Host mounts it in every production shape, while ledger-level fixtures
     * provide only the services the Team service itself owns. A missing or
     * throwing resolution is an unknown route — the pressure policy fails
     * closed on it.
     */
    private resolvedRouteInfo;
    /**
     * Resolve one checkpoint ref to its exact seed prefix before any rollover
     * commit. The walk covers the current generation (own events) and archived
     * ancestors through `sessionPersistence`; the same projection definition
     * folds every source. Guards fail closed: unresolved, foreign-lineage,
     * open-turn, or nonshrinking targets reject without any lifecycle effect.
     */
    private resolveCheckpointSeed;
    /**
     * Rebuild the handoff for a Member whose rollover committed but whose new
     * Session activated without the handoff delivery (a crash between the
     * ledger commit and the swap's delivery step). The previous Session —
     * recorded in the operation, mirrored by the lineage parent, and available
     * from the ledger even when the new Session's own header never carried it —
     * holds the durable intent; fold it cold and deliver the same handoff
     * envelope first. Idempotent: once any handoff exists in the new Session's
     * own log this never runs.
     */
    private reconstructMissingHandoff;
    /**
     * Resolve the exact recorded seed prefix of one committed checkpoint
     * return for crash recovery: cold-read the recorded source Session, take
     * the contiguous prefix of the recorded exclusive length, and verify the
     * source's own fold still resolves the recorded anchor there — an explicit
     * checkpoint through `checkpointByRef`, or a default Team boundary whose
     * recorded ref appears among the source's own boundary keys.
     * Fail-closed by contract: an unreadable source or an unprovable anchor
     * REJECTS the activation — a committed checkpoint return may never
     * downgrade to a blank child.
     */
    private recordedCheckpointPrefix;
    /**
     * Redeliver the old generation's unconsumed post-intent input to a
     * generation whose durable rollover committed but whose delivery did not
     * finish. Bound to the ledger's recorded transition target — the CURRENT
     * Session being that target — never to whether the handoff itself landed,
     * so a crash after the handoff but before the carried enqueue still
     * replays. The fold is the same durable truth the live transition uses
     * (unconsumed, non-Team, order preserved). Idempotency keys on what is
     * CURRENTLY present: delivered `user/message` ids plus the live inbox's
     * pending next-step/next-turn ids — a historical insert that was already
     * claimed (and removed) but never surfaced is NOT known and must replay.
     * Fail-closed for genuinely unreadable previous Sessions (missing/IO) so
     * the Member's input is never dropped silently, with three bounded
     * exceptions: a generation that already started its own turns needs no
     * replay (its carried input was delivered or superseded while it ran), a
     * log-corruption class error skips with a warning (the Host repairs torn
     * tails; a retired generation's corrupt log must not permanently block the
     * Member's activation), and a deterministic released-format refusal skips
     * with a warning (the candidate's own migration audit refuses that
     * artifact, so no retry can ever read it).
     */
    private replayCarriedInput;
    /**
     * Agent-only checkpoint request validation: the tool calls this inside its
     * own running turn. Like `context_rollover`, the tool performs no side effect —
     * the durable checkpoint is the successful `tool/call`+`tool/result` pair
     * the Session projection folds; the ref returned here is deterministic
     * from this Member Session's identity plus the tool call id, so the model
     * can cite it before the result exists and a repeated provider call id in
     * another generation never collides with this one.
     */
    recordCheckpointForAgent(agent: Agent, request: AgentTeamCheckpointToolRequest): AgentTeamCheckpointToolOutcome;
    /**
     * Agent-only bounded structural timeline: resolved checkpoints plus Team
     * delivery, handoff, and compaction boundaries across the current
     * generation and its archived ancestor lineage. Structural only — no
     * transcript content. The walk, the per-source folds, the pricing, and the
     * anchor rules are the engine's `readContextTimeline`; Team contributes the
     * fold configuration, the measurement, and the one judgement the engine
     * leaves to its host — which Threads a boundary's retained prefix holds — so
     * a ref this list offers is a ref `context_rollover` accepts.
     */
    contextTimelineForAgent(agent: Agent, request: AgentTeamTimelineToolRequest): Promise<AgentTeamTimelineToolResult>;
    /**
     * Map one engine timeline item onto the model-facing Team item. The engine
     * decided the walk, the fold, the pricing, and the head, checkpoint, and
     * measurable-source verdicts; Team restates exactly one policy of its own: a
     * Team boundary is selectable only when the RETAINED PREFIX through it stays
     * inside one Thread — the same proof the seed guard revalidates before it
     * swaps a generation. The engine judges a boundary by its OWN attribution
     * instead, so a boundary that arrived after a second Thread's facts would be
     * offered here and refused by `context_rollover`; Team's stricter rule is
     * what keeps the two surfaces answering one question.
     */
    private teamTimelineItemFor;
    /**
     * Replayed measurement of one lineage source: the live current Session
     * measures directly; an archived ancestor measures through a detached
     * Session rebuilt from the source's own log, so a seed's retained cost is
     * priced in the SOURCE's own tokens — never the current generation's.
     * Returns undefined when no meter is available or the source cannot be
     * replayed; callers fail closed on the unknown.
     */
    private sourceUsageTokens;
    /**
     * One already-read source's replayed measurement: an archived generation is
     * rebuilt as a detached Session and measured in its own tokens. Undefined
     * means unmeasurable, never free.
     */
    private measureDetachedSource;
    /**
     * One source's replayed measurement, in that source's own tokens, for a
     * caller that already holds the source: the live generation measures
     * directly, an archived one is rebuilt from the log it came with. Undefined
     * means unmeasurable — a caller must never price an unknown source as free.
     */
    measureContextSourceForAgent(agent: Agent, source: ContextTimelineSource): number | undefined;
    /**
     * The one fold configuration the registered projection unit and every cold
     * fold use, so a generation read back for the timeline reads exactly as the
     * projection folded it — same codec, same boundary attribution.
     */
    contextFoldConfig(): ContextProjectionConfig;
    /**
     * Monotonic anchor-share estimate of a seed's retained cost, priced in the
     * SOURCE Session's own measurement: the fraction of the source log the
     * seed prefix covers, scaled to the source's replayed token count. The
     * anchor position is exact and the share grows monotonically toward the
     * source's head (100%). A large ancestor's anchor therefore prices at the
     * ancestor's real size even inside a small current generation — the
     * timeline display and the return guard share this one estimate.
     */
    private retainedEstimate;
    /**
     * Agent-only rollover request validation: the tool calls this to check its
     * Member binding, exclusivity, and checkpoint ownership. It performs no
     * lifecycle effect — the actual transition reacts to the successful tool
     * result through the context-management coordinator.
     */
    requestNewContext(agent: Agent, request: AgentTeamNewContextToolRequest): Promise<AgentTeamNewContextToolOutcome>;
    /**
     * Jobs this Agent owns that cannot survive a generation swap: any
     * running/stopping job, and any settled job whose terminal output was
     * never reported (disposal would silently discard it). In-place hard
     * compaction is exempt — it never cancels the owner.
     */
    private ownedJobsBlockingRollover;
    /**
     * Agent-only session rollover commit: the Member actor must be the target
     * Member on its currently bound live Session. The Host performs the actual
     * generation swap around this write; the ledger records only the durable
     * binding transition and rollover audit envelope.
     */
    rolloverSessionForAgent(agent: Agent, request: AgentTeamRolloverSessionRequest): Promise<AgentTeamDurableMemberResult>;
    /**
     * Agent-only interrupt recording: pin the Member's unfinished session onto
     * a checkpoint it actually recorded. The cited ref must appear in the
     * Member's own lineage timeline — the same engine anti-forgery surface
     * `context_rollover` gate-checks against — and an unresolved checkpoint is
     * not yet an anchor, so the record belongs to the turn after the one that
     * recorded it (the engine's quiet continuation lands it there). Recording
     * performs no lifecycle effect: the swap stays exclusively the rollover
     * tool's; the entry is durable bookkeeping the resume protocol walks.
     */
    recordInterruptForAgent(agent: Agent, request: AgentTeamRecordInterruptToolRequest): Promise<AgentTeamRecordInterruptToolOutcome>;
    /** Agent-only pending-stack read: every interrupt this Member pinned and has not resumed or released, newest first. */
    listInterruptsForAgent(agent: Agent): Promise<AgentTeamListInterruptsToolOutcome>;
    /** Agent-only release: close one pending interrupt without returning to it. */
    releaseInterruptForAgent(agent: Agent, request: AgentTeamReleaseInterruptToolRequest): Promise<AgentTeamReleaseInterruptToolOutcome>;
    /** Whether one opaque ref is a resolved anchor of this Member's current lineage window. */
    private lineageKnowsAnchor;
    /**
     * Annotate pending entries with the live lineage verdict: citing the anchor
     * today returns or not, and the reason the timeline states. Without a live
     * Agent the walk cannot run at all — an unproven anchor never reads as
     * returnable, so the Human surface degrades to an explicit unverified false
     * instead of an optimistic yes.
     */
    private interruptViews;
    /** Human read: one Member's pending interrupts, newest first, annotated when the Member is live. */
    memberInterrupts(request: AgentTeamMemberInterruptsRequest): Promise<AgentTeamMemberInterrupts>;
    /** Human release of one Member's pending interrupt; `resumed` stays exclusively the Host's own close. */
    resolveMemberInterrupt(request: AgentTeamResolveMemberInterruptRequest): Promise<AgentTeamResolveMemberInterruptResult>;
    private emitCommittedOutcome;
    private assertChannelMembersAvailable;
    /** Shared Task-creation commit: resolve uploads into metadata lines and append through the ledger. */
    private sendMessageAs;
    /** Shared existing-Thread reply commit: same upload resolution and outcome emission. */
    private replyAs;
    /**
     * Record one dispatch whose sender judged the work needs the named Members'
     * live Session: their fresh-start arm stays armed but the direct work this
     * Message creates (at this ledger sequence) no longer spends it. A later
     * dispatch carries a higher sequence and renews as usual, so the exemption is
     * exactly this delivery, never the next task.
     */
    private keepFreshStartDispatch;
    /** Fence one Human Remote call: accepting Host, known Workspace, Human actor. */
    private humanCall;
    /** Fence one Member call: accepting Host, live Member binding, matching Workspace participation. */
    private memberCall;
    private memberActor;
    private requireAgentWorkspace;
    /**
     * Validate a pinned model route's reasoning effort against the adapter's own
     * metadata when the LLM service is reachable; unknown routes defer to the
     * LLM layer's runtime check at call time.
     */
    private assertModelRoute;
    /**
     * Session headers currently durable in the persistence backend.
     *
     * The Host retires a disposed Session's log without awaiting it, so a
     * concurrent activation can observe the JSONL backend's transient win32
     * staging directories (.dsh-mkdir-*) as ENOENT while they rename into
     * place. The read is idempotent; back off briefly instead of failing the
     * activation on a race the publisher resolves within milliseconds.
     */
    private persistedSessionHeaders;
    private activateMember;
    /**
     * Rebuild one enabled Member in place from its persisted Session.
     *
     * A bundle-row reload tears down the preset roster subtree, which prunes the
     * standing mount while live agents keep their dead scope bindings: the
     * Member keeps its session but loses its composed tools and services.
     * Re-running the preset composition requires a fresh Agent, and disposal is
     * the cost — the Web Client marks the recreated Session unavailable until it
     * is reopened, the same trade the shipped suspend/resume cycle makes.
     */
    private reactivateMember;
    /**
     * Default an untitled Member Session to its handle so the ordinary Session
     * list names it. An explicit rename or any earlier title always wins; the
     * cosmetic default never fails Member activation.
     */
    private nameMemberSession;
    private validateMemberPreset;
    private memberStatus;
    private setMemberFailure;
    /** Store one structured activation diagnostic; runtime/compaction slots stay plain messages. */
    private setActivationDiagnostic;
    /**
     * Route one activation failure to its diagnostic class: preset composition
     * failures by their own error class, session failures by the seam's typed
     * classification (our call sites carry it directly; a Harness resume
     * failure carries it through the cause chain), everything else as an
     * unclassified activation failure.
     */
    private activationDiagnosticOf;
    private clearMemberFailure;
    private requireWorkspace;
    private requireLedger;
    private requireAccepting;
    /**
     * The storage directory the composition layer ships beside the SQLite ledger
     * route (`ledgerDirectory`); undefined means this Host was never given a
     * shared file medium to fence (a memory-backend test harness owns its ledger
     * in-process), and it runs unfenced and touches nothing in the DSH home.
     */
    private ledgerFenceDirectory;
    private emitCommitted;
    private emitAutoCompactionChanged;
    /**
     * Presence-only invalidation: Agent running/idle/activation/failure changes
     * alter no durable projection, so only members/presence subscribers wake —
     * the workspace catalog and the scope-less Inbox subscriptions stay parked.
     */
    private emitPresenceChanged;
    /** Presence invalidation in every Workspace the Member participates in — each panel listing it must refresh. */
    private emitMemberPresenceChanged;
    /** Wake from durable unread state with bounded facts for direct and state-changing work. */
    private notifyMember;
    private isInboxNotice;
    private isRecoveryNotice;
    /**
     * Group key when one unread direct Message is a Host-posted recurring notice
     * whose deliveries supersede each other — a continuation nudge (one group per
     * Workspace) or a context-reset announcement (one group per announcing
     * Member and Workspace). Each newer delivery restates the full current state,
     * so an older unread instance carries no information and must not be
     * re-rendered into a Member's bounded notification context. Any other Message
     * has no key and always renders.
     */
    private recurringNoticeKey;
    private notificationText;
    private boundedNotificationBody;
    private activityNotification;
    /** Dispose one live Member Session and drop its per-Member runtime state. */
    private disposeMemberSession;
    private clearMemberRecoveryState;
    private clearMemberNotificationState;
    /**
     * Wake waiters for one committed or lifecycle change. Undefined broadcasts
     * to everyone; an empty scope list invalidates nobody because no shared
     * projection changed; otherwise global and matching scoped waiters wake.
     * Presence-only scopes sit outside that: they change no durable projection,
     * so only matching presence waiters wake and the scope-less Inbox
     * subscriptions stay parked.
     *
     * Each woken waiter receives the version of its own scope's domain, so a
     * wake can never hand a projection waiter a presence number or the other way
     * around. Nothing here advances the projection version.
     */
    private emitChanged;
    /**
     * The cursor domain of one scope: presence scopes count process-local edge
     * wakes, every other scope compares against the durable ledger position of
     * the newest shared-projection commit. The two domains are deliberately
     * separate, so a presence edge cannot invalidate a projection subscriber and
     * a private read invalidates no one.
     */
    private changeVersionOf;
    private validateChangeScope;
    private enqueueLifecycle;
}
//# sourceMappingURL=index.d.ts.map