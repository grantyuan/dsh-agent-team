import type { SessionId } from '@deepseek-ai/dsh-session';
import type { WorkspaceId } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { AgentTeamChannelRef, AgentTeamMemberId, AgentTeamTaskRef, AgentTeamThreadRef } from '@wowyuarm/dsh-agent-team/types';
import type { TeamTabFace } from './dock.ts';
export type TeamMode = 'conversation' | 'team';
/**
 * The Team list an open Thread was entered from. It decides where Back lands:
 * an Inbox, Tasks, or Message Center origin returns to that list, an absent
 * origin returns to the Thread's Channel through the Channel row path.
 */
export type TeamThreadOrigin = 'inbox' | 'tasks' | 'messages';
export interface TeamNavigationSnapshot {
    mode: TeamMode;
    workspaceId?: WorkspaceId;
    channelRef?: AgentTeamChannelRef;
    taskRef?: AgentTeamTaskRef;
    threadRef?: AgentTeamThreadRef;
    taskNumber?: number;
    /**
     * Which Team list the open Thread was entered from. It is a durable
     * navigation fact: a Thread opened from the Inbox or Tasks list returns to
     * that list after a reload; a Thread entered from its Channel carries no
     * origin and returns there.
     */
    threadOrigin?: TeamThreadOrigin;
    /**
     * One-shot locate anchor riding `threadRef`: the Message Center's 「定位」
     * opens the Thread and asks the timeline to scroll this fact into view and
     * flash it once. It is a durable navigation fact, so a reload replays it,
     * and every path that drops `threadRef` drops it with it.
     */
    focusSequence?: number;
    /**
     * Durable position of the Human mention-Inbox page (a navigation fact, not
     * an unread fact): selecting Inbox clears the Channel/Thread faces, and a
     * reload reopens the page. Read markers only move through Thread reads.
     */
    inbox?: boolean;
    /** Durable position of the Human Tasks page; same face discipline as `inbox`. */
    tasks?: boolean;
    /**
     * Durable position of the Human Message Center page — every discussion in
     * the Workspace beside every Message sent to or by this person. Same face
     * discipline as `inbox`.
     */
    messages?: boolean;
    /**
     * Durable position of one Member's session-history review page: the Human's
     * audit target survives a reload because the lineage read takes only the
     * branded Member id. Same face discipline as `inbox` and `tasks`.
     */
    sessionHistory?: AgentTeamMemberId;
    /** Runtime-only Member Session embedded in the conversation seat; never persisted. */
    memberSessionId?: SessionId;
    /** Runtime-only session to restore when the Member view closes; never persisted. */
    returnToSessionId?: SessionId;
}
declare const STORAGE_KEY = "dsh.agent-team.navigation";
export interface TeamNavigationActions {
    enterTeam: () => void;
    leaveTeam: () => void;
    selectWorkspace: (workspaceId: WorkspaceId) => void;
    selectChannel: (channelRef: AgentTeamChannelRef) => void;
    selectThread: (threadRef: AgentTeamThreadRef, channelRef?: AgentTeamChannelRef, taskRef?: AgentTeamTaskRef, taskNumber?: number, origin?: TeamThreadOrigin, focusSequence?: number) => void;
    /** Open the Human mention-Inbox page; clears the Channel/Thread faces. */
    selectInbox: () => void;
    /** Open the Human Tasks page; clears the Channel/Thread faces. */
    selectTasks: () => void;
    /** Open the Human Message Center page; clears the Channel/Thread faces. */
    selectMessages: () => void;
    /** Open one Member's session-history review page; clears the other Team faces. */
    selectSessionHistory: (memberId: AgentTeamMemberId) => void;
    /** Leave the session-history page; the Workspace face underneath takes the seat back. */
    exitSessionHistory: () => void;
    /**
     * Leave the open Thread for whichever Team list it was entered from: the
     * Inbox, Tasks, or Message Center list when the Thread carries that origin,
     * its Channel otherwise.
     */
    backFromThread: () => void;
    /** Leave the selected Channel for the workspace Channel list; keeps mode and Workspace. */
    backToChannels: () => void;
    /**
     * Swap the conversation seat to a Member Session while Team chrome stays
     * mounted. `returnToSessionId` is captured once — switching between Member
     * Sessions keeps the original target.
     */
    enterMemberSession: (sessionId: SessionId, returnToSessionId?: SessionId) => void;
    /** Close the embedded Member Session view and return to the Team views. */
    exitMemberSession: () => void;
    /**
     * Restore one dock tab's navigation face in a single commit: the Workspace
     * the tab was opened under (when it carries one and it differs) plus the
     * leaf face itself. A background tab taking its seat back must not publish
     * the intermediate Workspace-overview state, so the Workspace move and the
     * leaf selection land as one durable navigation write.
     */
    restoreTabFace: (face: TeamTabFace) => void;
}
/** Root-scoped Team mode state. Slot lifetimes subscribe to this source. */
export declare class TeamNavigation {
    private snapshot;
    private readonly listeners;
    readonly getSnapshot: () => TeamNavigationSnapshot;
    readonly subscribe: (listener: () => void) => (() => void);
    actions(): TeamNavigationActions;
    dispose(): void;
    private setMode;
    private setMemberSession;
    /** Any explicit Team navigation or the footer leave closes a Member view. */
    private clearMemberSession;
    private setWorkspace;
    private setChannel;
    /** The Inbox is a face, not workspace content: selecting a Workspace leaves it. */
    private setInbox;
    /** Same face discipline as the Inbox: the Tasks page owns the seat while its flag stands. */
    private setTasks;
    /** Same face discipline as the Inbox: the Message Center owns the seat while its flag stands. */
    private setMessages;
    /** Same face discipline as the Inbox: one Member's history page owns the seat while its flag stands. */
    private setSessionHistory;
    private clearSessionHistory;
    private clearChannel;
    private setThread;
    /** Back from the open Thread to the list it was entered from, else its Channel. */
    private leaveThread;
    /**
     * One dock tab's face restored as one durable write: the tab's Workspace
     * (when it carries one and it differs — which also drops every leaf face,
     * since faces never cross Workspaces) and then the leaf face itself. The
     * global list faces keep the current Workspace, like their own actions do.
     */
    private applyTabFace;
    private commit;
}
export { STORAGE_KEY };
//# sourceMappingURL=navigation.d.ts.map