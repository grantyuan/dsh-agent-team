import type { TeamPagePayload } from './slots.ts';
interface TeamTasksPageProps {
    readonly useWorkspaces: TeamPagePayload['useWorkspaces'];
    readonly loadTasks: TeamPagePayload['loadTasks'];
    /** Wake source while the page is open: one scope-less subscription, like the Inbox page. */
    readonly subscribeChanges: TeamPagePayload['subscribeChanges'];
    /** Host batch resolution behind the multi-select bar: acceptance or closing for several Tasks at once. */
    readonly changeTasks: TeamPagePayload['changeTasks'];
    readonly selectWorkspace: TeamPagePayload['selectWorkspace'];
    readonly selectThread: TeamPagePayload['selectThread'];
    /** The Human's display name, from the Client's one identity projection. */
    readonly humanName: string;
    readonly humanAvatarUrl?: string | undefined;
    readonly t: TeamPagePayload['t'];
}
/**
 * The Human Task list: one `tasks` call per visible Workspace, rendering every
 * Task with its live standing and the sub-task trees Agents split underneath.
 * The ledger stays flat, so the tree assembles here — a Task with a
 * `parentTaskRef` nests under its parent at any depth (which the Host
 * guaranteed lives in the same Channel), and a parent carries a
 * `{done}/{total}` progress count over its whole subtree. Rows group into the
 * same two sections the Inbox speaks — open work first, finished work after —
 * so a reader scans what still moves before what stopped; when the rows span
 * more than one Workspace, each section splits into per-Workspace groups in
 * the Workspace list's own order. A sub-task whose parent is not in the merged
 * list (archived away, or a one-sided projection gap) falls back to a root
 * row, so no Task is ever invisible. Open rows carry a selection checkbox: the
 * multi-select bar resolves them through one Host batch call, each Task its
 * own durable operation. Opening a row navigates to its Thread; selecting
 * acknowledges nothing and viewing acknowledges nothing.
 */
export declare function TeamTasksPage({ useWorkspaces, loadTasks, subscribeChanges, changeTasks, selectWorkspace, selectThread, humanName, humanAvatarUrl, t }: TeamTasksPageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamTasksPage.d.ts.map