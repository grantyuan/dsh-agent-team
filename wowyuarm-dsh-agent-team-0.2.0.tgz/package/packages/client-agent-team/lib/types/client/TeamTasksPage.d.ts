import type { TeamConversationProps } from './slots.ts';
interface TeamTasksPageProps {
    readonly useWorkspaces: TeamConversationProps['useWorkspaces'];
    readonly loadTasks: TeamConversationProps['loadTasks'];
    /** Wake source while the page is open: one scope-less subscription, like the Inbox page. */
    readonly subscribeChanges: TeamConversationProps['subscribeChanges'];
    /** Host batch resolution behind the multi-select bar: acceptance or closing for several Tasks at once. */
    readonly changeTasks: TeamConversationProps['changeTasks'];
    readonly selectWorkspace: TeamConversationProps['selectWorkspace'];
    readonly selectThread: TeamConversationProps['selectThread'];
    /** The Human's display name, from the Client's one identity projection. */
    readonly humanName: string;
    readonly humanAvatarUrl?: string | undefined;
    readonly t: TeamConversationProps['t'];
}
/**
 * The Human Task list: one `tasks` call per visible Workspace, rendering every
 * Task with its live standing and the sub-task trees Agents split underneath.
 * The ledger stays flat, so the tree assembles here — a Task with a
 * `parentTaskRef` renders indented under its parent (which the Host guaranteed
 * lives in the same Channel), with a `{done}/{total}` progress count beside the
 * parent. Rows merge across every Workspace in the Host's own Channel-ordinal
 * order, split into the same two sections the Inbox speaks — open work first,
 * finished work after — so a reader scans what still moves before what stopped.
 * A sub-task whose parent is not in the merged list (archived away, or a
 * one-sided projection gap) falls back to a top-level row, so no Task is ever
 * invisible. Open rows carry a selection checkbox: the multi-select bar
 * resolves them through one Host batch call, each Task its own durable
 * operation. Opening a row navigates to its Thread; selecting acknowledges
 * nothing and viewing acknowledges nothing.
 */
export declare function TeamTasksPage({ useWorkspaces, loadTasks, subscribeChanges, changeTasks, selectWorkspace, selectThread, humanName, humanAvatarUrl, t }: TeamTasksPageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamTasksPage.d.ts.map