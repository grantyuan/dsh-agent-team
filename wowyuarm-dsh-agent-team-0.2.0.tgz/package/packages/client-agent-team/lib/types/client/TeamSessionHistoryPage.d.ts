import type { AgentTeamMemberId } from '@wowyuarm/dsh-agent-team/types';
import type { TeamPagePayload } from './slots.ts';
interface TeamSessionHistoryPageProps {
    readonly memberId: AgentTeamMemberId;
    /** The selected Workspace, when the seat has one; the external-context read scopes to it. */
    readonly workspaceId?: string;
    readonly loadMembers: TeamPagePayload['loadMembers'];
    readonly loadMemberSessions: TeamPagePayload['loadMemberSessions'];
    readonly loadMemberSessionTranscript: TeamPagePayload['loadMemberSessionTranscript'];
    readonly loadExternalContext: TeamPagePayload['loadExternalContext'];
    readonly exitSessionHistory: TeamPagePayload['exitSessionHistory'];
    readonly t: TeamPagePayload['t'];
}
/**
 * The Human audit page for one Member's stored Sessions: every generation the
 * Member has run (the live one first, archived ancestors through the Host's
 * lineage walk), and a bounded read-only transcript of the selected generation.
 * The transcript is the Host's own stored-log render in multiline mode, so the
 * page can show each entry as authored Markdown — system instructions, Team
 * relays, and Host notices included — instead of the flattened single lines the
 * doctor's model-facing transcript needs. Opening this page never activates,
 * resumes, or writes a Member Session, which is why archived generations stay
 * browsable even though Harness refuses to open them as live conversations.
 */
export declare function TeamSessionHistoryPage({ memberId, workspaceId, loadMembers, loadMemberSessions, loadMemberSessionTranscript, loadExternalContext, exitSessionHistory, t }: TeamSessionHistoryPageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamSessionHistoryPage.d.ts.map