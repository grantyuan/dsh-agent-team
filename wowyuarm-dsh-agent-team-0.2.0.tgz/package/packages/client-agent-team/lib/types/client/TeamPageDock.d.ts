import type { TeamDockProps } from './slots.ts';
/**
 * The Team page dock: the right column seat that renders the Team pages —
 * Inbox, Tasks, Message Center, Channels, Threads, session history — as tabs
 * in one or more split panes, beside the conversation the frame keeps in its
 * center. The dock owns browser-kept layout only; what a tab shows is the
 * navigation snapshot's face, and every sidebar entry point lands here through
 * the same face (so a click on a sidebar card always answers, whatever the
 * center currently renders).
 */
export declare function TeamPageDock(props: TeamDockProps): import("react").JSX.Element | null;
//# sourceMappingURL=TeamPageDock.d.ts.map