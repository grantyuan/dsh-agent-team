import type { AgentTeamTaskRef, AgentTeamThreadRef } from '@wowyuarm/dsh-agent-team/types';
import type { WorkspaceId } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { TeamConversationProps } from './slots.ts';
interface TeamThreadDigestProps {
    readonly workspaceId: WorkspaceId;
    readonly threadRef: AgentTeamThreadRef;
    readonly taskRef?: AgentTeamTaskRef;
    /** The Thread revision currently on screen: the digest is read at it, and the decision reply commits against it. */
    readonly revision: number;
    readonly summarizeThread: TeamConversationProps['summarizeThread'];
    readonly reply: TeamConversationProps['reply'];
    readonly disabled: boolean;
    readonly t: TeamConversationProps['t'];
}
/**
 * The plain-language recap above the timeline: what the Thread asked, what
 * has happened, and — when it waits on the Human — the choices on offer.
 * Reading a Thread never spends a model call on it: the seat opens with a
 * stored recap for the current state if there is one, and otherwise waits for
 * the reader to ask. Once it is there, the reader answers a decision without
 * reading the whole timeline: pick the Thread's own options (one when the
 * digest read them as mutually exclusive, several when it read them as
 * combinable), or write an opinion; either way the answer goes out through the
 * normal durable reply path, so it lands in the ledger as an ordinary Message
 * like every other Human word.
 */
export declare function TeamThreadDigest({ workspaceId, threadRef, taskRef, revision, summarizeThread, reply, disabled, t }: TeamThreadDigestProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamThreadDigest.d.ts.map