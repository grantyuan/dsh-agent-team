import type { AgentTeamClientMemberStatus, AgentTeamMemberId, AgentTeamMemberPromptProfile, AgentTeamModelSelection } from '@wowyuarm/dsh-agent-team/types';
import type { TeamSidebarProps } from './slots.ts';
/**
 * Best-effort warm of the shared catalog (the agents panel calls this while
 * the roster loads, so the pickers open with rows instead of paying the
 * first read on open). Failures belong to the picker's own error surface.
 */
export declare function warmModelCatalog(loadModels: TeamSidebarProps['loadModels']): void;
/**
 * Shared provider/model dropdown for the create and edit forms. The option
 * list rides the shared Menu primitive (one leading "follow Host default"
 * row, then non-selectable provider headings) with a capped, internally
 * scrolling card so growing model catalogs cannot stretch the dialog. Mounts
 * open with the warmed value when one exists and revalidate behind it, so a
 * slow Host read delays a refresh — never the picker itself; a refused or
 * failed read with no warmed value renders a retryable error instead of
 * stranding the field on "loading".
 */
export declare function ModelPickerField({ model, onModelChange, loadModels, disabled, t, defaultLabel, fieldLabel }: {
    readonly model: AgentTeamModelSelection | undefined;
    readonly onModelChange: (choice: AgentTeamModelSelection | undefined) => void;
    readonly loadModels: TeamSidebarProps['loadModels'];
    /** Row label override; the shared picker names itself for the primary route. */
    readonly fieldLabel?: string;
    readonly disabled: boolean;
    readonly t: TeamSidebarProps['t'];
    /** Overrides the follow-default option's label when the picker's fallback reads differently. */
    readonly defaultLabel?: string;
}): import("react").JSX.Element;
/** Backup routes one Member may pin, in failover order. */
export declare const MODEL_FALLBACK_MAX = 4;
/**
 * The ordered backup-route editor shared by the create and edit forms: one
 * row per pinned candidate (movable up, removable) plus one trailing picker
 * that appends the next candidate. The list rides the same absent-clears
 * discipline as `model`: an empty list clears the failover pin, and the
 * ledger refuses a candidate that repeats the primary.
 */
export declare function ModelFallbackPickerField({ fallbacks, onChange, primary, loadModels, disabled, t }: {
    readonly fallbacks: readonly AgentTeamModelSelection[];
    readonly onChange: (next: readonly AgentTeamModelSelection[]) => void;
    readonly primary: AgentTeamModelSelection | undefined;
    readonly loadModels: TeamSidebarProps['loadModels'];
    readonly disabled: boolean;
    readonly t: TeamSidebarProps['t'];
}): import("react").JSX.Element;
/**
 * Parses the context-window override text shared by the create and edit
 * forms: empty means "follow the route window" (an absent field), a whole
 * number at the 8192 floor is a valid override, and anything else parses to
 * NaN — the caller's invalid sentinel that blocks submission. NaN stays
 * typed as a number so the payload spread needs no extra narrowing.
 */
export declare function parseContextWindow(text: string): number | undefined;
/**
 * The UTF-8 byte bound of one custom role paragraph. Mirrors the Host's
 * ledger commit rule, so this live counter agrees with the Host for CJK
 * prose too: the bytes the user sees are the bytes the commit measures.
 */
export declare const MEMBER_PROMPT_MAX_BYTES = 8192;
/** UTF-8 byte length of one paragraph — the measure the Host commit rule and this counter share. */
export declare function utf8ByteLength(text: string): number;
/**
 * One Prompt dialog behind both entry points: the create form stages a local
 * paragraph (`stage` mode — nothing durable until the member-added commit),
 * the editor commits a durable echo-complete member update (`edit` mode).
 */
export declare function MemberPromptDialog(props: {
    readonly t: TeamSidebarProps['t'];
    readonly onClose: () => void;
} & ({
    readonly mode: 'stage';
    readonly initialText: string;
    readonly onApply: (text: string) => void;
} | {
    readonly mode: 'edit';
    readonly memberId: AgentTeamMemberId;
    readonly loadPromptView: TeamSidebarProps['loadPromptView'];
    readonly curateMemberPrompt: TeamSidebarProps['curateMemberPrompt'];
    readonly updateMember: TeamSidebarProps['updateMember'];
    readonly onCommitted: (prompt: AgentTeamMemberPromptProfile | undefined) => Promise<void> | void;
})): import("react").JSX.Element;
/**
 * Shared task-start context block for the create and edit forms: one Menu
 * row choosing between the continue and fresh start policies plus a numeric
 * context-window override that can only narrow the route window. An empty
 * window input means "follow the route window" and maps to an absent field;
 * an unparsable one renders the invalid alert and keeps the form unsubmitted.
 */
export declare function ContextPickerField({ policy, onPolicyChange, windowText, onWindowTextChange, invalid, disabled, t }: {
    readonly policy: 'continue' | 'fresh';
    readonly onPolicyChange: (policy: 'continue' | 'fresh') => void;
    readonly windowText: string;
    readonly onWindowTextChange: (text: string) => void;
    /** Renders the invalid-window alert in place of the hint line. */
    readonly invalid: boolean;
    readonly disabled: boolean;
    readonly t: TeamSidebarProps['t'];
}): import("react").JSX.Element;
/**
 * Agent editor: handle, description, per-Member model selection, and the
 * task-start context control commit through one durable update. Channel
 * membership is managed from the Channel side, not here.
 */
export declare function AgentEditorDialog({ status, updateMember, loadPromptView, curateMemberPrompt, loadModels, onCommitted, onClose, t }: {
    readonly status: AgentTeamClientMemberStatus;
    readonly updateMember: TeamSidebarProps['updateMember'];
    readonly loadPromptView: TeamSidebarProps['loadPromptView'];
    readonly curateMemberPrompt: TeamSidebarProps['curateMemberPrompt'];
    readonly loadModels: TeamSidebarProps['loadModels'];
    readonly onCommitted: () => Promise<void> | void;
    readonly onClose: () => void;
    readonly t: TeamSidebarProps['t'];
}): import("react").JSX.Element;
export declare function sameModel(left: AgentTeamModelSelection | undefined, right: AgentTeamModelSelection | undefined): boolean;
//# sourceMappingURL=TeamMemberEditor.d.ts.map