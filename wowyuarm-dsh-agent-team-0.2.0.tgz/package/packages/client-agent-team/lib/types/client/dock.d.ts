import type { WorkspaceId } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { AgentTeamChannelRef, AgentTeamMemberId, AgentTeamTaskRef, AgentTeamThreadRef } from '@wowyuarm/dsh-agent-team/types';
import type { TeamNavigationSnapshot, TeamThreadOrigin } from './navigation.ts';
/**
 * The Team page dock: the right-column pane surface that renders the Team
 * pages beside the conversation. The dock owns browser-kept presentation
 * layout only — which pages are open as tabs, how panes split, and which one
 * is maximized. What the pages show is still the navigation snapshot's faces;
 * the dock subscribes to that snapshot and never invents durable facts.
 */
export type TeamDockTabKind = 'overview' | 'inbox' | 'tasks' | 'messages' | 'channel' | 'thread' | 'sessionHistory';
/**
 * The navigation face one dock tab stands for. The same shape both directions:
 * read off the snapshot when a Team face moves (so the dock follows the
 * sidebar), and written back through `restoreTabFace` when a background tab
 * takes its pane's seat again (so the sidebar follows the dock).
 */
export interface TeamTabFace {
    readonly kind: TeamDockTabKind;
    readonly workspaceId?: WorkspaceId;
    readonly channelRef?: AgentTeamChannelRef;
    readonly threadRef?: AgentTeamThreadRef;
    readonly taskRef?: AgentTeamTaskRef;
    readonly taskNumber?: number;
    readonly threadOrigin?: TeamThreadOrigin;
    readonly memberId?: AgentTeamMemberId;
}
export interface TeamDockTab extends TeamTabFace {
    /** Stable within the dock; `#N` suffixes distinguish cloned splits. */
    readonly id: string;
}
export interface TeamDockPane {
    readonly id: string;
    readonly tabs: readonly TeamDockTab[];
    readonly activeTabId: string;
    /** Relative flex weight against the sibling panes; the divider drag writes it. */
    readonly size: number;
}
export interface TeamDockSnapshot {
    /** Whether the dock column stands beside the conversation at all. */
    readonly open: boolean;
    /** Whether the dock covers the frame; derived fullscreen on narrow viewports rides the component. */
    readonly fullscreen: boolean;
    readonly panes: readonly TeamDockPane[];
    /** The pane new faces open into; falls back to the last pane when unset. */
    readonly focusedPaneId?: string;
    /** The pane drawn over its siblings; `undefined` restores the split. */
    readonly maximizedPaneId?: string;
}
/** The read face of the dock store, as slot props carry it. */
export interface TeamDockStoreSource {
    readonly getSnapshot: () => TeamDockSnapshot;
    readonly subscribe: (listener: () => void) => () => void;
}
declare const STORAGE_KEY = "dsh.agent-team.dock.v1";
/** Read one navigation snapshot into the face its sidebar state names. */
export declare function faceOfSnapshot(snapshot: TeamNavigationSnapshot): TeamTabFace | undefined;
/**
 * Root-scoped dock layout, one instance per Client context (provided next to
 * the navigation service). Every mutation commits once — persist, then notify
 * — and identical writes stay silent so sync effects converge without loops.
 */
export declare class TeamDockStore {
    private snapshot;
    private readonly listeners;
    private paneCounter;
    readonly getSnapshot: () => TeamDockSnapshot;
    readonly subscribe: (listener: () => void) => (() => void);
    dispose(): void;
    /** Test seam: forget everything, including what localStorage still holds. */
    reset(): void;
    /** Re-read persisted content — what a fresh page load starts from. */
    reload(): void;
    /**
     * Follow the navigation snapshot's face: focus the tab that already stands
     * for it — in whichever pane — or open it into the focused pane, reopening
     * the dock when it was closed. Sidebar cards, Thread rows, and the pages'
     * own Back buttons all arrive here, so the dock answers every one of them.
     */
    openFace(face: TeamTabFace): void;
    /** Focus one tab inside its pane; the component restores the face through navigation. */
    focusTab(paneId: string, tabId: string): void;
    closeTab(paneId: string, tabId: string): void;
    closePane(paneId: string): void;
    /**
     * Split the focused pane: its active page opens again in a new pane placed
     * right below, and the two share the row heights evenly. The source pane
     * keeps its tab — the split is a copy, never a move, so a single-tab pane
     * splits instead of collapsing.
     */
    splitPane(): void;
    toggleMaximize(paneId: string): void;
    setPaneSize(paneId: string, size: number): void;
    setOpen(open: boolean): void;
    toggleOpen(): void;
    setFullscreen(fullscreen: boolean): void;
    private targetPane;
    private newPane;
    private newTab;
    /**
     * One mutation, one commit: `patch` merges over the snapshot, and the named
     * optional pointers drop from it entirely (an `undefined` value under
     * exactOptionalPropertyTypes is not writable, and clearing must stay a
     * distinct act from leaving a field untouched).
     */
    private commit;
}
export { STORAGE_KEY as TEAM_DOCK_STORAGE_KEY };
//# sourceMappingURL=dock.d.ts.map