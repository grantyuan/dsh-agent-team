import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { AgentTeamGatewayConfig } from '@wowyuarm/dsh-agent-team/types';
import { type TeamHumanIdentityFace } from './human-identity.ts';
import type { TeamEnvironmentSource } from './environment-check.ts';
export interface HumanSettingsSectionInjected {
    /** The shared Human identity projection: profile facts plus post-write refresh. */
    identity: TeamHumanIdentityFace;
    /** Persist one renamed display name; the failure message when the Host refuses it. */
    saveName: (name: string) => Promise<string | undefined>;
    /** Upload one image file, persist its reference; the failure message when it does not stick. */
    uploadAvatar: (file: File) => Promise<string | undefined>;
    /** Clear the avatar; the identity falls back to the initial. */
    removeAvatar: () => Promise<string | undefined>;
    /** The local environment check, a read-only projection of the installation. */
    environment: TeamEnvironmentSource;
    /**
     * The external-agent gateway controls. Reads and saves answer the Host's
     * fresh view (save resolves post-reconcile, so `listening` is what the
     * listener is doing now) and throw with the Host's own reason when refused.
     */
    gateway: TeamGatewayConfigFace;
}
/** Read+write seat for the gateway's volatile settings row. */
export interface TeamGatewayConfigFace {
    read: () => Promise<AgentTeamGatewayConfig>;
    save: (patch: {
        enabled?: boolean;
        port?: number;
        token?: string;
    }) => Promise<AgentTeamGatewayConfig>;
}
export type HumanSettingsSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'team'> & HumanSettingsSectionInjected;
export declare function HumanSettingsSection(props: HumanSettingsSectionProps): import("react").JSX.Element;
//# sourceMappingURL=HumanSettingsSection.d.ts.map