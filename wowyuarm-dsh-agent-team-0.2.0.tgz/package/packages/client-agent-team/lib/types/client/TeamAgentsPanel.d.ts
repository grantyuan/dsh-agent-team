import type { AgentTeamAddMemberRequest, AgentTeamClientMemberStatus } from '@wowyuarm/dsh-agent-team/types';
import type { WorkspaceId } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { TeamSidebarProps } from './slots.ts';
interface TeamAgentsPanelProps {
    readonly workspaceId: WorkspaceId;
    readonly loadMembers: TeamSidebarProps['loadMembers'];
    readonly subscribeChanges: TeamSidebarProps['subscribeChanges'];
    readonly addMember: TeamSidebarProps['addMember'];
    readonly updateMember: TeamSidebarProps['updateMember'];
    readonly loadPromptView: TeamSidebarProps['loadPromptView'];
    readonly curateMemberPrompt: TeamSidebarProps['curateMemberPrompt'];
    readonly recoverMember: TeamSidebarProps['recoverMember'];
    readonly clearMemberContext: TeamSidebarProps['clearMemberContext'];
    readonly compactMemberContext: TeamSidebarProps['compactMemberContext'];
    readonly loadMemberInterrupts: TeamSidebarProps['loadMemberInterrupts'];
    readonly releaseMemberInterrupt: TeamSidebarProps['releaseMemberInterrupt'];
    readonly selectSessionHistory: TeamSidebarProps['selectSessionHistory'];
    readonly diagnoseMember: TeamSidebarProps['diagnoseMember'];
    readonly archiveMember: TeamSidebarProps['archiveMember'];
    readonly joinWorkspace: TeamSidebarProps['joinWorkspace'];
    readonly leaveWorkspace: TeamSidebarProps['leaveWorkspace'];
    readonly loadModels: TeamSidebarProps['loadModels'];
    /** The Member Session currently embedded in the conversation seat, if any. */
    readonly memberSessionId?: AgentTeamClientMemberStatus['member']['sessionId'];
    readonly openMemberSession: TeamSidebarProps['openMemberSession'];
    readonly onCreatingChange: (request: AgentTeamAddMemberRequest, creating: boolean) => void;
    readonly t: TeamSidebarProps['t'];
}
export declare function TeamAgentsPanel({ workspaceId, loadMembers, subscribeChanges, addMember, updateMember, loadPromptView, curateMemberPrompt, recoverMember, clearMemberContext, compactMemberContext, loadMemberInterrupts, releaseMemberInterrupt, selectSessionHistory, diagnoseMember, archiveMember, joinWorkspace, leaveWorkspace, loadModels, memberSessionId, openMemberSession, onCreatingChange, t }: TeamAgentsPanelProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamAgentsPanel.d.ts.map