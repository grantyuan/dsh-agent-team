import type { TeamPagePayload } from './slots.ts';
interface TeamMessageCenterPageProps {
    readonly useWorkspaces: TeamPagePayload['useWorkspaces'];
    /** The Host's read-only Message Center projection; one call per visible Workspace. */
    readonly loadMessageCenter: TeamPagePayload['loadMessageCenter'];
    /** The Channel roster, so the filter can name Channels the page has not listed yet. */
    readonly loadChannels: TeamPagePayload['loadChannels'];
    /** The Thread read an inline reply anchors to; it also consumes that row's unread. */
    readonly readThread: TeamPagePayload['readThread'];
    /** The same Human reply path the Thread composer uses; the Host resolves delivery. */
    readonly reply: TeamPagePayload['reply'];
    /** Wake source while the page is open; one scope-less subscription, shared with the sidebar badge. */
    readonly subscribeChanges: TeamPagePayload['subscribeChanges'];
    readonly selectWorkspace: TeamPagePayload['selectWorkspace'];
    readonly selectThread: TeamPagePayload['selectThread'];
    /** The Human's display name, from the Client's one identity projection. */
    readonly humanName: string;
    readonly humanAvatarUrl?: string | undefined;
    readonly t: TeamPagePayload['t'];
}
export declare function TeamMessageCenterPage({ useWorkspaces, loadMessageCenter, loadChannels, readThread, reply, subscribeChanges, selectWorkspace, selectThread, humanName, humanAvatarUrl, t }: TeamMessageCenterPageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamMessageCenterPage.d.ts.map