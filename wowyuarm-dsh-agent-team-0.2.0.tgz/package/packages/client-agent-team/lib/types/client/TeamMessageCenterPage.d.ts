import type { TeamConversationProps } from './slots.ts';
interface TeamMessageCenterPageProps {
    readonly useWorkspaces: TeamConversationProps['useWorkspaces'];
    /** The Host's read-only Message Center projection; one call per visible Workspace. */
    readonly loadMessageCenter: TeamConversationProps['loadMessageCenter'];
    /** The Channel roster, so the filter can name Channels the page has not listed yet. */
    readonly loadChannels: TeamConversationProps['loadChannels'];
    /** The Thread read an inline reply anchors to; it also consumes that row's unread. */
    readonly readThread: TeamConversationProps['readThread'];
    /** The same Human reply path the Thread composer uses; the Host resolves delivery. */
    readonly reply: TeamConversationProps['reply'];
    /** Wake source while the page is open; one scope-less subscription, shared with the sidebar badge. */
    readonly subscribeChanges: TeamConversationProps['subscribeChanges'];
    readonly selectWorkspace: TeamConversationProps['selectWorkspace'];
    readonly selectThread: TeamConversationProps['selectThread'];
    /** The Human's display name, from the Client's one identity projection. */
    readonly humanName: string;
    readonly humanAvatarUrl?: string | undefined;
    readonly t: TeamConversationProps['t'];
}
export declare function TeamMessageCenterPage({ useWorkspaces, loadMessageCenter, loadChannels, readThread, reply, subscribeChanges, selectWorkspace, selectThread, humanName, humanAvatarUrl, t }: TeamMessageCenterPageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamMessageCenterPage.d.ts.map