import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { AgentTeamAttachmentId, AgentTeamPutAttachmentRequest, AgentTeamPutAttachmentResult, AgentTeamRequestId, AgentTeamThreadReadRequest, AgentTeamThreadReadResult } from '@wowyuarm/dsh-agent-team/types';
/** Fresh idempotency identity for one Client-initiated durable request. */
export declare const mintRequestId: () => AgentTeamRequestId;
/**
 * Read one Thread through until the reader holds nothing unread on it — the one
 * durable read behind 「已读」, behind opening a Thread, and behind the read that
 * every Thread write needs first, because the Host refuses a write while the
 * writer still holds unread work. The revision a drained read returns is what a
 * caller fences its write against; `refused` carries the Host's own message,
 * and `capped` means the backlog outran the loop.
 */
export declare const drainThreadUnread: (readThread: (request: AgentTeamThreadReadRequest) => Promise<RemoteResult<AgentTeamThreadReadResult>>, request: Omit<AgentTeamThreadReadRequest, "requestId">) => Promise<{
    readonly kind: "drained";
    readonly revision: AgentTeamThreadReadResult["thread"]["revision"];
} | {
    readonly kind: "refused";
    readonly message: string;
} | {
    readonly kind: "capped";
}>;
/**
 * Upload composer files in order. One failure stops with the error text; the
 * caller keeps its chips so a retry uploads only the still-pending files.
 */
export declare const uploadComposerFiles: (putAttachment: (request: AgentTeamPutAttachmentRequest) => Promise<RemoteResult<AgentTeamPutAttachmentResult>>, workspaceId: AgentTeamPutAttachmentRequest["workspaceId"], files: readonly File[]) => Promise<{
    ok: true;
    attachmentIds: readonly AgentTeamAttachmentId[];
} | {
    ok: false;
    error: string;
}>;
//# sourceMappingURL=requests.d.ts.map