import type { TeamToastProps } from './slots.ts';
/**
 * The Human's new-message banner: whenever a Team Message arrives that is
 * addressed to the Human — an @mention or a direct marker, which is exactly
 * how the assistant's notices and teammates' asks reach them — a banner
 * slides in for ten seconds, and its action jumps straight to the Thread.
 * It watches the same durable Inbox the sidebar badge reads, so nothing new
 * is invented here: the banner is one more presentation of the Host's own
 * unread facts, mounted outside the Team seats so it reaches the Human in
 * either mode. The first pass only seeds the seen-cursor — a backlog that
 * predates this mount never toasts.
 */
export declare function TeamHumanToast({ navigation, loadInbox, subscribeChanges, subscribeReads, enterTeam, selectThread, t, useWorkspaces }: TeamToastProps): import("react").JSX.Element | null;
//# sourceMappingURL=TeamHumanToast.d.ts.map