import type { AgentTeamChannelRef, AgentTeamTaskRef, AgentTeamThreadRef } from '@wowyuarm/dsh-agent-team/types';
import type { WorkspaceId } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { TeamPagePayload } from './slots.ts';
import type { TeamThreadOrigin } from './navigation.ts';
import type { TeamDraftStore } from './drafts.ts';
interface TeamThreadPageProps {
    readonly workspaceId: WorkspaceId;
    /** The Human's own display name and avatar, from the shared identity projection. */
    readonly humanName: string;
    readonly humanAvatarUrl?: string | undefined;
    readonly channelRef?: AgentTeamChannelRef;
    readonly taskRef?: AgentTeamTaskRef;
    readonly threadRef: AgentTeamThreadRef;
    readonly taskNumber?: number;
    /** The Team list this Thread was entered from, deciding where Back lands. */
    readonly threadOrigin?: TeamThreadOrigin;
    /**
     * One-shot locate anchor from the Message Center: after the first read, the
     * timeline walks older history until this sequence is rendered, scrolls it
     * into view, and flashes it once. A sequence no page reaches states that it
     * could not be located instead of leaving a blank scroll.
     */
    readonly focusSequence?: number;
    readonly backFromThread: TeamPagePayload['backFromThread'];
    readonly loadChannels: TeamPagePayload['loadChannels'];
    readonly readThread: TeamPagePayload['readThread'];
    readonly loadThreadHistory: TeamPagePayload['loadThreadHistory'];
    readonly threadObservations: TeamPagePayload['threadObservations'];
    readonly summarizeThread: TeamPagePayload['summarizeThread'];
    readonly subscribeChanges: TeamPagePayload['subscribeChanges'];
    readonly loadMembers: TeamPagePayload['loadMembers'];
    readonly drafts: TeamDraftStore;
    readonly getAttachment: TeamPagePayload['getAttachment'];
    readonly reply: TeamPagePayload['reply'];
    readonly editMessage: TeamPagePayload['editMessage'];
    readonly recallMessage: TeamPagePayload['recallMessage'];
    readonly changeTask: TeamPagePayload['changeTask'];
    readonly promoteThread: TeamPagePayload['promoteThread'];
    readonly putAttachment: TeamPagePayload['putAttachment'];
    readonly selectChannel: TeamPagePayload['selectChannel'];
    readonly selectThread: TeamPagePayload['selectThread'];
    readonly resolveTaskRefs: TeamPagePayload['resolveTaskRefs'];
    readonly resolveThreadRefs: TeamPagePayload['resolveThreadRefs'];
    readonly openMemberSession: TeamPagePayload['openMemberSession'];
    readonly t: TeamPagePayload['t'];
}
export declare function TeamThreadPage(props: TeamThreadPageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamThreadPage.d.ts.map