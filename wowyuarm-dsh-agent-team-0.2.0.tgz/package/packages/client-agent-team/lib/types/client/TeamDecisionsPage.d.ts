import type { TeamConversationProps } from './slots.ts';
interface TeamDecisionsPageProps {
    readonly useWorkspaces: TeamConversationProps['useWorkspaces'];
    readonly loadPendingDecisions: TeamConversationProps['loadPendingDecisions'];
    /** Wake source while the page is open: one scope-less subscription, like the Inbox page. */
    readonly subscribeChanges: TeamConversationProps['subscribeChanges'];
    readonly readThread: TeamConversationProps['readThread'];
    readonly changeAttention: TeamConversationProps['changeAttention'];
    readonly reply: TeamConversationProps['reply'];
    readonly changeTask: TeamConversationProps['changeTask'];
    readonly selectWorkspace: TeamConversationProps['selectWorkspace'];
    readonly selectThread: TeamConversationProps['selectThread'];
    /** The Human's display name, from the Client's one identity projection. */
    readonly humanName: string;
    readonly humanAvatarUrl?: string | undefined;
    readonly t: TeamConversationProps['t'];
}
/**
 * The Human decision queue: every Thread that still waits on the reader, taken
 * from every visible Workspace and partitioned by Workspace, then by Channel.
 * It is one page for one question — 「有什么事在等我决定」 — instead of a chip the
 * reader has to chase through the Inbox into each Thread. A row states the ask
 * in the words its author used and offers the two answers the Host accepts: a
 * reply, written here, and — for work awaiting acceptance — accepting it.
 * Opening the Thread stays available for anything that needs the full history
 * first, and two personal marks sit beside them: 「已读」 clears the reader's own
 * unread on the Thread without removing the row (the ask still waits), and
 * 「关注/取消关注」 toggles the Thread's Attention, which is the only thing that
 * gives a Thread an unread count for this reader at all.
 *
 * Which Workspace and which Channel a row belongs to is a heading rather than a
 * per-row crumb, and the reader's sort key re-lays the rows inside each Channel
 * group while the groups themselves hold their fixed order.
 *
 * The queue never answers anything by being opened: a row leaves only when the
 * Host's projection stops reporting it, which is what makes the page safe to
 * leave open while Agents keep working.
 */
export declare function TeamDecisionsPage({ useWorkspaces, loadPendingDecisions, subscribeChanges, readThread, changeAttention, reply, changeTask, selectWorkspace, selectThread, humanName, humanAvatarUrl, t }: TeamDecisionsPageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TeamDecisionsPage.d.ts.map