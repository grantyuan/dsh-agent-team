import type { WorkspaceId } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { AgentTeamPendingDecisions, AgentTeamPendingDecisionsRequest } from '@wowyuarm/dsh-agent-team/types';
import type { TeamChangeListener } from './team-changes.ts';
/**
 * The two-note cue the decision queue announces a new ask with — a descending
 * doorbell rather than an alarm, because it reports work waiting rather than
 * anything wrong. Synthesized rather than shipped as an audio file: no binary
 * asset, no fetch on a path that must never fail the page, and nothing to
 * preload. A context still suspended by the autoplay policy is resumed and this
 * one cue is dropped; from the reader's first gesture on, every cue is heard.
 */
export declare function playDecisionChime(): void;
export interface TeamDecisionAlertDeps {
    /** Every Workspace this Client can see; the queue is a union across them. */
    readonly workspaceIds: () => readonly WorkspaceId[];
    readonly loadPendingDecisions: (request: AgentTeamPendingDecisionsRequest) => Promise<RemoteResult<AgentTeamPendingDecisions>>;
    readonly subscribeChanges: (listener: TeamChangeListener) => () => void;
}
/**
 * The Client's one cross-Workspace view of what still waits on the Human. It
 * answers two questions from one read per Workspace: how many decisions are
 * waiting (the sidebar entry's mark) and whether an ask arrived that the reader
 * has not seen yet (the cue). Both ride the Host's own `pendingDecisions`
 * projection, so neither surface can disagree with the queue page.
 *
 * Only a commit can change the queue — a Thread read moves a private watermark
 * and no decision with it — so the change stream is the whole wake source.
 * A failed refresh keeps the previous keys and count rather than reporting a
 * shrinkage the Host never committed: a transient read failure must not make
 * the whole queue look answered, nor its return look like a new arrival.
 */
export declare class TeamDecisionAlerts {
    private readonly deps;
    private keys;
    private waiting;
    /** The first successful read establishes the baseline: existing backlog never chimes. */
    private seeded;
    private started;
    private scheduled;
    private unsubscribe;
    private readonly listeners;
    constructor(deps: TeamDecisionAlertDeps);
    readonly getSnapshot: () => number;
    readonly subscribe: (listener: () => void) => (() => void);
    /** Begin watching; safe to call once. The first read seeds without any cue. */
    start(): void;
    dispose(): void;
    private schedule;
    private refresh;
}
//# sourceMappingURL=decision-alerts.d.ts.map